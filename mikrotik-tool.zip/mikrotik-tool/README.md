# MikroTik Network Tool

**Network Engineer Suite для RouterOS v7**

## Встановлення

1. Встановіть Python 3.10+ з https://www.python.org/downloads/
   - ✅ Обов'язково відмітьте "Add Python to PATH"

2. Запустіть `run.bat` — двічі клікніть мишкою

3. Браузер відкриється автоматично на http://localhost:8899

---

## Модулі

| Модуль | Функція |
|--------|---------|
| **Config Audit** | Повний аналіз конфігу: VLAN, WiFi, CAPsMAN, безпека, performance |
| **VLAN Validator** | Перевірка bridge vlan table, PVID, tagged/untagged, конфлікти |
| **WiFi Analyzer** | Канали, TX Power, FT(802.11r), Steering, DFS, Security |
| **CAPsMAN Audit** | Provisioning, Datapath, Security profiles, реєстрація CAP |
| **Troubleshooting** | Дерево діагностики для DHCP, VLAN, WiFi, роумінг, ping |
| **Config Generator** | Генерація конфігів з VLAN, DHCP, CAPsMAN, Firewall |
| **Knowledge Base** | Збереження та пошук рішень між сесіями |
| **Історія** | Журнал всіх аудитів з оцінкою |

---

## Вхідні формати

- `export compact show-sensitive` (рекомендовано)
- `export`
- `.rsc` файл (завантаження)
- `.txt` файл

## Вимоги

- Windows 10/11
- Python 3.10+
- 50 MB дискового простору

## Дані

Всі дані зберігаються локально в `data/knowledge.db` (SQLite)
Нічого не передається в інтернет.

---

*Зроблено для MikroTik RouterOS v7 · CAPsMAN WiFiWave2 · CAP AX · hAP ax³*
