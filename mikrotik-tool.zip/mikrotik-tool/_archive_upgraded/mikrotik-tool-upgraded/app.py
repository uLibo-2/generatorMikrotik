import re
import sqlite3
import json
import webbrowser
import threading
import time
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, UploadFile, File
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import uvicorn

# Import modular platform modules
from backend.models.network_model import ConfigGenRequest
from backend.parsers.network_model import parse_to_model
from backend.audit.engine import full_audit
from backend.audit.compliance import audit_compliance, apply_policy_to_config
from backend.repair.generator import generate_config, auto_repair_config
from backend.repair.diff import generate_config_diff

app = FastAPI(title="MikroTik Platform v2.5 Suite")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

BASE_DIR = Path(__file__).parent
DB_PATH = BASE_DIR / "data" / "knowledge.db"
STATIC_DIR = BASE_DIR / "static"

# ─── DB Init ─────────────────────────────────────────────────────────────────

def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS knowledge (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            problem TEXT NOT NULL,
            solution TEXT NOT NULL,
            tags TEXT,
            created_at TEXT DEFAULT (datetime('now')),
            used_count INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS audit_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            summary TEXT,
            issues_count INTEGER,
            created_at TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.commit()
    conn.close()

init_db()

# ─── Pydantic Request Models ──────────────────────────────────────────────────

class AnalyzeRequest(BaseModel):
    config: str
    filename: Optional[str] = "config.rsc"

class RebuildRequest(BaseModel):
    config: str
    profile: Optional[str] = "basic" # basic, secure, hardened, enterprise, isp

class TroubleshootRequest(BaseModel):
    problem: str

class KnowledgeEntry(BaseModel):
    problem: str
    solution: str
    tags: Optional[str] = ""

class CompareRequest(BaseModel):
    config_old: str
    config_new: str

class PolicyConfig(BaseModel):
    disabled_services: Optional[List[str]] = ["telnet", "ftp", "www", "api", "api-ssl"]
    enabled_services: Optional[List[str]] = ["winbox", "ssh"]
    winbox_port: Optional[int] = 8291
    ssh_port: Optional[int] = 22
    winbox_allowed_addresses: Optional[str] = ""
    ssh_allowed_addresses: Optional[str] = ""
    disable_ipv6: Optional[bool] = True
    identity_prefix: Optional[str] = ""
    identity_regex: Optional[str] = ""
    identity_example: Optional[str] = ""
    syslog_enabled: Optional[bool] = False
    syslog_host: Optional[str] = ""
    syslog_port: Optional[int] = 514
    syslog_topics: Optional[str] = "!debug,!packet"
    ssh_strong_crypto: Optional[bool] = True
    ntp_primary: Optional[str] = ""
    ntp_secondary: Optional[str] = ""
    dns_servers: Optional[str] = ""
    custom_rules: Optional[List[Dict[str, Any]]] = []

POLICY_PATH = BASE_DIR / "data" / "policy.json"

# Helper for policy operations
def load_policy() -> dict:
    if POLICY_PATH.exists():
        try:
            return json.loads(POLICY_PATH.read_text(encoding="utf-8"))
        except:
            return {}
    return {}

def save_policy(policy: dict):
    POLICY_PATH.parent.mkdir(exist_ok=True)
    POLICY_PATH.write_text(json.dumps(policy, ensure_ascii=False, indent=2), encoding="utf-8")

# ─── API Routes ───────────────────────────────────────────────────────────────

@app.post("/api/analyze")
async def analyze(req: AnalyzeRequest):
    result = full_audit(req.config)
    
    # Save to history
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO audit_history (filename, summary, issues_count) VALUES (?,?,?)",
        (req.filename, json.dumps(result["summary"]), result["summary"]["total_issues"])
    )
    conn.commit()
    conn.close()
    return result

@app.post("/api/analyze/upload")
async def analyze_upload(file: UploadFile = File(...)):
    content = await file.read()
    try:
        config_text = content.decode("utf-8")
    except UnicodeDecodeError:
        config_text = content.decode("latin-1")
        
    result = full_audit(config_text)
    
    # Save to history
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO audit_history (filename, summary, issues_count) VALUES (?,?,?)",
        (file.filename, json.dumps(result["summary"]), result["summary"]["total_issues"])
    )
    conn.commit()
    conn.close()
    return result

@app.post("/api/analyze/rebuild")
async def rebuild_configuration_api(req: RebuildRequest):
    result = auto_repair_config(req.config, req.profile)
    return result

@app.post("/api/generate")
async def generate_api(req: ConfigGenRequest):
    # Retrieve default policy to append if any exists
    lines = generate_config(req).splitlines()
    policy = load_policy()
    if policy:
        lines = apply_policy_to_config(lines, policy)
    return {"config": "\n".join(lines)}

@app.post("/api/compare")
async def compare_configs_api(req: CompareRequest):
    diff_text = generate_config_diff(req.config_old, req.config_new)
    return {"diff": diff_text}

@app.get("/api/history")
async def get_history():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT id, filename, summary, issues_count, created_at FROM audit_history ORDER BY created_at DESC LIMIT 20"
    ).fetchall()
    conn.close()
    return [{"id": r[0], "filename": r[1], "summary": json.loads(r[2]), "issues_count": r[3], "created_at": r[4]} for r in rows]

@app.get("/api/knowledge")
async def get_knowledge():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT id, problem, solution, tags, created_at, used_count FROM knowledge ORDER BY used_count DESC, created_at DESC"
    ).fetchall()
    conn.close()
    return [{"id": r[0], "problem": r[1], "solution": r[2], "tags": r[3], "created_at": r[4], "used_count": r[5]} for r in rows]

@app.post("/api/knowledge")
async def add_knowledge(entry: KnowledgeEntry):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO knowledge (problem, solution, tags) VALUES (?,?,?)",
        (entry.problem, entry.solution, entry.tags)
    )
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.delete("/api/knowledge/{kid}")
async def delete_knowledge(kid: int):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("DELETE FROM knowledge WHERE id=?", (kid,))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.get("/api/knowledge/use/{kid}")
async def use_knowledge(kid: int):
    conn = sqlite3.connect(DB_PATH)
    conn.execute("UPDATE knowledge SET used_count=used_count+1 WHERE id=?", (kid,))
    conn.commit()
    conn.close()
    return {"status": "ok"}

@app.post("/api/report/generate")
async def generate_report(req: AnalyzeRequest):
    result = full_audit(req.config)
    
    report = []
    report.append("==========================================================================")
    report.append("             ЗВІТ ПРО АУДИТ КОНФІГУРАЦІЇ MIKROTIK ROUTEROS               ")
    report.append("==========================================================================")
    report.append(f"Файл конфігурації: {req.filename or 'config.rsc'}")
    report.append(f"Дата генерації: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append(f"Загальний бал готовності (Production Readiness Score): {result['production_readiness']['score']}%")
    report.append(f"Вердикт: {'ГОТОВИЙ ДО ЕКСПЛУАТАЦІЇ' if result['production_readiness']['verdict'] == 'READY' else 'НЕ ГОТОВИЙ ДО ЕКСПЛУАТАЦІЇ'}")
    report.append("==========================================================================\n")
    
    # 1. EXECUTIVE SUMMARY
    report.append("1. EXECUTIVE SUMMARY (РЕЗЮМЕ ДЛЯ КЕРІВНИЦТВА)")
    report.append("--------------------------------------------------------------------------")
    report.append(f"Аудит мережі MikroTik виявив {result['summary']['total_issues']} критичних/високих помилок та {result['summary']['total_warnings']} попереджень.")
    report.append(f"Поточний статус готовності до продакшну оцінюється у {result['production_readiness']['score']}%.")
    if result['production_readiness']['critical_failures']:
        report.append("Критичні фактори, що блокують запуск мережі в експлуатацію:")
        for cf in result['production_readiness']['critical_failures']:
            report.append(f"  - {cf}")
    else:
        report.append("Усі життєво важливі служби мережі (NAT, WAN, міст) налаштовані та працездатні.")
    report.append("\n")
    
    # 2. CRITICAL ISSUES
    report.append("2. CRITICAL ISSUES (КРИТИЧНІ ПОМИЛКИ)")
    report.append("--------------------------------------------------------------------------")
    if result['production_readiness']['critical_failures']:
        for c in result['production_readiness']['critical_failures']:
            report.append(f" [CRITICAL] {c}")
    else:
        report.append("Критичних помилок не виявлено.")
    report.append("\n")
    
    # 3. HIGH ISSUES
    report.append("3. HIGH ISSUES (ПОМИЛКИ ВИСОКОГО ПРІОРИТЕТУ)")
    report.append("--------------------------------------------------------------------------")
    highs = []
    sections_to_check = ["l2", "vlan_ext", "dhcp_ext", "capsman_ext", "wifi_ext", "firewall", "multiwan", "script", "services", "performance_ext", "orphan_objects"]
    for sect_key in sections_to_check:
        sect = result.get(sect_key)
        if sect and sect.get("issues"):
            for issue in sect["issues"]:
                highs.append(issue)
                
    if highs:
        for h in set(highs):
            report.append(f" [HIGH] {h}")
    else:
        report.append("Помилок високого пріоритету не виявлено.")
    report.append("\n")
    
    # 4. WARNINGS
    report.append("4. WARNINGS (ПОПЕРЕДЖЕННЯ)")
    report.append("--------------------------------------------------------------------------")
    warns = []
    for sect_key in sections_to_check:
        sect = result.get(sect_key)
        if sect and sect.get("warnings"):
            for w in sect["warnings"]:
                warns.append(w)
                
    if warns:
        for w in set(warns):
            report.append(f" [WARNING] {w}")
    else:
        report.append("Попереджень не виявлено.")
    report.append("\n")
    
    # 5. RECOMMENDATIONS
    report.append("5. RECOMMENDATIONS (РЕКОМЕНДАЦІЇ З ОПТИМІЗАЦІЇ)")
    report.append("--------------------------------------------------------------------------")
    recs = []
    for sect_key in sections_to_check:
        sect = result.get(sect_key)
        if sect and sect.get("recommendations"):
            for r in sect["recommendations"]:
                recs.append(r)
        if sect and sect.get("fixes"):
            for f in sect["fixes"]:
                recs.append(f"Застосувати виправлення: {f}")
                
    if recs:
        for r in set(recs):
            report.append(f" [*] {r}")
    else:
        report.append("Рекомендацій з оптимизації не сформовано.")
    report.append("\n")
    
    # 6. SECURITY REPORT
    report.append("6. SECURITY REPORT (ДЕТАЛЬНИЙ ЗВІТ БЕЗПЕКИ)")
    report.append("--------------------------------------------------------------------------")
    report.append(f"Рівень безпеки (Security Rating): {result['security_ext']['score']}/100")
    report.append("\n")
    
    # 7. TOPOLOGY REPORT
    report.append("7. TOPOLOGY REPORT (АНАЛІЗ ТОПОЛОГІЇ МЕРЕЖІ)")
    report.append("--------------------------------------------------------------------------")
    if result.get("topology") and result["topology"].get("chains"):
        for chain in result["topology"]["chains"]:
            report.append(f" Мережа: {chain['network']} - Status: {chain['status'].upper()}")
            steps_str = " -> ".join(s['name'] for s in chain['chain_steps'])
            report.append(f"  Ланцюг: {steps_str}")
            for step in chain['chain_steps']:
                if step['status'] != 'ok':
                    report.append(f"    * Помилка на кроці '{step['name']}': {step['detail']}")
    else:
        report.append("Топологічний звіт недоступний.")
    report.append("\n")
    
    # 8. PRODUCTION READINESS SCORE
    report.append("8. PRODUCTION READINESS SCORE (КЛЮЧОВІ ПОКАЗНИКИ ГОТОВНОСТІ)")
    report.append("--------------------------------------------------------------------------")
    report.append(f"Підсумковий індекс готовності: {result['production_readiness']['score']}%")
    report.append("Розподіл за категоріями:")
    for cat, score in result["production_readiness"]["breakdown"].items():
        report.append(f"  - {cat.upper()}: {score}%")
    report.append("\n==========================================================================")
    
    return {"report": "\n".join(report)}

@app.get("/api/report/{history_id}")
async def get_report(history_id: int):
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute(
        "SELECT filename, summary, issues_count, created_at FROM audit_history WHERE id=?",
        (history_id,)
    ).fetchone()
    conn.close()
    if not row:
        return JSONResponse(status_code=404, content={"error": "Звіт не знайдено"})
    
    filename, summary_str, issues_count, created_at = row
    summary = json.loads(summary_str)
    
    report = []
    report.append("==================================================")
    report.append(f"ЗВІТ ПРО АУДИТ КОНФІГУРАЦІЇ MIKROTIK")
    report.append("==================================================")
    report.append(f"Файл: {filename or 'config'}")
    report.append(f"Дата аудиту: {created_at}")
    report.append(f"Оцінка готовності: {summary.get('score', 0)}/100")
    report.append(f"Критичні проблеми: {summary.get('total_issues', 0)}")
    report.append(f"Попередження: {summary.get('total_warnings', 0)}")
    report.append("==================================================")
    report.append("\nЦей звіт сформовано на основі історії аудиту.")
    
    return {"report": "\n".join(report)}

@app.post("/api/compliance")
async def check_compliance(req: AnalyzeRequest):
    policy = load_policy()
    if not policy:
        return {"violations": [], "passed": [], "compliant": True, "score": None, "note": "Регламент не налаштовано"}
    model = parse_to_model(req.config)
    result = audit_compliance(model, policy)
    return result

@app.get("/api/policy")
async def get_policy():
    return load_policy()

@app.post("/api/policy")
async def set_policy(policy: dict):
    save_policy(policy)
    return {"status": "ok"}

@app.get("/api/sample-config")
async def get_sample_config():
    config = """# model = hAP ax3
/system identity
set name=Router-Home

/interface bridge
add name=bridge vlan-filtering=no comment="Main local bridge"

/interface vlan
add interface=bridge name=vlan10_mgmt vlan-id=10
add interface=bridge name=vlan20_staff vlan-id=20

/interface bridge port
add bridge=bridge interface=ether2 pvid=20 comment="Staff Access Port"
add bridge=bridge interface=ether3 pvid=30 comment="Guest Access Port"

/interface bridge vlan
add bridge=bridge tagged=bridge,ether5 untagged=ether2 vlan-ids=20

/ip address
add address=10.20.0.1/24 interface=vlan20_staff

/ip pool
add name=pool_staff ranges=10.20.0.10-10.20.0.200

/ip dhcp-server
add name=dhcp_staff interface=vlan20_staff address-pool=pool_staff disabled=no lease-time=8h

/ip dhcp-server network
add address=10.20.0.0/24 gateway=10.20.0.1 dns-server=8.8.8.8

/ip service
set telnet disabled=no
set ftp disabled=no
set www disabled=no
set winbox port=8291 disabled=no

/ip neighbor discovery-settings
set discover-interface-list=all
"""
    return {"config": config}

@app.get("/", response_class=FileResponse)
async def root():
    return FileResponse(STATIC_DIR / "index.html")

app.mount("/", StaticFiles(directory=STATIC_DIR), name="static")

# ─── Launch ──────────────────────────────────────────────────────────────────

def open_browser():
    time.sleep(1.2)
    webbrowser.open("http://localhost:8899")

if __name__ == "__main__":
    threading.Thread(target=open_browser, daemon=True).start()
    uvicorn.run(app, host="0.0.0.0", port=8899, log_level="warning")
