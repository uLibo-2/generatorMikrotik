import re
from typing import List, Dict, Set

class ConfigDependencyGraph:
    def __init__(self):
        self.nodes: List[str] = []
        self.adj: Dict[str, Set[str]] = {} # node -> set of nodes it depends on

    def add_node(self, command: str):
        self.nodes.append(command)
        self.adj[command] = set()

    def build_dependencies(self):
        # We will parse commands and match them to identify dependencies
        # Common Mikrotik resource creation patterns:
        # 1. Bridge creation: /interface bridge add name=XYZ
        # 2. VLAN creation: /interface vlan add name=VLAN_XYZ vlan-id=NUM interface=BRIDGE_XYZ
        # 3. IP address: /ip address add address=IP interface=IFACE
        # 4. DHCP Pool: /ip pool add name=POOL_XYZ
        # 5. DHCP Server: /ip dhcp-server add interface=IFACE address-pool=POOL_XYZ
        
        # Let's map each command to what it creates / defines
        creates_map = {} # resource_id -> command
        
        # First pass: identify what each command creates
        for cmd in self.nodes:
            # Normalize whitespace
            norm_cmd = " ".join(cmd.split())
            
            # Bridge
            if "/interface bridge add" in norm_cmd or "/interface bridge set" in norm_cmd:
                name_match = re.search(r"name=([^\s]+)", norm_cmd)
                name = name_match.group(1).replace('"', '') if name_match else "bridge"
                creates_map[f"bridge:{name}"] = cmd
                
            # VLAN Interface
            elif "/interface vlan add" in norm_cmd:
                name_match = re.search(r"name=([^\s]+)", norm_cmd)
                if name_match:
                    name = name_match.group(1).replace('"', '')
                    creates_map[f"interface:{name}"] = cmd
                    creates_map[f"vlan:{name}"] = cmd
                    
            # IP Address
            elif "/ip address add" in norm_cmd:
                addr_match = re.search(r"address=([^\s]+)", norm_cmd)
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if addr_match and iface_match:
                    addr = addr_match.group(1).replace('"', '')
                    iface = iface_match.group(1).replace('"', '')
                    creates_map[f"ip:{iface}"] = cmd
                    
            # DHCP Pool
            elif "/ip pool add" in norm_cmd:
                name_match = re.search(r"name=([^\s]+)", norm_cmd)
                if name_match:
                    name = name_match.group(1).replace('"', '')
                    creates_map[f"pool:{name}"] = cmd
                    
            # DHCP Server
            elif "/ip dhcp-server add" in norm_cmd:
                name_match = re.search(r"name=([^\s]+)", norm_cmd)
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if name_match:
                    name = name_match.group(1).replace('"', '')
                    creates_map[f"dhcp-server:{name}"] = cmd
                if iface_match:
                    iface = iface_match.group(1).replace('"', '')
                    creates_map[f"dhcp-server-iface:{iface}"] = cmd

        # Second pass: build dependencies (edges)
        for cmd in self.nodes:
            norm_cmd = " ".join(cmd.split())
            
            # 1. VLAN depends on its parent interface/bridge
            if "/interface vlan add" in norm_cmd:
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if iface_match:
                    parent = iface_match.group(1).replace('"', '')
                    # Depends on bridge creation
                    if f"bridge:{parent}" in creates_map:
                        self.adj[cmd].add(creates_map[f"bridge:{parent}"])
                        
            # 2. Bridge port depends on bridge and interface
            elif "/interface bridge port add" in norm_cmd:
                bridge_match = re.search(r"bridge=([^\s]+)", norm_cmd)
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if bridge_match:
                    br = bridge_match.group(1).replace('"', '')
                    if f"bridge:{br}" in creates_map:
                        self.adj[cmd].add(creates_map[f"bridge:{br}"])
                if iface_match:
                    iface = iface_match.group(1).replace('"', '')
                    if f"interface:{iface}" in creates_map:
                        self.adj[cmd].add(creates_map[f"interface:{iface}"])

            # 3. IP address depends on its interface (VLAN or Bridge)
            elif "/ip address add" in norm_cmd:
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if iface_match:
                    iface = iface_match.group(1).replace('"', '')
                    if f"interface:{iface}" in creates_map:
                        self.adj[cmd].add(creates_map[f"interface:{iface}"])
                    elif f"bridge:{iface}" in creates_map:
                        self.adj[cmd].add(creates_map[f"bridge:{iface}"])

            # 4. DHCP Server depends on DHCP Pool and Interface IP
            elif "/ip dhcp-server add" in norm_cmd:
                pool_match = re.search(r"address-pool=([^\s]+)", norm_cmd)
                iface_match = re.search(r"interface=([^\s]+)", norm_cmd)
                if pool_match:
                    pool = pool_match.group(1).replace('"', '')
                    if f"pool:{pool}" in creates_map:
                        self.adj[cmd].add(creates_map[f"pool:{pool}"])
                if iface_match:
                    iface = iface_match.group(1).replace('"', '')
                    # Must have IP address configured first
                    if f"ip:{iface}" in creates_map:
                        self.adj[cmd].add(creates_map[f"ip:{iface}"])
                    # Or at least the interface itself
                    elif f"interface:{iface}" in creates_map:
                        self.adj[cmd].add(creates_map[f"interface:{iface}"])

            # 5. DHCP Network depends on DHCP server/pool
            elif "/ip dhcp-server network add" in norm_cmd:
                # Usually matches ip subnet, but we make it depend on pool/dhcp creation if any exist
                for key, val in creates_map.items():
                    if key.startswith("pool:") or key.startswith("dhcp-server:"):
                        self.adj[cmd].add(val)

            # 6. VLAN set command in bridge vlan depends on bridge and interfaces
            elif "/interface bridge vlan add" in norm_cmd:
                bridge_match = re.search(r"bridge=([^\s]+)", norm_cmd)
                if bridge_match:
                    br = bridge_match.group(1).replace('"', '')
                    if f"bridge:{br}" in creates_map:
                        self.adj[cmd].add(creates_map[f"bridge:{br}"])

    def sort(self) -> List[str]:
        # Topological sort using DFS (Tarjan's algorithm)
        visited = {} # node -> state (0 = unvisited, 1 = visiting, 2 = visited)
        order = []
        
        for node in self.nodes:
            visited[node] = 0
            
        def dfs(node):
            visited[node] = 1 # visiting
            for dep in self.adj.get(node, []):
                if visited.get(dep, 0) == 0:
                    dfs(dep)
                elif visited.get(dep, 0) == 1:
                    # Cycle detected, ignore to prevent freeze, but break dependency
                    pass
            visited[node] = 2 # visited
            order.append(node)
            
        for node in self.nodes:
            if visited[node] == 0:
                dfs(node)
                
        return order

def sort_fixes(fixes: List[str]) -> List[str]:
    graph = ConfigDependencyGraph()
    for fix in fixes:
        graph.add_node(fix)
    graph.build_dependencies()
    return graph.sort()
