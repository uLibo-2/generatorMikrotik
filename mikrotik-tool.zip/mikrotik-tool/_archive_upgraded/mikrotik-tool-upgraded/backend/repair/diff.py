import difflib

def generate_config_diff(orig: str, new: str) -> str:
    orig_lines = orig.splitlines()
    new_lines = new.splitlines()
    
    diff = difflib.unified_diff(
        orig_lines, new_lines,
        fromfile="Original Config",
        tofile="Repaired Config",
        lineterm=""
    )
    return "\n".join(list(diff))
