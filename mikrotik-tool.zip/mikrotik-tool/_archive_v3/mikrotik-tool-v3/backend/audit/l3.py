import ipaddress
from typing import Dict, Any
from backend.audit.base import AuditPlugin, registry
from backend.models.network_model import NetworkModel
from backend.parsers.base import get_param_value

@registry.register
class AuditDhcpConsistency(AuditPlugin):
    id = "BP-L3-001"
    category = "l3"
    severity = "critical"
    confidence = 98
    title = "DHCP Server & Subnet Gateway Consistency"
    description = "Перевірка зв'язку DHCP сервера, IP адреси інтерфейсу та пулу адрес."
    impact = "Якщо DHCP сервер запущено на інтерфейсі без IP адреси, або гейтвей DHCP мережі не належить до підмережі інтерфейсу, клієнти не зможуть отримати IP або вийти в мережу."
    best_practice = "Інтерфейс DHCP повинен мати статичну IP адресу. Пул DHCP та гейтвей повинні повністю належати до цієї мережі."
    resolution = "Створити IP адресу на інтерфейсі або виправити DHCP налаштування."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        # Build address mapping: interface -> list of (addr_str, ip_network)
        iface_ips = {}
        for ip in model.ips:
            try:
                net = ipaddress.ip_network(ip.address, strict=False)
                iface_ips.setdefault(ip.interface, []).append((ip.address, net))
            except Exception:
                pass

        # Also build bridge -> member interfaces map for DHCP on bridge
        # If DHCP is on 'bridge', also check VLAN interfaces bound to that bridge
        bridge_aliases = {}
        for br in model.bridges:
            aliases = [br.name]
            for vlan_iface in model.vlans:
                if vlan_iface.interface == br.name:
                    aliases.append(vlan_iface.name)
            bridge_aliases[br.name] = aliases

        def get_iface_nets(iface_name):
            """Return all IP networks reachable for this interface (direct + VLAN subinterfaces)."""
            nets = list(iface_ips.get(iface_name, []))
            # If this is a bridge, also pull nets from its VLAN sub-interfaces
            for br_name, aliases in bridge_aliases.items():
                if iface_name == br_name:
                    for alias in aliases:
                        nets.extend(iface_ips.get(alias, []))
            return nets

        for dhcp in model.dhcp_servers:
            if dhcp.disabled:
                continue

            iface_nets = get_iface_nets(dhcp.interface)

            # Check: Does the interface (or its VLAN subs) have any IP?
            if not iface_nets:
                issues.append(
                    f"❌ DHCP: Сервер '{dhcp.name}' запущено на інтерфейсі '{dhcp.interface}', "
                    f"який не має жодної IP адреси"
                )
                fixes.append(f"/ip address add address=192.168.88.1/24 interface={dhcp.interface}")
                continue

            # Check: Does the pool exist?
            pool_found = next((p for p in model.dhcp_pools if p.name == dhcp.address_pool), None)
            if not pool_found:
                issues.append(
                    f"❌ DHCP: Сервер '{dhcp.name}' посилається на неіснуючий пул '{dhcp.address_pool}'"
                )
                fixes.append(f"/ip pool add name={dhcp.address_pool} ranges=192.168.88.10-192.168.88.254")
                continue

            # Check: Does any DHCP network overlap with any IP on this interface?
            matched = False
            for net in model.dhcp_networks:
                try:
                    dhcp_net = ipaddress.ip_network(net.address, strict=False)
                    for ip_addr_str, ip_net in iface_nets:
                        if ip_net.overlaps(dhcp_net):
                            matched = True
                            # Verify gateway belongs to subnet
                            if net.gateway:
                                try:
                                    gw_ip = ipaddress.ip_address(net.gateway)
                                    if gw_ip not in ip_net:
                                        issues.append(
                                            f"❌ DHCP: Шлюз DHCP '{net.gateway}' не належить до підмережі "
                                            f"інтерфейсу '{ip_addr_str}'"
                                        )
                                except Exception:
                                    pass
                            break
                    if matched:
                        break
                except Exception:
                    pass

            if not matched:
                # Only report if there are NO dhcp_networks at all, or none match
                # Don't flag if the issue is simply missing /ip dhcp-server network (that's a separate check)
                if model.dhcp_networks:
                    issues.append(
                        f"❌ DHCP: Підмережа DHCP сервера '{dhcp.name}' не відповідає жодному "
                        f"діапазону IP-адрес на інтерфейсі '{dhcp.interface}'"
                    )

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}


@registry.register
class AuditDefaultRoute(AuditPlugin):
    id = "BP-L3-002"
    category = "l3"
    # Lowered confidence: static exports don't include dynamic routes from DHCP client
    severity = "critical"
    confidence = 70
    title = "Default Gateway Route"
    description = "Перевірка наявності дефолтного маршруту для виходу в Інтернет."
    impact = "Без маршруту за замовчуванням (0.0.0.0/0) пристрій та його локальні клієнти не матимуть доступу до зовнішніх мереж та Інтернету."
    best_practice = (
        "Налаштуйте статичний маршрут /ip route або увімкніть add-default-route=yes на DHCP клієнті WAN. "
        "Зверніть увагу: /export не показує динамічні маршрути від DHCP клієнта — "
        "якщо DHCP клієнт активний, маршрут може існувати в runtime."
    )
    resolution = "Перевірте '/ip route print' на живому пристрої або налаштуйте явний статичний маршрут."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        has_static_default = False
        route_lines = model.raw_sections.get("/ip route", [])
        for line in route_lines:
            dst = get_param_value(line, "dst-address")
            gateway = get_param_value(line, "gateway")
            disabled = get_param_value(line, "disabled") == "yes"
            if not disabled and gateway and (dst == "0.0.0.0/0" or not dst):
                has_static_default = True

        # DHCP client without add-default-route=no → creates dynamic default route at runtime
        has_dhcp_client_route = False
        dhcp_client_lines = model.raw_sections.get("/ip dhcp-client", [])
        for line in dhcp_client_lines:
            disabled = get_param_value(line, "disabled") == "yes"
            add_default = get_param_value(line, "add-default-route")
            if not disabled and add_default != "no":
                has_dhcp_client_route = True

        if has_static_default or has_dhcp_client_route:
            # Route exists (static) or will be created dynamically
            if has_dhcp_client_route and not has_static_default:
                info.append(
                    "ℹ️ Дефолтний маршрут буде додано динамічно DHCP клієнтом. "
                    "Виконайте '/ip route print' на пристрої для підтвердження."
                )
        else:
            wan_candidate = "ether1"
            for iface in model.interfaces:
                if "wan" in iface.name.lower() or "isp" in iface.name.lower():
                    wan_candidate = iface.name
                    break
            warnings.append(
                "⚠️ Маршрутизація: Не знайдено статичного дефолтного маршруту та активного DHCP клієнта з "
                "add-default-route. Перевірте '/ip route print' на пристрої."
            )
            fixes.append(f"/ip dhcp-client add interface={wan_candidate} disabled=no")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}


@registry.register
class AuditDuplicateStaticLeases(AuditPlugin):
    id = "BP-L3-003"
    category = "l3"
    severity = "high"
    confidence = 98
    title = "Duplicate DHCP Static Leases"
    description = "Пошук дублюючих записів статичної прив'язки IP та MAC адрес в DHCP сервері."
    impact = "Дублювання MAC адрес або призначення однієї IP декільком MAC адресам призводить до конфлікту адрес та переривань зв'язку."
    best_practice = "Кожен клієнт (MAC) повинен мати унікальну IP-адресу у списку статичних лізів."
    resolution = "Видалити дублюючі записи DHCP."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        seen_macs = {}
        seen_ips = {}

        for lease in model.dhcp_static_leases:
            mac = lease.mac_address.lower()
            if mac in seen_macs:
                issues.append(
                    f"❌ DHCP: Дублювання статичного лізу для MAC '{lease.mac_address}' "
                    f"(IP {lease.address} та {seen_macs[mac]})"
                )
            else:
                seen_macs[mac] = lease.address

            ip = lease.address
            if ip in seen_ips:
                issues.append(
                    f"❌ DHCP: Дублювання IP '{ip}' для різних MAC "
                    f"({lease.mac_address} та {seen_ips[ip]})"
                )
            else:
                seen_ips[ip] = lease.mac_address

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}


@registry.register
class AuditSubnetOverlaps(AuditPlugin):
    id = "BP-L3-004"
    category = "l3"
    severity = "critical"
    confidence = 95
    title = "Subnet Overlap Detection"
    description = "Пошук перетинів IP підмереж на різних мережевих інтерфейсах пристрою."
    impact = "Перетин підмереж ламає таблицю маршрутизації. Роутер не знатиме куди надсилати трафік, що призведе до непрацездатності одного з сегментів."
    best_practice = "Кожен інтерфейс / VLAN повинен використовувати унікальний неперетинний діапазон IP-адрес."
    resolution = "Змінити IP-адресацію на одному з інтерфейсів."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        networks = []
        for ip in model.ips:
            try:
                net = ipaddress.ip_network(ip.address, strict=False)
                networks.append((ip.interface, ip.address, net))
            except Exception:
                pass

        for i in range(len(networks)):
            iface_a, addr_a, net_a = networks[i]
            for j in range(i + 1, len(networks)):
                iface_b, addr_b, net_b = networks[j]
                if iface_a != iface_b and net_a.overlaps(net_b):
                    issues.append(
                        f"❌ Конфлікт IP: Підмережа '{addr_a}' на '{iface_a}' "
                        f"перетинається з '{addr_b}' на '{iface_b}'"
                    )

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}
