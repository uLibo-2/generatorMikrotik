import re
from typing import Dict, Any
from backend.audit.base import AuditPlugin, registry
from backend.models.network_model import NetworkModel
from backend.parsers.base import get_param_value

@registry.register
class AuditUnsafeIpServices(AuditPlugin):
    id = "BP-SEC-001"
    category = "security"
    severity = "critical"
    confidence = 100
    title = "Unsafe IP Services Detection"
    description = "Пошук та перевірка доступності незашифрованих та небезпечних служб керування роутером (telnet, ftp, www)."
    impact = "Увімкнені служби telnet та ftp передають паролі та дані в незашифрованому вигляді через мережу. Будь-хто в сегменті транзиту зможе перехопити доступ до роутера."
    best_practice = "Завжди вимикайте незашифровані служби telnet, ftp, api та www (або переведіть www на www-ssl) і використовуйте лише безпечні winbox, ssh та api-ssl."
    resolution = "Вимкнути небезпечні служби в налаштуваннях IP Services."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []
        
        unsafe_services = ["telnet", "ftp"]
        for srv in model.services:
            if srv.name in unsafe_services and not srv.disabled:
                issues.append(f"❌ Службу {srv.name} увімкнено (небезпечний незашифрований протокол)")
                fixes.append(f"/ip service disable {srv.name}")
                
            if srv.name == "www" and not srv.disabled:
                warnings.append("⚠️ Службу www (HTTP Webfig) увімкнено без SSL шифрування")
                
        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditIpServicesRestrictions(AuditPlugin):
    id = "BP-SEC-002"
    category = "security"
    severity = "high"
    confidence = 95
    title = "Admin Management Access Restriction"
    description = "Перевірка обмеження доступу до Winbox, SSH та Web за IP-адресами."
    impact = "Якщо доступ до служб Winbox (8291) та SSH (22) відкритий для всіх IP адрес (0.0.0.0/0), роутер піддається постійному брутфорсу (brute-force) паролів з інтернету."
    best_practice = "Явно вкажіть дозволені IP-адреси або підмережу адміністратора (параметр address) для служб winbox, ssh, www-ssl."
    resolution = "Обмежити доступ до служб управління роутером за допомогою параметра address."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []
        
        admin_services = ["winbox", "ssh", "www-ssl"]
        for srv in model.services:
            if srv.name in admin_services and not srv.disabled:
                if not srv.address or srv.address == "0.0.0.0/0":
                    warnings.append(f"⚠️ Доступ до {srv.name} відкрито для всіх IP адрес (відсутнє обмеження в полі address)")
                    fixes.append(f"/ip service set {srv.name} address=192.168.88.0/24")
                    
        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditDnsOpenResolver(AuditPlugin):
    id = "BP-SEC-003"
    category = "security"
    severity = "critical"
    confidence = 98
    title = "DNS WAN Open Resolver Vulnerability"
    description = "Перевірка захисту від атак DNS Amplification, коли порт DNS 53 відкритий назовні."
    impact = "Якщо дозволено remote-requests (allow-remote-requests=yes), і порт 53 UDP/TCP не заблоковано на інтерфейсі WAN у Firewall, ваш роутер стане DNS Open Resolver. Зловмисники використовуватимуть його для здійснення потужних DDoS-атак."
    best_practice = "Завжди блокувати вхідні DNS-запити на порт 53 з боку WAN інтерфейсу або вимкнути allow-remote-requests."
    resolution = "Створити захисне правило у файрволі, яке блокує DNS запити на WAN."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        if not model.dns_allow_remote:
            return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

        # Count active (non-disabled) firewall input rules
        active_input_rules = [
            r for r in model.firewall_rules
            if r.chain == "input" and not getattr(r, "disabled", False)
        ]

        if not active_input_rules:
            # Firewall is entirely off → DNS exposure is a consequence, not a separate finding.
            # The AuditFirewallDisabled check will cover this case.
            warnings.append(
                "⚠️ DNS: allow-remote-requests=yes, але IPv4 firewall вимкнено — "
                "DNS порт 53 потенційно доступний з WAN (детальніше — у розділі Firewall)"
            )
            return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

        # Firewall is active: check if port 53 is explicitly blocked on WAN
        dns_blocked_wan = False
        for rule in active_input_rules:
            if rule.action in ("drop", "reject"):
                is_port_53 = rule.dst_port == "53" or "53" in (rule.dst_port or "")
                is_wan = rule.in_interface_list == "WAN" or "wan" in (rule.in_interface or "").lower()
                if is_port_53 and is_wan:
                    dns_blocked_wan = True
                    break

        # Also accept: a final drop-all on input from WAN covers port 53 implicitly
        for rule in active_input_rules:
            if rule.action in ("drop", "reject"):
                no_conditions = (
                    not rule.src_address and not rule.dst_port
                    and not rule.src_address_list and not rule.dst_address_list
                    and (rule.in_interface_list == "WAN" or "wan" in (rule.in_interface or "").lower()
                         or not rule.in_interface_list)
                )
                if no_conditions:
                    dns_blocked_wan = True
                    break

        if not dns_blocked_wan:
            issues.append(
                "❌ DNS: allow-remote-requests=yes та відсутній захист порту 53 на WAN — "
                "вразливість до DNS Amplification DDoS атак"
            )
            fixes.append("/ip firewall filter add chain=input action=drop protocol=udp dst-port=53 in-interface-list=WAN comment=\"Block DNS from WAN\"")
            fixes.append("/ip firewall filter add chain=input action=drop protocol=tcp dst-port=53 in-interface-list=WAN comment=\"Block DNS from WAN\"")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditDiscoveryOnWan(AuditPlugin):
    id = "BP-SEC-004"
    category = "security"
    severity = "medium"
    confidence = 90
    title = "Neighbor Discovery on WAN"
    description = "Перевірка активності служб виявлення сусідів (MNDP, LLDP) на зовнішніх інтерфейсах."
    impact = "Neighbor Discovery та MAC Winbox Server, увімкнені на WAN, надсилають у зовнішню мережу інформацію про модель роутера, версію RouterOS та MAC-адресу, полегшуючи зловмисникам пошук вразливостей."
    best_practice = "Дозволяти Neighbor Discovery та MAC Winbox тільки для внутрішнього списку інтерфейсів (LAN)."
    resolution = "Обмежити Neighbor Discovery та MAC Winbox списком LAN."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        mndp_lines = model.raw_sections.get("/ip neighbor discovery-settings", [])
        mndp_only_lan = False
        mndp_explicitly_set = bool(mndp_lines)
        for line in mndp_lines:
            iface_list = get_param_value(line, "discover-interface-list")
            if iface_list == "LAN":
                mndp_only_lan = True

        mac_winbox_lines = model.raw_sections.get("/tool mac-server mac-winbox", [])
        winbox_only_lan = False
        winbox_explicitly_set = bool(mac_winbox_lines)
        for line in mac_winbox_lines:
            iface_list = get_param_value(line, "allowed-interface-list")
            if iface_list == "LAN":
                winbox_only_lan = True

        # MNDP: warn if explicitly set to non-LAN, or if not set at all (default = all)
        if mndp_explicitly_set and not mndp_only_lan:
            warnings.append("⚠️ Neighbor Discovery (MNDP) явно налаштовано для всіх інтерфейсів, включаючи WAN")
            fixes.append("/ip neighbor discovery-settings set discover-interface-list=LAN")
        elif not mndp_explicitly_set:
            warnings.append("⚠️ Neighbor Discovery не обмежено (за замовчуванням активне на всіх інтерфейсах)")
            fixes.append("/ip neighbor discovery-settings set discover-interface-list=LAN")

        # MAC Winbox: only warn if explicitly present in config and not restricted to LAN
        # If section is absent from export — cannot confirm, do not guess
        if winbox_explicitly_set and not winbox_only_lan:
            warnings.append("⚠️ MAC Winbox Server налаштовано без обмеження за інтерфейсами (не тільки LAN)")
            fixes.append("/tool mac-server mac-winbox set allowed-interface-list=LAN")
        elif not winbox_explicitly_set:
            info.append(
                "ℹ️ Розділ '/tool mac-server mac-winbox' відсутній в експорті — "
                "перевірте вручну: /tool mac-server mac-winbox print"
            )

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditFirewallRuleOrder(AuditPlugin):
    id = "BP-SEC-005"
    category = "security"
    severity = "high"
    confidence = 95
    title = "Firewall Filter Rules Ordering"
    description = "Перевірка послідовності та пріоритету правил фільтрації у файрволі."
    impact = "RouterOS обробляє правила файрволу зверху вниз (First Match). Якщо загальне блокуюче правило розміщено вище дозволяючих правил, корисний трафік буде заблоковано."
    best_practice = "Завжди ставте правила фільтрації стану (accept established,related) першими, за ними дозволяючі правила, і тільки в кінці — блокуючі правила."
    resolution = "Перевпорядкувати чергу правил файрволу."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        # Only analyse active (non-disabled) rules — disabled rules cannot shadow anything
        active_input = [
            r for r in model.firewall_rules
            if r.chain == "input" and not getattr(r, "disabled", False)
        ]

        if not active_input:
            # No active rules — shadowing analysis is meaningless; let AuditFirewallDisabled handle it
            return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

        drop_all_input_idx = -1
        accept_rules_after_drop = False

        for idx, rule in enumerate(active_input):
            is_drop_all = (
                rule.action in ("drop", "reject")
                and not rule.src_address
                and not rule.dst_address
                and not getattr(rule, "src_address_list", None)
                and not getattr(rule, "dst_address_list", None)
                and not rule.dst_port
            )
            if is_drop_all:
                drop_all_input_idx = idx
            elif drop_all_input_idx != -1 and rule.action == "accept":
                accept_rules_after_drop = True
                break

        if accept_rules_after_drop:
            warnings.append(
                "⚠️ Firewall: Виявлено дозволяючі правила input після загального блокуючого правила (shadowing) — вони ніколи не спрацюють"
            )
            fixes.append("/ip firewall filter move [find action=accept chain=input] destination=0")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditNtpMonitoring(AuditPlugin):
    id = "BP-SEC-006"
    category = "security"
    severity = "medium"
    confidence = 90
    title = "System Time & Logging Audit"
    description = "Аналіз налаштувань синхронізації часу (NTP) та ведення системних логів."
    impact = "Без точного системного часу лог-файли роутера матимуть невірні мітки часу, що робить неможливим ретроспективний аналіз інцидентів безпеки та збоїв зв'язку."
    best_practice = "Завжди вмикати та налаштовувати клієнт NTP, а також налаштувати логування критичних подій на віддалений сервер логів (Syslog)."
    resolution = "Увімкнути NTP клієнт та налаштувати сервери синхронізації часу."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        if not model.ntp_enabled:
            warnings.append(
                "⚠️ Службу синхронізації часу NTP вимкнено — лог-файли матимуть неправильні мітки часу"
            )
            fixes.append("/system ntp client set enabled=yes servers=time.google.com,time.cloudflare.com")

        if not model.syslog_enabled:
            info.append(
                "ℹ️ Централізований Syslog не налаштовано — рекомендується для корпоративних мереж "
                "(для домашнього використання не обов'язково)"
            )

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

@registry.register
class AuditBackupScripts(AuditPlugin):
    id = "BP-SEC-007"
    category = "security"
    severity = "medium"
    confidence = 95
    title = "RouterOS Backup & Export Scheduling"
    description = "Перевірка наявності автоматичних скриптів створення резервних копій."
    impact = "У разі апаратного збою або згорання роутера за відсутності актуального бекапу відновлення конфігурації офісу з нуля може тривати дні, спричиняючи простої бізнесу."
    best_practice = "Рекомендується налаштувати регулярний скрипт (наприклад, щотижня) для створення бінарного .backup та текстового .rsc експорту конфігурації з відправкою на email/FTP."
    resolution = "Створити скрипти та планувальники автоматичного резервного копіювання."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        if not model.backup_script_exists:
            info.append(
                "ℹ️ Рекомендується: автоматичний скрипт бінарного бекапу (.backup) не знайдено"
            )
            fixes.append("/system script add name=auto_backup source=\"/system backup save name=auto_backup_file\"")
            fixes.append("/system scheduler add name=sched_backup interval=7d start-time=03:00:00 on-event=auto_backup")

        if not model.rsc_export_script_exists:
            info.append(
                "ℹ️ Рекомендується: автоматичний скрипт текстового експорту (.rsc) не знайдено"
            )
            fixes.append("/system script add name=auto_export source=\"/export file=auto_export_file\"")
            fixes.append("/system scheduler add name=sched_export interval=7d start-time=03:15:00 on-event=auto_export")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}



@registry.register
class AuditFirewallDisabled(AuditPlugin):
    id = "BP-SEC-009"
    category = "security"
    severity = "critical"
    confidence = 99
    title = "IPv4 Firewall Completely Disabled"
    description = "Перевірка чи не вимкнено всі правила IPv4 Firewall одночасно."
    impact = (
        "Якщо всі правила firewall мають disabled=yes, роутер фактично не фільтрує трафік. "
        "Будь-який хост з Інтернету матиме прямий доступ до всіх сервісів (Winbox, SSH, DNS тощо)."
    )
    best_practice = "Завжди мати хоча б мінімальний набір активних правил: accept established/related, drop invalid, drop non-LAN input."
    resolution = "Активувати правила firewall або створити новий базовий набір."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        if not model.firewall_rules:
            # No rules at all
            return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}

        active_rules = [r for r in model.firewall_rules if not getattr(r, "disabled", False)]

        if not active_rules and model.firewall_rules:
            issues.append(
                "❌ КРИТИЧНО: Всі правила IPv4 Firewall вимкнено (disabled=yes) — "
                "роутер повністю відкритий з WAN без будь-якої фільтрації трафіку"
            )
            fixes.append("# Варіант 1: Увімкнути наявні правила:")
            fixes.append("/ip firewall filter enable [find]")
            fixes.append("# Варіант 2: Створити мінімальний безпечний набір правил:")
            fixes.append("/ip firewall filter add chain=input action=accept connection-state=established,related comment=\"Accept established\"")
            fixes.append("/ip firewall filter add chain=input action=accept in-interface-list=LAN comment=\"Accept from LAN\"")
            fixes.append("/ip firewall filter add chain=input action=drop comment=\"Drop all else\"")
            fixes.append("/ip firewall filter add chain=forward action=fasttrack-connection connection-state=established,related hw-offload=yes")
            fixes.append("/ip firewall filter add chain=forward action=accept connection-state=established,related")
            fixes.append("/ip firewall filter add chain=forward action=drop connection-state=invalid")
            fixes.append("/ip firewall filter add chain=forward action=accept in-interface-list=LAN out-interface-list=WAN")
            fixes.append("/ip firewall filter add chain=forward action=drop")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}


@registry.register
class AuditNeighborDiscoveryWan(AuditPlugin):
    id = "BP-SEC-010"
    category = "security"
    severity = "medium"
    confidence = 95
    title = "Neighbor Discovery on WAN"
    description = "Перевірка вимкнення Neighbor Discovery (LLDP/CDP/MNDP) на зовнішніх інтерфейсах."
    impact = "Якщо Neighbor Discovery активний на WAN інтерфейсі, зловмисники можуть отримати відомості про топологію мережі (модель пристрою, версію ОС, сусідні вузли) з публічного інтернету."
    best_practice = "Обмежити Neighbor Discovery виключно списком LAN інтерфейсів: discover-interface-list=LAN."
    resolution = "Вимкнути MNDP на WAN інтерфейсах."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        nd_lines = model.raw_sections.get("/ip neighbor discovery-settings", [])
        for line in nd_lines:
            iface_list = get_param_value(line, "discover-interface-list")
            if iface_list and iface_list.lower() in ("all", ""):
                warnings.append("⚠️ Neighbor Discovery (MNDP/LLDP) активний на всіх інтерфейсах, включаючи WAN — розкриває інформацію про пристрій зовні")
                fixes.append("/ip neighbor discovery-settings set discover-interface-list=LAN")

        if not nd_lines:
            # Default in RouterOS is discover on all — flag as warning
            warnings.append("⚠️ Neighbor Discovery не обмежено (за замовчуванням активне на всіх інтерфейсах)")
            fixes.append("/ip neighbor discovery-settings set discover-interface-list=LAN")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}


@registry.register
class AuditNtpConfiguration(AuditPlugin):
    id = "BP-SEC-011"
    category = "security"
    severity = "low"
    confidence = 90
    title = "NTP Client Configuration"
    description = "Перевірка налаштування NTP клієнта для синхронізації часу."
    impact = "Без коректного часу (NTP) логи матимуть неправильні часові мітки, що унеможливить розслідування інцидентів. Також можуть виникати помилки перевірки TLS/SSL сертифікатів."
    best_practice = "Завжди налаштовувати NTP клієнт з мінімум двома серверами: /system ntp client."
    resolution = "Увімкнути NTP клієнт та вказати сервери."

    def run(self, model: NetworkModel) -> Dict[str, Any]:
        issues, warnings, fixes, info = [], [], [], []

        ntp_lines = model.raw_sections.get("/system ntp client", [])
        ntp_enabled = False
        for line in ntp_lines:
            enabled = get_param_value(line, "enabled")
            if enabled == "yes":
                ntp_enabled = True

        if not ntp_enabled:
            warnings.append("⚠️ NTP клієнт не налаштовано — час роутера може бути некоректним, що впливає на логи та TLS")
            fixes.append("/system ntp client set enabled=yes primary-ntp=0.pool.ntp.org secondary-ntp=1.pool.ntp.org")

        return {"issues": issues, "warnings": warnings, "fixes": fixes, "info": info, "recs": []}
