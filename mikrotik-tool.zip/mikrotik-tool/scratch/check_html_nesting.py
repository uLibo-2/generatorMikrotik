import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# 1. Check all pages active states
print("--- PAGE DIVS AND ACTIVE STATES ---")
pages = re.findall(r'<div[^>]*class="page[^"]*"[^>]*>', html)
for p in pages:
    print(p)

# 2. Check for tag balance of divs in each page section
# Let's count <div> and </div> tags globally, and also see if there's any obvious mismatch
print("\n--- GLOBAL DIV TAG COUNTS ---")
div_opens = len(re.findall(r'<div\b', html))
div_closes = len(re.findall(r'</div>', html))
print(f"Opening <div> tags: {div_opens}")
print(f"Closing </div> tags: {div_closes}")
print(f"Difference: {div_opens - div_closes}")

if div_opens != div_closes:
    print("WARNING: Mismatch in total <div> and </div> tags!")
