import re
import subprocess
import sys

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Extract all scripts
scripts = re.findall(r'<script>(.*?)</script>', html, re.DOTALL)

full_js = "\n".join(scripts)

# Save to temporary file
temp_file = 'scratch/temp_js_check.js'
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(full_js)

print("Running node syntax check on extracted JavaScript...")
res = subprocess.run(['node', '--check', temp_file], capture_output=True, text=True)

if res.returncode == 0:
    print("JavaScript syntax is VALID!")
else:
    print("JavaScript syntax is INVALID:")
    print(res.stderr)
    sys.exit(1)
