import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

subtabs = [
    ("advisor", 'id="subtab-design-advisor"', 'id="subtab-design-generator"'),
    ("generator", 'id="subtab-design-generator"', 'id="subtab-design-packet-trace"'),
    ("packet-trace", 'id="subtab-design-packet-trace"', '<!-- Right Column: Outputs -->')
]

for name, start_query, end_query in subtabs:
    start_pos = html.find(start_query)
    end_pos = html.find(end_query)
    if start_pos == -1 or end_pos == -1:
        print(f"Failed to find boundaries for {name}!")
        continue
        
    sub_html = html[start_pos:end_pos]
    opens = len(re.findall(r'<div\b', sub_html))
    closes = len(re.findall(r'</div>', sub_html))
    diff = opens - closes
    
    # Let's count tags in lines
    start_line = html.count('\n', 0, start_pos) + 1
    end_line = html.count('\n', 0, end_pos) + 1
    print(f"Subtab: {name:15s} | Lines: {start_line:4d}-{end_line:4d} | Opens: {opens:3d} | Closes: {closes:3d} | Diff: {diff:3d}")
