import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

import re
print("Matches for 'page-audit':")
for match in re.finditer(r'.{0,100}page-audit.{0,100}', html):
    print(match.group(0).strip())
