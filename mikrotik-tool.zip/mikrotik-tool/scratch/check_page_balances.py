import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Find all indices of page starts
page_matches = list(re.finditer(r'<div[^>]*class="page[^"]*"[^>]*id="([^"]*)"[^>]*>', html))
print(f"Found {len(page_matches)} pages.")

# Convert position to line number
def get_line(pos):
    return html.count('\n', 0, pos) + 1

for idx, match in enumerate(page_matches):
    start_pos = match.start()
    page_id = match.group(1)
    
    # End pos is the start of the next page, or the end of the file (or rather, where the script tag starts)
    if idx + 1 < len(page_matches):
        end_pos = page_matches[idx+1].start()
    else:
        # find the script tag start
        script_match = re.search(r'<script>', html[start_pos:])
        if script_match:
            end_pos = start_pos + script_match.start()
        else:
            end_pos = len(html)
            
    page_html = html[start_pos:end_pos]
    
    # Count opens and closes inside this page block
    # We should exclude self-closing divs if there are any (though standard divs are not self-closing)
    opens = len(re.findall(r'<div\b', page_html))
    closes = len(re.findall(r'</div>', page_html))
    diff = opens - closes
    
    print(f"Page: {page_id:15s} | Lines: {get_line(start_pos):4d}-{get_line(end_pos):4d} | Opens: {opens:3d} | Closes: {closes:3d} | Diff: {diff:3d}")
