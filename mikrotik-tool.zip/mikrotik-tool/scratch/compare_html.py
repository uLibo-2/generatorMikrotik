import sys
import difflib

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    current = f.readlines()

with open('_archive_upgraded/mikrotik-tool-upgraded/static/index.html', 'r', encoding='utf-8') as f:
    archive = f.readlines()

# Let's find runCompilerPipeline in both
current_idx = -1
for idx, line in enumerate(current):
    if 'runCompilerPipeline' in line:
        current_idx = idx
        break

archive_idx = -1
for idx, line in enumerate(archive):
    if 'runCompilerPipeline' in line:
        archive_idx = idx
        break

print(f"Current index: {current_idx}, Archive index: {archive_idx}")

if current_idx != -1 and archive_idx != -1:
    curr_chunk = current[current_idx-50:current_idx+400]
    arch_chunk = archive[archive_idx-50:archive_idx+250]
    
    print("\n--- DIFF OF runCompilerPipeline ---")
    diff = difflib.unified_diff(arch_chunk, curr_chunk, fromfile='archive', tofile='current', n=3)
    for d_line in diff:
        print(d_line, end="")
else:
    print("Could not find function in one of the files.")
