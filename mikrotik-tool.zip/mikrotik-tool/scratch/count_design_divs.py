import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

start_pos = html.find('id="page-design"')
end_pos = html.find('id="page-compiler"')

design_html = html[start_pos:end_pos]

div_opens = [m.start() + start_pos for m in re.finditer(r'<div\b', design_html)]
div_closes = [m.start() + start_pos for m in re.finditer(r'</div>', design_html)]

def get_line(pos):
    return html.count('\n', 0, pos) + 1

print(f"Total Opening <div>s: {len(div_opens)}")
print(f"Total Closing </div>s: {len(div_closes)}")

print("\n--- FIRST 20 OPENING DIVS ---")
for idx, pos in enumerate(div_opens[:20]):
    line = get_line(pos)
    snippet = html[pos:pos+60].replace('\n', ' ')
    print(f"Open {idx+1} at line {line}: {snippet}")

print("\n--- LAST 20 CLOSING DIVS ---")
for idx, pos in enumerate(div_closes[-20:]):
    line = get_line(pos)
    snippet = html[pos-30:pos+6].replace('\n', ' ')
    print(f"Close {len(div_closes)-20+idx+1} at line {line}: ... {snippet}")
