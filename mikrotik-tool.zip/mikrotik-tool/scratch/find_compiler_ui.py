import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

for idx, line in enumerate(lines):
    if 'compiler-target-device' in line or 'compiler-target-subnet' in line:
        print(f"Line {idx+1}: {line.strip()}")
