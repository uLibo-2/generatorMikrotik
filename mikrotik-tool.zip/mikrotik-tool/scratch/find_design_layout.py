import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Let's find all occurrences of class="design-subtab-content" or similar subtab containers
# under page-design
matches = list(re.finditer(r'<div[^>]*id="([^"]*subtab[^"]*|[^"]*design-tpl[^"]*|[^"]*design-ip[^"]*|[^"]*design-clone[^"]*|[^"]*design-extractor[^"]*|[^"]*design-bulk[^"]*|[^"]*design-comp[^"]*|[^"]*design-blueprint[^"]*|[^"]*design-expert[^"]*)"[^>]*>', html))

print("--- SUBTABS IN index.html ---")
for m in matches:
    pos = m.start()
    line_no = html.count('\n', 0, pos) + 1
    print(f"Subtab: {m.group(1):25s} at line {line_no} | Raw: {m.group(0).strip()}")
