import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

import re

# 1. Print all occurrences of class="page" with their ids
print("--- ALL PAGES ---")
for match in re.finditer(r'<div[^>]*class="page"[^>]*id="([^"]*)"[^>]*>', html):
    print(match.group(0))

# 2. Find goto function definition
print("\n--- GOTO FUNCTION ---")
goto_match = re.search(r'function goto\((.*?)\)\s*\{(.*?)\}', html, re.DOTALL)
if goto_match:
    print(goto_match.group(0))
else:
    # search for goto = function
    goto_match2 = re.search(r'goto\s*=\s*function.*', html)
    if goto_match2:
        print(html[goto_match2.start():goto_match2.start()+300])
    else:
        # just print matches of "function goto"
        for m in re.finditer(r'function\s+goto\b', html):
            start = max(0, m.start() - 50)
            end = min(len(html), m.end() + 200)
            print(f"Match around index {m.start()}:\n", html[start:end])
