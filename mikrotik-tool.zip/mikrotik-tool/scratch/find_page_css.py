import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

import re
print("Matches for CSS .page:")
for match in re.finditer(r'\.page\s*\{.*?\}', html, re.DOTALL):
    print(match.group(0))

print("\nMatches for .page.active:")
for match in re.finditer(r'\.page\.active\s*\{.*?\}', html, re.DOTALL):
    print(match.group(0))
