import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Let's count open divs before page-compiler to find parent hierarchy
import re
compiler_pos = html.find('id="page-compiler"')
if compiler_pos == -1:
    print("page-compiler not found!")
    sys.exit(1)

# We want to trace all tags up to compiler_pos
# We can do this by keeping a stack of open tags
stack = []
pos = 0
# Regex to match tags
tag_regex = re.compile(r'<(/?[a-zA-Z0-9:-]+)(?:\s+[^>]*)?>')

for match in tag_regex.finditer(html[:compiler_pos]):
    tag_name = match.group(1)
    if tag_name.startswith('/'):
        tag_name = tag_name[1:]
        # pop from stack
        if stack and stack[-1][0] == tag_name:
            stack.pop()
    else:
        # Check if self-closing
        if not match.group(0).endswith('/>') and tag_name not in ['img', 'br', 'hr', 'input', 'link', 'meta']:
            stack.append((tag_name, match.start(), html[match.start():match.end()]))

print("--- PARENT STACK OF page-compiler ---")
for idx, (tag, start, raw) in enumerate(stack):
    # Print line number
    line_no = html.count('\n', 0, start) + 1
    print(f"Level {idx+1}: <{tag}> at line {line_no} | Raw: {raw.strip()}")
