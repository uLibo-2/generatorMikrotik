import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

match = re.search(r'function showDesignSubtab\((.*?)\)\s*\{(.*?)\}', html, re.DOTALL)
if match:
    print(match.group(0))
else:
    # try searching with other patterns
    m2 = re.search(r'showDesignSubtab\s*=\s*function|function\s+\w*DesignSubtab', html)
    if m2:
        print(html[m2.start():m2.start()+500])
    else:
        print("showDesignSubtab not found!")
