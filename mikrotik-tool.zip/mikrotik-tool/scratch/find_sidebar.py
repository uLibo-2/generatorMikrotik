import sys
sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

# Let's find occurrences of sidebar nav items
import re
print("--- SIDEBAR NAV ITEMS ---")
for match in re.finditer(r'<div class="nav-item[^"]*"[^>]*onclick="[^"]*"[^>]*>.*?</div>', html, re.DOTALL):
    print(match.group(0).strip())

print("\n--- PAGES ---")
for match in re.finditer(r'<div class="page"[^>]*id="[^"]*"[^>]*>', html):
    print(match.group(0).strip())

print("\n--- SHOWPAGE FUNCTION ---")
js_match = re.search(r'function showPage\((.*?)\)\s*\{(.*?)\}', html, re.DOTALL)
if js_match:
    print(js_match.group(0))
else:
    print("showPage function not found as written. Searching with general regex...")
    js_match2 = re.search(r'showPage\s*=\s*function|function\s+\w*page\w*|switchTab', html, re.IGNORECASE)
    if js_match2:
        start = max(0, js_match2.start() - 100)
        end = min(len(html), js_match2.end() + 500)
        print(html[start:end])
