import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

log_path = r"C:\Users\Admin\.gemini\antigravity\brain\b771ec97-5df9-405a-af5c-a95fd8cccfc4\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        try:
            data = json.loads(line)
            if data.get('step_index') == 2268:
                tc = data.get('tool_calls', [])[0]
                args = tc.get('args', {})
                rc_str = args.get('ReplacementChunks')
                if isinstance(rc_str, str):
                    rc = json.loads(rc_str, strict=False) # set strict=False
                    print("Number of chunks:", len(rc))
                    for i, chunk in enumerate(rc):
                        print(f"\n--- CHUNK {i+1} (lines {chunk.get('StartLine')}-{chunk.get('EndLine')}) ---")
                        print("TargetContent:")
                        print(chunk.get('TargetContent'))
                        print("ReplacementContent:")
                        print(chunk.get('ReplacementContent'))
        except Exception as e:
            print("Error parsing line:", e)
