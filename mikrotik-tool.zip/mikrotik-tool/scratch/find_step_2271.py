import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

log_path = r"C:\Users\Admin\.gemini\antigravity\brain\b771ec97-5df9-405a-af5c-a95fd8cccfc4\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        try:
            data = json.loads(line)
            if data.get('step_index') == 2271:
                print("--- STEP 2271 TOOL CALLS ---")
                tool_calls = data.get('tool_calls', [])
                for tc in tool_calls:
                    # Print keys
                    print("Keys in tool_call:", tc.keys())
                    # Print the arguments
                    args = tc.get('args') or tc.get('arguments')
                    if args:
                        print("Args keys:", args.keys())
                        chunks = args.get('ReplacementChunks') or args.get('chunks')
                        if chunks:
                            print(f"Found {len(chunks)} chunks")
                            for idx, c in enumerate(chunks):
                                print(f"Chunk {idx+1}: {c.keys()}")
                                print("StartLine:", c.get('StartLine'))
                                print("EndLine:", c.get('EndLine'))
                                print("TargetContent (first 200 chars):")
                                print(repr(c.get('TargetContent')[:200]))
                                print("ReplacementContent (first 200 chars):")
                                print(repr(c.get('ReplacementContent')[:200]))
                        else:
                            print("TargetContent (first 200 chars):")
                            print(repr(args.get('TargetContent')[:200]))
                            print("ReplacementContent (first 200 chars):")
                            print(repr(args.get('ReplacementContent')[:200]))
        except Exception as e:
            pass
