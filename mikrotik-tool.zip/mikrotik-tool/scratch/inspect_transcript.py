import sys
sys.stdout.reconfigure(encoding='utf-8')

log_path = r"C:\Users\Admin\.gemini\antigravity\brain\b771ec97-5df9-405a-af5c-a95fd8cccfc4\.system_generated\logs\transcript.jsonl"

with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
    for idx in range(10):
        line = f.readline()
        if not line:
            break
        print(f"Line {idx+1}: {line[:300]}...")
