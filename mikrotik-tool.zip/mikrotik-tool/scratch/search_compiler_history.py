import os
import zipfile
import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

print("Searching files in current folder...")
for root, dirs, files in os.walk('.'):
    # skip node_modules and .git
    if 'node_modules' in root or '.git' in root or '.gemini' in root:
        continue
    for file in files:
        if file.endswith('.html') or file.endswith('.js') or file.endswith('.py'):
            path = os.path.join(root, file)
            try:
                with open(path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                if 'runCompilerPipeline' in content:
                    print(f"Found in: {path}")
            except Exception as e:
                pass

print("\nSearching inside ZIP files...")
for file in os.listdir('.'):
    if file.endswith('.zip'):
        print(f"Checking zip: {file}")
        try:
            with zipfile.ZipFile(file, 'r') as z:
                for name in z.namelist():
                    if name.endswith('.html') or name.endswith('.js') or name.endswith('.py'):
                        try:
                            with z.open(name) as f:
                                content = f.read().decode('utf-8', errors='ignore')
                            if 'runCompilerPipeline' in content:
                                print(f"  Found in zip member: {name}")
                        except Exception as e:
                            pass
        except Exception as e:
            print(f"Error reading zip {file}: {e}")
