import sys
if sys.platform.startswith('win'):
    sys.stdout.reconfigure(encoding='utf-8')

with open("static/index.html", "r", encoding="utf-8") as f:
    for i, line in enumerate(f, 1):
        if 'function runCompare' in line or 'function compare' in line or 'function loadDesignTemplates' in line:
            print(f"{i}: {line.strip()[:150]}")
