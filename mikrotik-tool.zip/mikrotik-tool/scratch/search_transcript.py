import json
import os
import sys

sys.stdout.reconfigure(encoding='utf-8')

log_path = r"C:\Users\Admin\.gemini\antigravity\brain\b771ec97-5df9-405a-af5c-a95fd8cccfc4\.system_generated\logs\transcript.jsonl"

if not os.path.exists(log_path):
    print("Transcript not found at:", log_path)
    sys.exit(1)

print("Reading edits to index.html from transcript...")
with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
    for line in f:
        try:
            data = json.loads(line)
            tool_calls = data.get('tool_calls', [])
            for tc in tool_calls:
                func_name = tc.get('name')
                args = tc.get('args', {}) # changed arguments -> args
                target = args.get('TargetFile') or args.get('Target') or ""
                if 'index.html' in target:
                    step = data.get('step_index')
                    print(f"\n================ STEP {step} ({func_name}) ================")
                    desc = args.get('Description') or args.get('Instruction') or ""
                    print(f"Description: {desc}")
                    chunks = args.get('ReplacementChunks', [])
                    if chunks:
                        print(f"Number of chunks: {len(chunks)}")
                        for c_idx, chunk in enumerate(chunks):
                            print(f"  Chunk {c_idx+1} lines {chunk.get('StartLine')}-{chunk.get('EndLine')}")
                            print(f"    TargetContent: {repr(chunk.get('TargetContent')[:100])}")
                            print(f"    ReplacementContent: {repr(chunk.get('ReplacementContent')[:120])}")
                    elif 'ReplacementContent' in args:
                        print(f"Single chunk lines {args.get('StartLine')}-{args.get('EndLine')}")
                        print(f"  TargetContent: {repr(args.get('TargetContent')[:100])}")
                        print(f"  ReplacementContent: {repr(args.get('ReplacementContent')[:120])}")
                    elif 'CodeContent' in args:
                        print("Write file code content (full write):")
                        print(f"  CodeContent length: {len(args.get('CodeContent'))}")
        except Exception as e:
            pass
