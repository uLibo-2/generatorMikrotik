
const API = 'http://localhost:8899/api';
let currentAuditData = null;
let allKb = [];

// ── Navigation ──
const pageMap = {
  audit: { title: 'Config Audit', sub: 'Повний аналіз конфігурації RouterOS v7' },
  vlan: { title: 'VLAN Validator', sub: 'Перевірка Bridge VLAN Filtering' },
  wifi: { title: 'WiFi Analyzer', sub: 'Аналіз WiFi конфігурації та рекомендації' },
  capsman: { title: 'CAPsMAN Auditor', sub: 'Аудит CAPsMAN / WiFi (v7)' },
  trouble: { title: 'Troubleshooting Assistant', sub: 'Діагностика мережевих проблем' },
  generate: { title: 'Config Generator', sub: 'Генерація RouterOS v7 конфігурацій' },
  compare: { title: 'Порівняння конфігів', sub: 'Аналіз різниці між двома файлами налаштувань' },
  design: { title: 'Проектування & Генерація', sub: 'Проектування VLAN/IP, генерація та клонування рішень MikroTik RouterOS' },
  policy: { title: 'Регламент компанії', sub: 'Обовʼязкові параметри конфігурації' },
  knowledge: { title: 'Knowledge Base', sub: 'База знань та рішень' },
  history: { title: 'Історія аудитів', sub: 'Попередні результати аналізу' },
  compiler: { title: 'Компілятор конфігурацій', sub: 'Трансляція, апаратна міграція, оптимізація та аналіз безпеки' },
  wiki: { title: 'Енциклопедія моделей', sub: 'Характеристики пристроїв, можливості та опис MikroTik' },
};

function goto(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.getElementById('page-' + page).classList.add('active');
  document.querySelector(`[onclick="goto('${page}')"]`).classList.add('active');
  document.getElementById('page-title').textContent = pageMap[page].title;
  document.getElementById('page-sub').textContent = pageMap[page].sub;
  if (page === 'knowledge') loadKnowledge();
  if (page === 'history') loadHistory();
  if (page === 'policy') loadPolicy();
  if (page === 'design') loadDesignTemplates();
  if (page === 'wiki') loadWikiModels();
}

// ── Tab switching ──
function showTab(tabId, group) {
  document.querySelectorAll(`[id^="tab-"]`).forEach(t => { if(t.closest(`#page-${group}`)) t.style.display = 'none'; });
  document.querySelectorAll('.result-tab').forEach(t => t.classList.remove('active'));
  document.getElementById(tabId).style.display = 'block';
  event.target.classList.add('active');
}

function copyText(t) {
  navigator.clipboard.writeText(t.trim()).then(() => showToast('Скопійовано в буфер обміну!'));
}

function copyAllFixes() {
  const blocks = document.querySelectorAll('#fixes-list .fix-cmd');
  const cmds = Array.from(blocks).map(b => b.textContent.trim()).filter(Boolean);
  if (!cmds.length) { showToast('Немає команд для копіювання'); return; }
  navigator.clipboard.writeText(cmds.join('\n')).then(() => showToast('Всі ' + cmds.length + ' команд скопійовано!'));
}

function highlightROS(text) {
  if (!text) return "";
  const lines = text.split("\n");
  const highlighted = lines.map(line => {
    let trimmed = line.trim();
    if (!trimmed) return "";
    if (trimmed.startsWith("#")) {
      return `<span style="color: var(--text3); font-style: italic;">${escHtml(line)}</span>`;
    }
    if (trimmed.startsWith("/")) {
      return `<span style="color: var(--accent); font-weight: 600;">${escHtml(line)}</span>`;
    }
    
    let replaced = escHtml(line);
    
    // Highlight parameter assignments (param="value" or param=value)
    replaced = replaced.replace(/([a-zA-Z0-9.-]+)=(&quot;([^&]*)&quot;|([^\s&]+))/g, (match, p1, p2) => {
      return `<span style="color: var(--orange);">${p1}</span>=<span style="color: var(--green);">${p2}</span>`;
    });
    
    // Highlight command verbs
    if (trimmed.startsWith("add ") || trimmed.startsWith("set ") || trimmed.startsWith("remove ") || trimmed.startsWith("enable ") || trimmed.startsWith("disable ")) {
      let verb = trimmed.split(" ")[0];
      replaced = replaced.replace(new RegExp(`\\b${verb}\\b`), `<span style="color: var(--teal); font-weight: 600;">${verb}</span>`);
    }
    
    return replaced;
  });
  return highlighted.join("\n");
}

async function loadSampleConfig() {
  try {
    const r = await fetch(`${API}/sample-config`);
    const data = await r.json();
    document.getElementById('audit-config').value = data.config;
    showToast('Завантажено зразкову конфігурацію!');
  } catch(e) {
    showToast('Помилка завантаження зразкової конфігурації');
  }
}

async function exportReport() {
  const config = document.getElementById('audit-config').value.trim();
  if (!config) return;
  try {
    const r = await fetch(`${API}/report/generate`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config, filename: 'report'})
    });
    const data = await r.json();
    
    // Download plain text file
    const blob = new Blob([data.report], {type:'text/plain'});
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'mikrotik_audit_report.txt';
    a.click();
    showToast('Звіт експортовано успішно!');
  } catch(e) {
    showToast('Помилка експорту звіту');
  }
}

function animateValue(id, start, end, duration) {
  const obj = document.getElementById(id);
  if (!obj) return;
  let startTimestamp = null;
  const step = (timestamp) => {
    if (!startTimestamp) startTimestamp = timestamp;
    const progress = Math.min((timestamp - startTimestamp) / duration, 1);
    obj.innerHTML = Math.floor(progress * (end - start) + start);
    if (progress < 1) {
      window.requestAnimationFrame(step);
    }
  };
  window.requestAnimationFrame(step);
}

// ── Helpers ──
function issueHtml(items, cls) {
  return items.map(i => `<div class="issue-item ${cls}">${escHtml(i)}</div>`).join('');
}

function fixHtml(fixes) {
  return fixes.map(f => `
    <div class="fix-block">
      <button class="copy-btn" onclick="copyText(this.nextElementSibling.textContent)">📋 Copy</button>
      <div>${escHtml(f)}</div>
    </div>
  `).join('');
}

function escHtml(s) {
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}

function showToast(msg) {
  // Clear any existing toast first
  const existing = document.querySelector('.custom-toast');
  if (existing) existing.remove();

  const t = document.createElement('div');
  t.className = 'custom-toast';
  t.innerHTML = `<span>ℹ️</span> <span>${msg}</span>`;
  document.body.appendChild(t);
  
  // Force a reflow to trigger slide animation
  t.offsetHeight;
  
  t.classList.add('show');
  setTimeout(() => {
    t.classList.remove('show');
    setTimeout(() => t.remove(), 400);
  }, 2500);
}

function scoreColor(s) { return s >= 80 ? 'green' : s >= 50 ? 'yellow' : 'red'; }

// ── Audit ──
async function runAudit() {
  const config = document.getElementById('audit-config').value.trim();
  if (!config) { showToast('Вставте конфіг'); return; }
  document.getElementById('audit-results').style.display = 'none';
  showLoading('audit-results');
  try {
    const r = await fetch(`${API}/analyze`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config, filename: 'manual-paste'})
    });
    const data = await r.json();
    hideLoading();
    renderAudit(data);
  } catch(e) { hideLoading(); showToast('Помилка з\'єднання з сервером'); }
}

async function uploadFile(input) {
  const file = input.files[0];
  if (!file) return;
  const fd = new FormData();
  fd.append('file', file);
  showLoading('audit-results');
  try {
    const r = await fetch(`${API}/analyze/upload`, { method: 'POST', body: fd });
    const data = await r.json();
    hideLoading();
    const text = await file.text().catch(() => '');
    if (text) document.getElementById('audit-config').value = text;
    renderAudit(data);
  } catch(e) { hideLoading(); showToast('Помилка завантаження файлу'); }
}

function renderAudit(data) {
  currentAuditData = data;
  const s = data.summary;
  const sc = scoreColor(s.score);
  const desc = s.score >= 80 ? "Конфігурація безпечна та оптимізована за стандартами ROS v7." : s.score >= 50 ? "Виявлено деякі зауваження до безпеки чи продуктивності мережі." : "Увага! Виявлено критичні проблеми з безпекою чи топологією VLAN!";

  // Show export report button
  document.getElementById('export-report-btn').style.display = 'inline-flex';

  document.getElementById('audit-summary').innerHTML = `
    <div class="premium-score-card">
      <div class="score-gauge">
        <svg class="gauge-svg" viewBox="0 0 100 100">
          <circle class="gauge-bg" cx="50" cy="50" r="40"></circle>
          <circle class="gauge-fill" id="score-fill" cx="50" cy="50" r="40" style="stroke-dashoffset: 251.2; stroke: var(--${sc});"></circle>
        </svg>
        <div class="gauge-text">
          <div class="score-num" id="score-val">0</div>
          <div class="score-label">Score</div>
        </div>
      </div>
      <div style="flex: 1; margin-left: 20px;">
        <h3 style="font-size: 15px; font-weight: 700; color: var(--text);">Загальна оцінка: <span style="color:var(--${sc})">${s.score}/100</span></h3>
        <p style="font-size: 12.5px; color: var(--text2); margin-top: 6px; line-height: 1.4;">${desc}</p>
      </div>
    </div>
    <div class="summary-card"><div class="val red" id="summary-issues">0</div><div class="lbl">Критичних помилок</div></div>
    <div class="summary-card"><div class="val yellow" id="summary-warnings">0</div><div class="lbl">Попереджень</div></div>
    <div class="summary-card"><div class="val blue" id="summary-vlans">0</div><div class="lbl">VLAN знайдено</div></div>
    ${(data.compliance && data.compliance.violations && data.compliance.violations.length > 0) ? `<div class="summary-card" onclick="showTab('tab-compliance','audit')" style="cursor:pointer"><div class="val" style="color:var(--orange)" id="summary-compliance">0</div><div class="lbl">Порушень регламенту</div></div>` : ''}
  `;

  // Animate circular gauge and counters
  setTimeout(() => {
    const circle = document.getElementById('score-fill');
    if (circle) {
      const offset = 251.2 - (251.2 * s.score) / 100;
      circle.style.strokeDashoffset = offset;
    }
    animateValue("score-val", 0, s.score, 800);
    animateValue("summary-issues", 0, s.total_issues, 800);
    animateValue("summary-warnings", 0, s.total_warnings, 800);
    animateValue("summary-vlans", 0, (data.vlan.vlan_ids||[]).length, 800);
    if (data.compliance && data.compliance.violations && data.compliance.violations.length > 0) {
      animateValue("summary-compliance", 0, data.compliance.violations.length, 800);
    }
  }, 100);

  // Overview List
  const overviewEl = document.getElementById('overview-list');
  const allIssuesList = [
    ...data.vlan.issues, ...(data.dhcp ? data.dhcp.issues : []), ...(data.routing ? data.routing.issues : []), ...data.wifi.issues, ...data.capsman.issues, ...data.security.issues,
    ...(data.l2 ? data.l2.issues : []), ...(data.vlan_ext ? data.vlan_ext.issues : []), ...(data.dhcp_ext ? data.dhcp_ext.issues : []), ...(data.capsman_ext ? data.capsman_ext.issues : []), ...(data.wifi_ext ? data.wifi_ext.issues : []), ...(data.firewall ? data.firewall.issues : []), ...(data.multiwan ? data.multiwan.issues : []), ...(data.script ? data.script.issues : []), ...(data.security_ext ? data.security_ext.issues : []), ...(data.monitoring ? data.monitoring.issues : []), ...(data.backup ? data.backup.issues : []), ...(data.services ? data.services.issues : []), ...(data.performance_ext ? data.performance_ext.issues : [])
  ];
  const allWarningsList = [
    ...data.vlan.warnings, ...(data.dhcp ? data.dhcp.warnings : []), ...(data.routing ? data.routing.warnings : []), ...data.wifi.warnings, ...data.capsman.warnings, ...data.security.warnings, ...data.performance.warnings,
    ...(data.l2 ? data.l2.warnings : []), ...(data.vlan_ext ? data.vlan_ext.warnings : []), ...(data.dhcp_ext ? data.dhcp_ext.warnings : []), ...(data.capsman_ext ? data.capsman_ext.warnings : []), ...(data.wifi_ext ? data.wifi_ext.warnings : []), ...(data.firewall ? data.firewall.warnings : []), ...(data.multiwan ? data.multiwan.warnings : []), ...(data.script ? data.script.warnings : []), ...(data.security_ext ? data.security_ext.warnings : []), ...(data.monitoring ? data.monitoring.warnings : []), ...(data.backup ? data.backup.warnings : []), ...(data.services ? data.services.warnings : []), ...(data.performance_ext ? data.performance_ext.warnings : [])
  ];
  const allRecsList = [
    ...(data.wifi.recommendations||[]), ...(data.security.recommendations||[]), ...(data.performance.recommendations||[]),
    ...(data.performance_ext ? data.performance_ext.recommendations : [])
  ];
  const allInfosList = [
    ...data.vlan.info, ...(data.dhcp ? data.dhcp.info : []), ...(data.routing ? data.routing.info : []), ...data.wifi.info, ...data.capsman.info, ...data.security.info,
    ...(data.l2 ? data.l2.info : []), ...(data.vlan_ext ? data.vlan_ext.info : []), ...(data.dhcp_ext ? data.dhcp_ext.info : []), ...(data.capsman_ext ? data.capsman_ext.info : []), ...(data.wifi_ext ? data.wifi_ext.info : []), ...(data.firewall ? data.firewall.info : []), ...(data.multiwan ? data.multiwan.info : []), ...(data.script ? data.script.info : []), ...(data.security_ext ? data.security_ext.info : []), ...(data.monitoring ? data.monitoring.info : []), ...(data.backup ? data.backup.info : []), ...(data.services ? data.services.info : []), ...(data.performance_ext ? data.performance_ext.info : [])
  ];

  // Prominent Ready Badge
  const isReady = data.production_readiness.verdict === 'READY';
  const verdictBadge = isReady 
    ? `<div style="display:inline-flex;align-items:center;padding:8px 16px;background:rgba(46,204,113,0.15);color:var(--green);border:1px solid var(--green);border-radius:20px;font-size:13px;font-weight:700;margin-bottom:16px"><span style="margin-right:8px">🚀</span> ГОТОВИЙ ДО ЕКСПЛУАТАЦІЇ (PRODUCTION READY)</div>`
    : `<div style="display:inline-flex;align-items:center;padding:8px 16px;background:rgba(231,76,60,0.15);color:var(--red);border:1px solid var(--red);border-radius:20px;font-size:13px;font-weight:700;margin-bottom:16px"><span style="margin-right:8px">⚠️</span> НЕ ГОТОВИЙ ДО ЕКСПЛУАТАЦІЇ (NOT READY FOR PRODUCTION)</div>`;

  let critFailuresHtml = '';
  if (data.production_readiness.critical_failures && data.production_readiness.critical_failures.length > 0) {
    critFailuresHtml = '<div style="margin-top:8px;margin-bottom:16px;">' +
      data.production_readiness.critical_failures.map(cf => `<div class="issue-item error" style="margin-bottom:6px;font-weight:600">${escHtml(cf)}</div>`).join('') +
      '</div>';
  }

  if (allIssuesList.length === 0 && allWarningsList.length === 0 && allRecsList.length === 0) {
    overviewEl.innerHTML = verdictBadge + critFailuresHtml + '<div class="issue-item info">✅ Проблем не знайдено — конфігурація виглядає коректно</div>';
  } else {
    overviewEl.innerHTML = verdictBadge + critFailuresHtml +
      allIssuesList.map(i => `<div class="issue-item error">${escHtml(i)}</div>`).join('') +
      allWarningsList.map(i => `<div class="issue-item warning">${escHtml(i)}</div>`).join('') +
      allRecsList.map(i => `<div class="issue-item rec">${escHtml(i)}</div>`).join('') +
      allInfosList.map(i => `<div class="issue-item info">${escHtml(i)}</div>`).join('');
  }

  // L2
  if (data.l2) {
    document.getElementById('l2-issues').innerHTML =
      issueHtml(data.l2.issues, 'error') +
      issueHtml(data.l2.warnings, 'warning') +
      issueHtml(data.l2.info, 'info') ||
      '<div class="issue-item info">✅ L2 OK</div>';
  }

  // VLAN
  document.getElementById('vlan-issues').innerHTML =
    issueHtml(data.vlan.issues, 'error') +
    issueHtml(data.vlan.warnings, 'warning') +
    issueHtml(data.vlan.info, 'info') ||
    '<div class="issue-item info">✅ VLAN OK</div>';

  // DHCP
  if (data.dhcp) {
    document.getElementById('dhcp-issues').innerHTML =
      issueHtml(data.dhcp.issues, 'error') +
      issueHtml(data.dhcp.warnings, 'warning') +
      issueHtml(data.dhcp.info, 'info') ||
      '<div class="issue-item info">✅ DHCP OK</div>';
  }

  // Routing
  if (data.routing) {
    document.getElementById('routing-issues').innerHTML =
      issueHtml(data.routing.issues, 'error') +
      issueHtml(data.routing.warnings, 'warning') +
      issueHtml(data.routing.info, 'info') ||
      '<div class="issue-item info">✅ Routing OK</div>';
  }

  // MultiWAN
  if (data.multiwan) {
    document.getElementById('multiwan-issues').innerHTML =
      issueHtml(data.multiwan.issues, 'error') +
      issueHtml(data.multiwan.warnings, 'warning') +
      issueHtml(data.multiwan.info, 'info') ||
      '<div class="issue-item info">✅ MultiWAN OK</div>';
  }

  // WiFi
  document.getElementById('wifi-issues').innerHTML =
    issueHtml(data.wifi.issues, 'error') +
    issueHtml(data.wifi.warnings, 'warning') +
    issueHtml(data.wifi.recommendations||[], 'rec') +
    issueHtml(data.wifi.info, 'info') ||
    '<div class="issue-item info">✅ WiFi OK</div>';

  // CAPsMAN
  document.getElementById('caps-issues').innerHTML =
    issueHtml(data.capsman.issues, 'error') +
    issueHtml(data.capsman.warnings, 'warning') +
    issueHtml(data.capsman.info, 'info') ||
    '<div class="issue-item info">✅ CAPsMAN OK</div>';

  // Firewall
  if (data.firewall) {
    document.getElementById('firewall-issues').innerHTML =
      issueHtml(data.firewall.issues, 'error') +
      issueHtml(data.firewall.warnings, 'warning') +
      issueHtml(data.firewall.info, 'info') ||
      '<div class="issue-item info">✅ Firewall OK</div>';
  }

  // Security
  document.getElementById('sec-issues').innerHTML =
    issueHtml(data.security.issues, 'error') +
    issueHtml(data.security.warnings, 'warning') +
    issueHtml(data.security.recommendations||[], 'rec') +
    issueHtml(data.security.info, 'info') ||
    '<div class="issue-item info">✅ Безпека OK</div>';

  // Scripts
  if (data.script) {
    document.getElementById('script-issues').innerHTML =
      issueHtml(data.script.issues, 'error') +
      issueHtml(data.script.warnings, 'warning') +
      issueHtml(data.script.info, 'info') ||
      '<div class="issue-item info">✅ Scripts OK</div>';
  }

  // Monitoring
  if (data.monitoring) {
    document.getElementById('monitoring-issues').innerHTML =
      issueHtml(data.monitoring.issues, 'error') +
      issueHtml(data.monitoring.warnings, 'warning') +
      issueHtml(data.monitoring.info, 'info') ||
      '<div class="issue-item info">✅ Monitoring OK</div>';
  }

  // Backup
  if (data.backup) {
    document.getElementById('backup-issues').innerHTML =
      issueHtml(data.backup.issues, 'error') +
      issueHtml(data.backup.warnings, 'warning') +
      issueHtml(data.backup.info, 'info') ||
      '<div class="issue-item info">✅ Backup OK</div>';
  }

  // Services
  if (data.services) {
    document.getElementById('services-issues').innerHTML =
      issueHtml(data.services.issues, 'error') +
      issueHtml(data.services.warnings, 'warning') +
      issueHtml(data.services.info, 'info') ||
      '<div class="issue-item info">✅ Services OK</div>';
  }

  // Performance
  document.getElementById('perf-issues').innerHTML =
    issueHtml(data.performance.warnings, 'warning') +
    issueHtml(data.performance.recommendations||[], 'rec') +
    issueHtml(data.performance.info, 'info') ||
    '<div class="issue-item info">✅ Performance OK</div>';

  // Fixes
  const allFixes = [
    ...(data.vlan.fixes||[]),
    ...(data.capsman.fixes||[]),
    ...(data.l2 ? data.l2.fixes : []),
    ...(data.dhcp_ext ? data.dhcp_ext.fixes : []),
    ...(data.capsman_ext ? data.capsman_ext.fixes : []),
    ...(data.wifi_ext ? data.wifi_ext.fixes : []),
    ...(data.firewall ? data.firewall.fixes : []),
    ...(data.multiwan ? data.multiwan.fixes : []),
    ...(data.script ? data.script.fixes : []),
    ...(data.security_ext ? data.security_ext.fixes : []),
    ...(data.monitoring ? data.monitoring.fixes : []),
    ...(data.backup ? data.backup.fixes : []),
    ...(data.services ? data.services.fixes : []),
    ...(data.performance_ext ? data.performance_ext.fixes : [])
  ];
  document.getElementById('fixes-list').innerHTML = allFixes.length
    ? fixHtml(allFixes)
    : '<div class="issue-item info">✅ Автоматичних виправлень немає</div>';

  // Topology Chain Rendering
  if (data.topology && data.topology.chains) {
    let topoHtml = '';
    data.topology.chains.forEach(chain => {
      topoHtml += `<div style="margin-bottom:24px;background:rgba(255,255,255,0.03);padding:16px;border-radius:12px;border:1px solid rgba(255,255,255,0.05)">
        <h4 style="margin-bottom:12px;font-size:14px;color:var(--text);font-weight:600;display:flex;align-items:center;justify-content:space-between">
          <span>🌐 ${escHtml(chain.network)}</span>
          <span style="font-size:11px;padding:3px 8px;border-radius:12px;background:${chain.status === 'ok' ? 'rgba(46,204,113,0.15)' : chain.status === 'warning' ? 'rgba(241,196,15,0.15)' : 'rgba(231,76,60,0.15)'};color:${chain.status === 'ok' ? 'var(--green)' : chain.status === 'warning' ? 'var(--yellow)' : 'var(--red)'}">
            ${chain.status.toUpperCase()}
          </span>
        </h4>
        <div style="display:flex;flex-wrap:wrap;align-items:center;gap:8px;margin-bottom:12px;">`;
      
      chain.chain_steps.forEach((step, sIdx) => {
        const badgeColor = step.status === 'ok' ? 'var(--green)' : step.status === 'warning' ? 'var(--yellow)' : 'var(--red)';
        const badgeBg = step.status === 'ok' ? 'rgba(46,204,113,0.1)' : step.status === 'warning' ? 'rgba(241,196,15,0.1)' : 'rgba(231,76,60,0.1)';
        const statusIcon = step.status === 'ok' ? '✓' : step.status === 'warning' ? '⚠️' : '✗';
        
        topoHtml += `<div style="display:flex;align-items:center;gap:6px;background:${badgeBg};border:1px solid ${badgeColor};padding:6px 12px;border-radius:6px;font-size:12px;color:var(--text)" title="${escHtml(step.detail)}">
          <span style="font-weight:700;color:${badgeColor}">${statusIcon}</span>
          <span>${escHtml(step.name)}</span>
        </div>`;
        
        if (sIdx < chain.chain_steps.length - 1) {
          topoHtml += `<span style="color:var(--text3);font-size:14px">➔</span>`;
        }
      });
      
      topoHtml += `</div>
        <!-- Error descriptions -->
        <div style="margin-top:12px;display:flex;flex-direction:column;gap:6px">`;
      chain.chain_steps.forEach(step => {
        if (step.status !== 'ok') {
          topoHtml += `<div style="font-size:11.5px;color:${step.status === 'warning' ? 'var(--yellow)' : 'var(--red)'};background:rgba(255,255,255,0.02);padding:6px 8px;border-radius:4px;border-left:3px solid ${step.status === 'warning' ? 'var(--yellow)' : 'var(--red)'}">
            <strong>${escHtml(step.name)}</strong>: ${escHtml(step.detail)}
          </div>`;
        }
      });
      topoHtml += `</div></div>`;
    });
    document.getElementById('topology-container').innerHTML = topoHtml;
  }

  // VLAN table
  if (data.vlan.ports && Object.keys(data.vlan.ports.pvid||{}).length > 0) {
    document.getElementById('vlan-table-card').style.display = 'block';
    const ports = new Set([
      ...Object.keys(data.vlan.ports.pvid||{}),
      ...Object.keys(data.vlan.ports.tagged||{}),
      ...Object.keys(data.vlan.ports.untagged||{})
    ]);
    let html = '<thead><tr><th>Порт</th><th>PVID</th><th>Tagged VLANs</th><th>Untagged VLANs</th></tr></thead><tbody>';
    for (const port of ports) {
      html += `<tr>
        <td>${escHtml(port)}</td>
        <td>${data.vlan.ports.pvid[port] || '—'}</td>
        <td>${(data.vlan.ports.tagged[port]||[]).join(', ') || '—'}</td>
        <td>${(data.vlan.ports.untagged[port]||[]).join(', ') || '—'}</td>
      </tr>`;
    }
    html += '</tbody>';
    document.getElementById('vlan-port-table').innerHTML = html;
  } else {
    document.getElementById('vlan-table-card').style.display = 'none';
  }

  // Compliance
  const tabBtn = document.getElementById('tab-btn-compliance');
  if (data.compliance) {
    const cv = data.compliance.violations || [];
    const cp = data.compliance.passed || [];
    document.getElementById('compliance-no-policy').style.display = 'none';
    
    if (cv.length > 0) {
      document.getElementById('compliance-violations-card').style.display = 'block';
      document.getElementById('compliance-violations-list').innerHTML = cv.map(v => `
        <div class="issue-item error" style="border-left-color:var(--orange)">
          <div style="font-weight:600;color:var(--orange)">🏢 ${escHtml(v.message)}</div>
          ${v.section ? `<div style="font-size:11px;color:var(--text3);margin-top:3px">Розділ: ${escHtml(v.section)}</div>` : ''}
          ${v.fix ? `<div style="margin-top:6px;padding:6px 8px;background:var(--bg);border-radius:4px;font-family:var(--font);font-size:11px;color:var(--teal)">${escHtml(v.fix)}</div>` : ''}
        </div>`).join('');
      if (tabBtn) { tabBtn.style.color = 'var(--orange)'; tabBtn.textContent = `🏢 Регламент (${cv.length})`; }
    } else {
      document.getElementById('compliance-violations-card').style.display = 'none';
      if (tabBtn) { tabBtn.style.color = 'var(--green)'; tabBtn.textContent = '🏢 Регламент ✓'; }
    }
    
    if (cp.length > 0) {
      document.getElementById('compliance-passed-card').style.display = 'block';
      document.getElementById('compliance-passed-list').innerHTML = cp.map(p => `<div class="issue-item info">${escHtml(p)}</div>`).join('');
    } else {
      document.getElementById('compliance-passed-card').style.display = 'none';
    }

    if (cv.length > 0) {
      const complianceHtml = cv.map(v => `<div class="issue-item error" style="border-left-color:var(--orange)">🏢 ${escHtml(v.message)}</div>`).join('');
      overviewEl.innerHTML = complianceHtml + overviewEl.innerHTML;
    }
  } else {
    document.getElementById('compliance-no-policy').style.display = 'block';
    document.getElementById('compliance-violations-card').style.display = 'none';
    document.getElementById('compliance-passed-card').style.display = 'none';
    if (tabBtn) { tabBtn.style.color = ''; tabBtn.textContent = '🏢 Регламент'; }
  }

  document.getElementById('audit-results').style.display = 'block';

  // Show AutoFix tab badge
  const fixCount = allFixes.length;
  const autofixBtn = document.getElementById('tab-btn-autofix');
  if (autofixBtn && fixCount > 0) {
    autofixBtn.textContent = `🔧 AutoFix (${fixCount})`;
    autofixBtn.style.color = 'var(--orange)';
    autofixBtn.style.borderColor = 'var(--orange)';
  }
}

function clearAudit() {
  document.getElementById('audit-config').value = '';
  document.getElementById('audit-results').style.display = 'none';
  const autofixBtn = document.getElementById('tab-btn-autofix');
  if (autofixBtn) { autofixBtn.textContent = '🔧 AutoFix'; autofixBtn.style.color = ''; autofixBtn.style.borderColor = ''; }
  document.getElementById('autofix-results').style.display = 'none';
}

// ── AutoFix / Rebuild ──
async function runAutoFix() {
  const config = document.getElementById('audit-config').value.trim();
  if (!config) { showToast('Спочатку вставте конфіг у вкладці аудиту'); return; }
  const profile = document.getElementById('rebuild-profile').value;
  const btn = document.getElementById('run-autofix-btn');
  btn.disabled = true;
  document.getElementById('autofix-loading').style.display = 'flex';
  document.getElementById('autofix-results').style.display = 'none';
  try {
    const r = await fetch(`${API}/analyze/rebuild`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config, profile})
    });
    const data = await r.json();
    renderAutoFix(data);
  } catch(e) {
    showToast('Помилка AutoFix: ' + e.message);
  } finally {
    btn.disabled = false;
    document.getElementById('autofix-loading').style.display = 'none';
  }
}

function renderAutoFix(data) {
  // Status bar
  const dryRunOk = data.dry_run && data.dry_run.status === 'SUCCESS';
  const complexity = data.complexity || {};
  const complexColor = complexity.score >= 80 ? 'var(--red)' : complexity.score >= 45 ? 'var(--yellow)' : 'var(--green)';
  document.getElementById('autofix-status-bar').innerHTML = `
    <div class="summary-card" style="flex:1;min-width:120px">
      <div class="val" style="color:${dryRunOk ? 'var(--green)' : 'var(--yellow)'}; font-size:20px">${dryRunOk ? '✅' : '⚠️'}</div>
      <div class="lbl">Dry-Run</div>
    </div>
    <div class="summary-card" style="flex:1;min-width:120px">
      <div class="val" style="color:${complexColor}; font-size:22px">${complexity.score || 0}</div>
      <div class="lbl">Складність</div>
    </div>
    <div class="summary-card" style="flex:1;min-width:120px">
      <div class="val blue" style="font-size:22px">${complexity.vlans || 0}</div>
      <div class="lbl">VLAN</div>
    </div>
    <div class="summary-card" style="flex:1;min-width:120px">
      <div class="val" style="color:var(--purple); font-size:22px">${complexity.firewall_rules || 0}</div>
      <div class="lbl">Firewall Rules</div>
    </div>
  `;

  // Impact Analysis
  const impacts = data.impact_analysis || [];
  document.getElementById('autofix-impact-list').innerHTML = impacts.length
    ? impacts.map(i => `<div class="issue-item warning">${escHtml(i)}</div>`).join('')
    : '<div class="issue-item info">✅ Застосування виправлень безпечне. Переривань сервісів не очікується.</div>';

  // Dry-Run
  const dryRun = data.dry_run || {};
  const remaining = dryRun.remaining_issues || [];
  document.getElementById('autofix-dryrun-status').innerHTML = `
    <div class="issue-item ${dryRun.status === 'SUCCESS' ? 'info' : 'warning'}" style="font-weight:600;margin-bottom:8px">
      Статус: ${dryRun.status === 'SUCCESS' ? '✅ SUCCESS — всі проблеми усунуто' : '⚠️ WARNING — залишились проблеми після виправлення'}
    </div>
    ${remaining.length ? remaining.map(r => `<div class="issue-item error">${escHtml(r)}</div>`).join('') : ''}
  `;

  // Complexity
  document.getElementById('autofix-complexity-info').innerHTML = `
    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px">
      <div style="background:var(--bg3);border-radius:var(--radius);padding:12px;text-align:center">
        <div style="font-size:20px;font-weight:800;font-family:var(--font);color:${complexColor}">${complexity.score || 0}</div>
        <div style="font-size:11px;color:var(--text3);margin-top:4px">${complexity.description || '—'}</div>
      </div>
      <div style="background:var(--bg3);border-radius:var(--radius);padding:12px;text-align:center">
        <div style="font-size:20px;font-weight:800;font-family:var(--font);color:var(--accent)">${complexity.vlans || 0}</div>
        <div style="font-size:11px;color:var(--text3);margin-top:4px">VLAN Interfaces</div>
      </div>
      <div style="background:var(--bg3);border-radius:var(--radius);padding:12px;text-align:center">
        <div style="font-size:20px;font-weight:800;font-family:var(--font);color:var(--green)">${complexity.dhcp_servers || 0}</div>
        <div style="font-size:11px;color:var(--text3);margin-top:4px">DHCP Servers</div>
      </div>
      <div style="background:var(--bg3);border-radius:var(--radius);padding:12px;text-align:center">
        <div style="font-size:20px;font-weight:800;font-family:var(--font);color:var(--purple)">${complexity.firewall_rules || 0}</div>
        <div style="font-size:11px;color:var(--text3);margin-top:4px">Firewall Rules</div>
      </div>
    </div>
  `;

  // Remedied Original
  const remedied = data.remedied_original || '';
  document.getElementById('autofix-remedied').innerHTML = highlightROS(remedied);

  // Diff View with coloring
  const diffText = data.diff || '';
  const diffHtml = diffText.split('\n').map(line => {
    if (line.startsWith('+++') || line.startsWith('---')) return `<span style="color:var(--text3);font-weight:600">${escHtml(line)}</span>`;
    if (line.startsWith('+')) return `<span style="color:var(--green);background:rgba(16,185,129,0.08);display:block">${escHtml(line)}</span>`;
    if (line.startsWith('-')) return `<span style="color:var(--red);background:rgba(239,68,68,0.08);display:block">${escHtml(line)}</span>`;
    if (line.startsWith('@@')) return `<span style="color:var(--accent)">${escHtml(line)}</span>`;
    return `<span style="color:var(--text3)">${escHtml(line)}</span>`;
  }).join('\n');
  document.getElementById('autofix-diff').innerHTML = diffHtml || '<span style="color:var(--text3)">Немає змін</span>';

  // Refactored Clean Config
  const refactored = data.refactored_clean || '';
  document.getElementById('autofix-refactored').innerHTML = highlightROS(refactored);

  document.getElementById('autofix-results').style.display = 'block';
  showToast('✅ AutoFix завершено!');
}

function downloadText(elementId, filename) {
  const text = document.getElementById(elementId).textContent;
  const blob = new Blob([text], {type: 'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  a.click();
  showToast('Файл завантажується...');
}

// ── VLAN ──
async function runVlan() {
  const config = document.getElementById('vlan-config').value.trim();
  if (!config) return;
  try {
    const r = await fetch(`${API}/analyze`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config})
    });
    const data = await r.json();
    const v = data.vlan;
    document.getElementById('vlan-result-list').innerHTML =
      issueHtml(v.issues, 'error') + issueHtml(v.warnings, 'warning') + issueHtml(v.info, 'info') ||
      '<div class="issue-item info">✅ VLAN OK</div>';

    if (v.fixes && v.fixes.length) {
      document.getElementById('vlan-fixes-card').style.display = 'block';
      document.getElementById('vlan-fix-list').innerHTML = fixHtml(v.fixes);
    } else {
      document.getElementById('vlan-fixes-card').style.display = 'none';
    }

    if (v.ports && Object.keys(v.ports.pvid||{}).length > 0) {
      document.getElementById('vlan-ports-card').style.display = 'block';
      const ports = new Set([...Object.keys(v.ports.pvid||{}), ...Object.keys(v.ports.tagged||{}), ...Object.keys(v.ports.untagged||{})]);
      let html = '<thead><tr><th>Порт</th><th>PVID</th><th>Tagged</th><th>Untagged</th></tr></thead><tbody>';
      for (const port of ports) {
        html += `<tr><td>${escHtml(port)}</td><td>${v.ports.pvid[port]||'—'}</td><td>${(v.ports.tagged[port]||[]).join(', ')||'—'}</td><td>${(v.ports.untagged[port]||[]).join(', ')||'—'}</td></tr>`;
      }
      document.getElementById('vlan-result-table').innerHTML = html + '</tbody>';
    } else {
      document.getElementById('vlan-ports-card').style.display = 'none';
    }
    document.getElementById('vlan-results').style.display = 'block';
  } catch(e) { showToast('Помилка'); }
}

// ── WiFi ──
async function runWifi() {
  const config = document.getElementById('wifi-config').value.trim();
  if (!config) return;
  try {
    const r = await fetch(`${API}/analyze`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config})
    });
    const data = await r.json();
    const w = data.wifi;
    const s = w.summary;
    document.getElementById('wifi-summary-card').innerHTML = `
      <div class="card-title">📶 Зведення</div>
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${s.channels_2ghz.length ? `<span class="pill">2.4GHz: ${s.channels_2ghz.join(', ')}</span>` : ''}
        ${s.channels_5ghz.length ? `<span class="pill">5GHz: ${s.channels_5ghz.join(', ')}</span>` : ''}
        ${s.security.length ? `<span class="pill ${s.security.some(x=>x.includes('wpa3'))?'green':''}">Security: ${s.security.join(', ')}</span>` : ''}
        ${s.countries.length ? `<span class="pill">Country: ${s.countries.join(', ')}</span>` : ''}
        <span class="pill ${s.ft?'green':'yellow'}">FT(802.11r): ${s.ft?'✅':'❌'}</span>
        <span class="pill ${s.steering?'green':'yellow'}">Steering: ${s.steering?'✅':'❌'}</span>
      </div>
    `;
    document.getElementById('wifi-result-list').innerHTML =
      issueHtml(w.issues, 'error') + issueHtml(w.warnings, 'warning') +
      issueHtml(w.recommendations||[], 'rec') + issueHtml(w.info, 'info');
    document.getElementById('wifi-results').style.display = 'block';
  } catch(e) { showToast('Помилка'); }
}

// ── CAPsMAN ──
async function runCaps() {
  const config = document.getElementById('caps-config').value.trim();
  if (!config) return;
  try {
    const r = await fetch(`${API}/analyze`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config})
    });
    const data = await r.json();
    const c = data.capsman;
    document.getElementById('caps-result-list').innerHTML =
      issueHtml(c.issues, 'error') + issueHtml(c.warnings, 'warning') + issueHtml(c.info, 'info') ||
      '<div class="issue-item info">✅ CAPsMAN OK</div>';
    if (c.fixes && c.fixes.length) {
      document.getElementById('caps-fixes-card').style.display = 'block';
      document.getElementById('caps-fix-list').innerHTML = fixHtml(c.fixes);
    } else {
      document.getElementById('caps-fixes-card').style.display = 'none';
    }
    document.getElementById('caps-results').style.display = 'block';
  } catch(e) { showToast('Помилка'); }
}

// ── Troubleshoot ──
function setTrouble(text) {
  document.getElementById('trouble-input').value = text;
  runTrouble();
}

async function runTrouble() {
  const problem = document.getElementById('trouble-input').value.trim();
  if (!problem) return;
  try {
    const r = await fetch(`${API}/troubleshoot`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({problem})
    });
    const data = await r.json();
    document.getElementById('trouble-title').textContent = '🔍 ' + data.detected;
    const causesEl = document.getElementById('trouble-causes');
    causesEl.innerHTML = data.causes.map(c => {
      const probClass = c.prob >= 75 ? 'prob-high' : c.prob >= 50 ? 'prob-med' : 'prob-low';
      const checks = c.checks.map(cmd =>
        `<div class="check-cmd">${escHtml(cmd)}<button class="copy-btn" onclick="copyText('${escHtml(cmd)}')">📋</button></div>`
      ).join('');
      return `
        <div class="cause-item">
          <div class="cause-header">
            <span class="prob-badge ${probClass}">${c.prob}%</span>
            <span class="cause-title">${escHtml(c.cause)}</span>
          </div>
          <div class="section-sep" style="border:none;padding:4px 0 6px;font-size:10px">КОМАНДИ ПЕРЕВІРКИ</div>
          <div class="check-list">${checks}</div>
          ${c.fix ? `<div class="section-sep" style="border:none;padding:8px 0 4px;font-size:10px">ВИПРАВЛЕННЯ</div><div class="fix-block"><button class="copy-btn" onclick="copyText('${escHtml(c.fix)}')">📋</button>${escHtml(c.fix)}</div>` : ''}
        </div>
      `;
    }).join('');

    if (data.kb_matches && data.kb_matches.length) {
      document.getElementById('trouble-kb').style.display = 'block';
      document.getElementById('trouble-kb-list').innerHTML = data.kb_matches.map(k => `
        <div class="kb-item" style="margin-bottom:8px">
          <div class="kb-item-content">
            <div class="kb-problem">${escHtml(k.problem)}</div>
            <div class="kb-solution">${escHtml(k.solution)}</div>
          </div>
        </div>
      `).join('');
    } else {
      document.getElementById('trouble-kb').style.display = 'none';
    }

    document.getElementById('trouble-results').style.display = 'block';
  } catch(e) { showToast('Помилка'); }
}

// ── Config Generator Templates & Features ──

function generatePass() {
  const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%";
  let pass = "";
  for (let i = 0; i < 14; i++) {
    pass += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  document.getElementById('gen-wifi-password').value = pass;
  showToast('Згенеровано надійний пароль!');
}

function toggleCustomDns() {
  const dns = document.getElementById('gen-dns').value;
  document.getElementById('gen-dns-custom').style.display = dns === 'custom' ? 'block' : 'none';
}

function toggleCustomNtp() {
  const ntp = document.getElementById('gen-ntp').value;
  document.getElementById('gen-ntp-custom').style.display = ntp === 'custom' ? 'block' : 'none';
}

function applyTemplate() {
  const tmpl = document.getElementById('gen-template').value;
  if (tmpl === 'none') return;
  
  document.getElementById('gen-vlans').innerHTML = '';
  document.getElementById('gen-ssids').innerHTML = '';
  
  if (tmpl === 'home-ap') {
    document.getElementById('gen-device').value = 'hap-ax3';
    document.getElementById('gen-capsman-toggle').classList.remove('on');
    
    addVlanRowData(10, 'LAN', '10.10.0.1');
    addVlanRowData(20, 'GUEST', '10.20.0.1');
    
    addSsidRowData('Home-WiFi', 10);
    addSsidRowData('Home-Guest', 20);
    
    document.getElementById('gen-wifi-password').value = 'HomeSecure2026!';
    document.getElementById('gen-firewall').value = 'basic';
    document.getElementById('gen-dns').value = 'cloudflare';
    document.getElementById('gen-ntp').value = 'pool';
  } else if (tmpl === 'office-sw') {
    document.getElementById('gen-device').value = 'rb4011';
    document.getElementById('gen-capsman-toggle').classList.remove('on');
    
    addVlanRowData(10, 'MGMT', '10.10.0.1');
    addVlanRowData(100, 'STAFF', '10.100.0.1');
    addVlanRowData(200, 'GUEST', '10.200.0.1');
    addVlanRowData(300, 'IOT', '10.300.0.1');
    
    addSsidRowData('Office-Staff', 100);
    addSsidRowData('Office-Guest', 200);
    
    document.getElementById('gen-wifi-password').value = 'OfficeStaffSecure!';
    document.getElementById('gen-firewall').value = 'strict';
    document.getElementById('gen-dns').value = 'cloudflare';
    document.getElementById('gen-ntp').value = 'pool';
  } else if (tmpl === 'capsman-ctrl') {
    document.getElementById('gen-device').value = 'rb4011';
    document.getElementById('gen-capsman-toggle').classList.add('on');
    
    addVlanRowData(99, 'MGMT', '10.99.0.1');
    addVlanRowData(10, 'STAFF', '10.10.0.1');
    addVlanRowData(20, 'GUEST', '10.20.0.1');
    
    addSsidRowData('Corp-Staff', 10);
    addSsidRowData('Corp-Guest', 20);
    
    document.getElementById('gen-wifi-password').value = 'CapsSecureNet!';
    document.getElementById('gen-firewall').value = 'basic';
    document.getElementById('gen-dns').value = 'google';
    document.getElementById('gen-ntp').value = 'google';
  }
  
  toggleCustomDns();
  toggleCustomNtp();
  showToast('Шаблон застосовано успішно!');
}

function addVlanRowData(id, name, gateway) {
  const div = document.createElement('div');
  div.className = 'vlan-row';
  div.innerHTML = `
    <input type="number" placeholder="ID" value="${id}" min="1" max="4094" style="max-width:70px">
    <input type="text" placeholder="Назва" value="${name}">
    <input type="text" placeholder="Шлюз" value="${gateway}">
    <button class="btn btn-danger btn-sm" onclick="removeRow(this)">✕</button>
  `;
  document.getElementById('gen-vlans').appendChild(div);
}

function addSsidRowData(ssid, vlan) {
  const div = document.createElement('div');
  div.className = 'vlan-row';
  div.innerHTML = `
    <input type="text" placeholder="SSID" value="${ssid}">
    <input type="number" placeholder="VLAN" value="${vlan}" style="max-width:70px">
    <button class="btn btn-danger btn-sm" onclick="removeRow(this)">✕</button>
  `;
  document.getElementById('gen-ssids').appendChild(div);
}

function addVlanRow() {
  addVlanRowData(20, 'VLAN20', '10.20.0.1');
}

function addSsidRow() {
  addSsidRowData('SSID20', 20);
}

function removeRow(btn) { btn.closest('.vlan-row').remove(); }

async function runCompilerPipeline() {
  const config = document.getElementById('compiler-input-config').value.trim();
  const target_hardware = document.getElementById('compiler-target-device').value;
  const src_subnet = document.getElementById('compiler-src-subnet').value.trim();
  const target_subnet = document.getElementById('compiler-target-subnet').value.trim();
  const target_ssid = document.getElementById('compiler-target-ssid').value.trim();
  const target_wifi_password = document.getElementById('compiler-target-wifi-password').value.trim();
  
  if (!config) { showToast('Будь ласка, вставте вхідну конфігурацію!'); return; }
  
  showToast('Запуск компілятора...');
  
  try {
    const r = await fetch(`${API}/design/compile`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        config,
        target_hardware,
        src_subnet: src_subnet || null,
        target_subnet: target_subnet || null,
        target_ssid: target_ssid || null,
        target_wifi_password: target_wifi_password || null
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast('Помилка компіляції: ' + (errData.error || r.statusText));
      return;
    }
    
    const data = await r.json();
    
    // Switch panels
    document.getElementById('compiler-empty-state').style.display = 'none';
    document.getElementById('compiler-results').style.display = 'flex';
    
    // Update Quality & Confidence Score UI
    const qScoreEl = document.getElementById('compiler-score-quality');
    const cScoreEl = document.getElementById('compiler-score-confidence');
    
    qScoreEl.textContent = data.inventory.quality_score + '%';
    qScoreEl.style.color = data.inventory.quality_score >= 80 ? 'var(--success)' : data.inventory.quality_score >= 50 ? 'var(--warning)' : 'var(--danger)';
    
    cScoreEl.textContent = data.inventory.confidence_score + '%';
    cScoreEl.style.color = data.inventory.confidence_score >= 80 ? 'var(--accent)' : data.inventory.confidence_score >= 50 ? 'var(--warning)' : 'var(--danger)';
    
    document.getElementById('compiler-secrets-count').textContent = data.inventory.secrets_count;
    
    // Render Confidence Deductions
    const deductionsContainer = document.getElementById('compiler-confidence-deductions-container');
    const deductionsList = document.getElementById('compiler-confidence-deductions');
    deductionsList.innerHTML = '';
    if (data.inventory.confidence_deductions && data.inventory.confidence_deductions.length > 0) {
      data.inventory.confidence_deductions.forEach(d => {
        const li = document.createElement('li');
        li.textContent = d;
        deductionsList.appendChild(li);
      });
      deductionsContainer.style.display = 'block';
    } else {
      deductionsContainer.style.display = 'none';
    }

    // Fetch and display Semantic Diff
    try {
      const diffResp = await fetch(`${API}/compare`, {
        method: 'POST',
        headers: {'Content-Type': 'application/json'},
        body: JSON.stringify({ config_old: config, config_new: data.new_config })
      });
      if (diffResp.ok) {
        const diffData = await diffResp.json();
        const diffText = diffData.diff;
        document.getElementById('compiler-out-diff').textContent = diffText;
        
        let riskLevel = "LOW";
        let riskExpl = "Змін у структурі конфігурації не виявлено.";
        const diffLines = diffText.split('\n');
        if (diffLines[1] && diffLines[1].includes('ОЦІНКА РИЗИКУ ЗМІН:')) {
          riskLevel = diffLines[1].split('ОЦІНКА РИЗИКУ ЗМІН:')[1].trim();
        }
        if (diffLines[2] && diffLines[2].includes('Пояснення:')) {
          riskExpl = diffLines[2].split('Пояснення:')[1].trim();
        }
        
        const riskCard = document.getElementById('compiler-diff-risk-card');
        const riskIcon = document.getElementById('compiler-diff-risk-icon');
        const riskLvlEl = document.getElementById('compiler-diff-risk-level');
        const riskExplEl = document.getElementById('compiler-diff-risk-explanation');
        
        riskLvlEl.textContent = `РІВЕНЬ РИЗИКУ: ${riskLevel}`;
        riskExplEl.textContent = riskExpl;
        
        if (riskLevel === 'CRITICAL') {
          riskCard.style.background = 'rgba(239, 68, 68, 0.1)';
          riskCard.style.border = '1px solid var(--danger)';
          riskCard.style.color = 'var(--danger)';
          riskIcon.textContent = '🚨';
        } else if (riskLevel === 'HIGH') {
          riskCard.style.background = 'rgba(245, 158, 11, 0.1)';
          riskCard.style.border = '1px solid var(--warning)';
          riskCard.style.color = 'var(--warning)';
          riskIcon.textContent = '⚠️';
        } else if (riskLevel === 'MEDIUM') {
          riskCard.style.background = 'rgba(59, 130, 246, 0.1)';
          riskCard.style.border = '1px solid var(--accent)';
          riskCard.style.color = 'var(--accent)';
          riskIcon.textContent = '⚡';
        } else {
          riskCard.style.background = 'rgba(16, 185, 129, 0.1)';
          riskCard.style.border = '1px solid var(--success)';
          riskCard.style.color = 'var(--success)';
          riskIcon.textContent = '✅';
        }
      }
    } catch(err) {
      console.error("Failed to fetch diff:", err);
      document.getElementById('compiler-out-diff').textContent = "Не вдалося отримати семантичний диф.";
    }

    if (data.inventory.readiness_breakdown) {
      const rb = data.inventory.readiness_breakdown;
      
      const sScoreEl = document.getElementById('compiler-score-security');
      sScoreEl.textContent = rb.security + '%';
      sScoreEl.style.color = rb.security >= 80 ? 'var(--success)' : rb.security >= 50 ? 'var(--warning)' : 'var(--danger)';
      
      const rScoreEl = document.getElementById('compiler-score-reliability');
      rScoreEl.textContent = rb.reliability + '%';
      rScoreEl.style.color = rb.reliability >= 80 ? 'var(--success)' : rb.reliability >= 50 ? 'var(--warning)' : 'var(--danger)';
      
      const scScoreEl = document.getElementById('compiler-score-scalability');
      scScoreEl.textContent = rb.scalability + '%';
      scScoreEl.style.color = rb.scalability >= 80 ? 'var(--success)' : rb.scalability >= 50 ? 'var(--warning)' : 'var(--danger)';
      
      const mScoreEl = document.getElementById('compiler-score-maintainability');
      mScoreEl.textContent = rb.maintainability + '%';
      mScoreEl.style.color = rb.maintainability >= 80 ? 'var(--success)' : rb.maintainability >= 50 ? 'var(--warning)' : 'var(--danger)';
    }
    
    // Bind files output
    document.getElementById('compiler-out-rsc').innerHTML = highlightROS(data.new_config);
    document.getElementById('compiler-out-rollback').innerHTML = highlightROS(data.rollback_config);
    document.getElementById('compiler-out-secrets').textContent = data.secrets;
    document.getElementById('compiler-out-topology').textContent = data.topology;
    
    // Render Risk badges
    const riskContainer = document.getElementById('compiler-hardware-risks');
    riskContainer.innerHTML = '';
    if (data.inventory.risks && data.inventory.risks.length > 0) {
      data.inventory.risks.forEach(risk => {
        const item = document.createElement('div');
        item.className = 'issue-item ' + (risk.level === 'danger' ? 'danger' : 'warning');
        item.innerHTML = `<span>${risk.level === 'danger' ? '🚨' : '⚠️'}</span> <span>${risk.message}</span>`;
        riskContainer.appendChild(item);
      });
    } else {
      riskContainer.innerHTML = '<div style="color:var(--success); font-size:13px; font-weight:500;">✅ Не виявлено апаратних ризиків.</div>';
    }
    
    // Render Sandbox Errors
    const sandboxContainer = document.getElementById('compiler-sandbox-errors');
    sandboxContainer.innerHTML = '';
    if (data.inventory.sandbox_errors && data.inventory.sandbox_errors.length > 0) {
      data.inventory.sandbox_errors.forEach(err => {
        const item = document.createElement('div');
        item.className = 'issue-item ' + (err.type === 'error' ? 'danger' : 'warning');
        item.innerHTML = `<span>${err.type === 'error' ? '❌' : '⚠️'}</span> <span>${err.message}</span>`;
        sandboxContainer.appendChild(item);
      });
    } else {
      sandboxContainer.innerHTML = '<div style="color:var(--success); font-size:13px; font-weight:500;">✅ Конфігурація успішно пройшла валідацію в пісочниці.</div>';
    }
    
    // Render Heuristics
    const optContainer = document.getElementById('compiler-optimizations');
    optContainer.innerHTML = '';
    if (data.inventory.recommendations && data.inventory.recommendations.length > 0) {
      data.inventory.recommendations.forEach(rec => {
        const item = document.createElement('div');
        item.className = 'issue-item info';
        item.innerHTML = `<span>💡</span> <span>${rec.message}</span>`;
        optContainer.appendChild(item);
      });
    } else {
      optContainer.innerHTML = '<div style="color:var(--success); font-size:13px; font-weight:500;">✅ Конфігурація повністю оптимізована.</div>';
    }

    // Render Firewall Flow Tracing
    const fwContainer = document.getElementById('compiler-firewall-flow');
    fwContainer.innerHTML = '';
    if (data.inventory.firewall_flow) {
      const verdicts = data.inventory.firewall_flow.verdicts;
      const vItems = [
        { key: "snmp_blocked", label: "Захист SNMP (блокування з WAN)", okIcon: "✓", errIcon: "✗" },
        { key: "ssh_lan_only", label: "SSH доступ дозволено тільки з LAN", okIcon: "✓", errIcon: "✗" },
        { key: "dns_lan_only", label: "Захист DNS від зовнішніх запитів", okIcon: "✓", errIcon: "✗" },
        { key: "ntp_exposed", label: "Служба NTP відкрита публічно", okIcon: "🚨 (Відкрито)", errIcon: "✓ (Захищено)", invert: true }
      ];
      
      let html = `<div style="font-family:var(--font); font-size:12px; margin-bottom:8px; background:var(--bg); padding:10px; border-radius:var(--radius); border:1px solid var(--border); line-height: 1.5;">`;
      vItems.forEach(item => {
        let passed = verdicts[item.key];
        if (item.invert) passed = !passed;
        const icon = passed ? `<span style="color:var(--success); font-weight:bold;">${item.okIcon}</span>` : `<span style="color:var(--danger); font-weight:bold;">${item.errIcon}</span>`;
        html += `<div>${icon} ${item.label}</div>`;
      });
      html += `</div>`;
      
      let cachedWikiModels = null;
      async function loadWikiModels() {
        try {
          const select = document.getElementById('wiki-model-select');
          select.innerHTML = '<option value="">Оберіть модель...</option>';
          const r = await fetch(`${API}/wiki/models`);
          const data = await r.json();
          cachedWikiModels = data;

          for (const key in data) {
            const option = document.createElement('option');
            option.value = key;
            option.textContent = data[key].name || key;
            select.appendChild(option);
          }

          // Populate load simulator device selector
          const simSelect = document.getElementById('sim-device-select');
          if (simSelect) {
            simSelect.innerHTML = '';
            for (const key in data) {
              const option = document.createElement('option');
              option.value = key;
              option.textContent = data[key].name || key;
              simSelect.appendChild(option);
            }
          }
        } catch(err) {
          console.error(err);
          showToast('Помилка завантаження бази знань моделей');
        }
      }

      if (data.inventory.firewall_flow.tree.input.length > 0) {
        html += `<div style="font-size:11.5px; color:var(--text3); font-weight:600; margin-bottom:4px;">СЛІД ПРАВИЛ INPUT CHAIN:</div>`;
        html += `<pre style="font-family:var(--font-mono); font-size:11px; background:rgba(0,0,0,0.2); padding:8px; border-radius:var(--radius); border:1px solid var(--border); overflow-x:auto; margin-top:0;">`;
        html += data.inventory.firewall_flow.tree.input.join('\n');
        html += `</pre>`;
      }
      fwContainer.innerHTML = html;
    }

    // Render NAT Mappings
    const natContainer = document.getElementById('compiler-nat-flow');
    natContainer.innerHTML = '';
    if (data.inventory.nat_flow && data.inventory.nat_flow.length > 0) {
      let html = `<pre style="font-family:var(--font-mono); font-size:11.5px; background:var(--bg); padding:10px; border-radius:var(--radius); border:1px solid var(--border); line-height:1.5; color:var(--text2); margin-top:0; white-space:pre-wrap;">`;
      html += data.inventory.nat_flow.join('\n');
      html += `</pre>`;
      natContainer.innerHTML = html;
    }

    // Render Routing & PCC
    const rtContainer = document.getElementById('compiler-routing-flow');
    rtContainer.innerHTML = '';
    if (data.inventory.routing_flow) {
      const rf = data.inventory.routing_flow;
      let html = `<div style="font-family:var(--font); font-size:12.5px; line-height:1.5; background:var(--bg); padding:10px; border-radius:var(--radius); border:1px solid var(--border);">`;
      html += `<div>🌐 Виявлено WAN шлюзів: <strong style="color:var(--accent);">${rf.wan_gateways.length > 0 ? rf.wan_gateways.join(', ') : 'Немає'}</strong></div>`;
      html += `<div>📊 Правил класифікатора PCC: <strong style="color:var(--accent);">${rf.pcc_rules_count}</strong></div>`;
      
      if (rf.warnings && rf.warnings.length > 0) {
        rf.warnings.forEach(w => {
          html += `<div style="margin-top:8px; padding:10px; border-radius:var(--radius); background:rgba(239,68,68,0.1); border:1px solid var(--danger); color:var(--danger); font-size:12px; font-weight:500;">`;
          html += `🚨 ${w.message}`;
          html += `</div>`;
        });
      } else {
        html += `<div style="margin-top:8px; color:var(--success); font-size:12px; font-weight:500; font-family:var(--font);">✓ Конфігурація балансування PCC узгоджена.</div>`;
      }
      html += `</div>`;
      rtContainer.innerHTML = html;
    }
    
    
    // Render WiFi Audit
    const wifiContainer = document.getElementById('compiler-wifi-audit');
    wifiContainer.innerHTML = '';
    if (data.inventory.wifi_audit) {
      let html = `<div style="font-family:var(--font); font-size:12.5px; line-height:1.5; background:var(--bg); padding:10px; border-radius:var(--radius); border:1px solid var(--border);">`;
      
      const wa = data.inventory.wifi_audit;
      if (wa.warnings.length === 0 && wa.recommendations.length === 0) {
        html += `<div style="color:var(--success); font-weight:500;">✓ Проблем бездротового зв'язку не виявлено.</div>`;
      } else {
        if (wa.warnings.length > 0) {
          wa.warnings.forEach(w => {
            html += `<div style="margin-bottom:8px; padding:10px; border-radius:var(--radius); background:rgba(239,68,68,0.1); border:1px solid var(--danger); color:var(--danger); font-size:12px; font-weight:500;">`;
            html += `⚠️ ${w.message}`;
            html += `</div>`;
          });
        }
        if (wa.recommendations.length > 0) {
          wa.recommendations.forEach(r => {
            const isSuccess = r.type === 'success';
            const bg = isSuccess ? 'rgba(16,185,129,0.1)' : 'rgba(59,130,246,0.1)';
            const border = isSuccess ? 'var(--success)' : 'var(--accent)';
            const color = isSuccess ? 'var(--success)' : 'var(--accent)';
            html += `<div style="margin-bottom:8px; padding:10px; border-radius:var(--radius); background:${bg}; border:1px solid ${border}; color:${color}; font-size:12px; font-weight:500;">`;
            html += `💡 ${r.message}`;
            html += `</div>`;
          });
        }
      }
      html += `</div>`;
      wifiContainer.innerHTML = html;
    }

    // Render Change Impacts
    const impactContainer = document.getElementById('compiler-change-impacts');
    impactContainer.innerHTML = '';
    if (data.inventory.change_impacts && data.inventory.change_impacts.length > 0) {
      data.inventory.change_impacts.forEach(imp => {
        const item = document.createElement('div');
        let badgeClass = 'info';
        let icon = 'ℹ️';
        if (imp.severity === 'high') {
          badgeClass = 'danger';
          icon = '🚨';
        } else if (imp.severity === 'warning') {
          badgeClass = 'warning';
          icon = '⚠️';
        } else if (imp.severity === 'success') {
          badgeClass = 'success';
          icon = '✅';
        }
        item.className = 'issue-item ' + badgeClass;
        item.innerHTML = `<span>${icon}</span> <span>${imp.message}</span>`;
        impactContainer.appendChild(item);
      });
    } else {
      impactContainer.innerHTML = '<div style="color:var(--success); font-size:13px; font-weight:500;">✅ Деструктивного впливу не виявлено.</div>';
    }

    // Render Auto-Repair Fixes
    const fixesContainer = document.getElementById('compiler-auto-fixes');
    fixesContainer.innerHTML = '';
    if (data.inventory.auto_fixes && data.inventory.auto_fixes.length > 0) {
      data.inventory.auto_fixes.forEach(fix => {
        const item = document.createElement('div');
        item.className = 'issue-item info';
        item.style.display = 'flex';
        item.style.justifyContent = 'space-between';
        item.style.alignItems = 'center';
        item.style.gap = '10px';
        item.innerHTML = `
          <div>
            <div style="font-weight:600; font-size:12px; color:var(--text);">💡 ${fix.explanation}</div>
            <code style="font-size:11px; background:rgba(0,0,0,0.25); padding:2px 4px; border-radius:4px; font-family:var(--font-mono); color:var(--yellow);">${fix.command}</code>
          </div>
          <button class="btn btn-sm btn-outline" style="padding:4px 8px; font-size:11px; flex-shrink:0;" onclick="applyAutoFixCommand(\`${fix.command.replace(/\\/g, '\\\\').replace(/`/g, '\\`').replace(/"/g, '&quot;')}\`)">🔧 Fix</button>
        `;
        fixesContainer.appendChild(item);
      });
    } else {
      fixesContainer.innerHTML = '<div style="color:var(--success); font-size:13px; font-weight:500;">✅ Авто-виправлення не потрібні.</div>';
    }

    // Render Capacity Report
    const capContainer = document.getElementById('compiler-capacity');
    capContainer.innerHTML = '';
    if (data.inventory.capacity_report) {
      const cap = data.inventory.capacity_report;
      let html = `<div style="font-family:var(--font); font-size:12.5px; line-height:1.5; background:var(--bg); padding:10px; border-radius:var(--radius); border:1px solid var(--border);">`;
      html += `<div>🖥️ <b>Пристрій:</b> ${cap.model_name}</div>`;
      html += `<div style="margin-top:4px;">📊 <b>Запас CPU:</b> <strong style="color:var(--success); font-size:14px;">${cap.cpu_reserve}%</strong></div>`;
      html += `<div style="margin-top:2px;">💾 <b>Запас RAM:</b> <strong style="color:var(--success); font-size:14px;">${cap.ram_reserve}%</strong></div>`;
      html += `<div style="margin-top:4px; font-weight:600; color:var(--yellow);">📈 Резюме: ${cap.status_ukr}</div>`;
      html += `</div>`;
      capContainer.innerHTML = html;
    }

    // Render Mermaid visual topology
    if (window.mermaid && data.mermaid_topology) {
      const graphContainer = document.getElementById('compiler-mermaid-graph');
      graphContainer.style.display = 'block';
      graphContainer.removeAttribute('data-processed');
      graphContainer.textContent = data.mermaid_topology;
      try {
        mermaid.init(undefined, graphContainer);
      } catch (me) {
        console.error(me);
      }
    } else {
      document.getElementById('compiler-mermaid-graph').style.display = 'none';
    }
    
    showToast('Успішно скомпільовано!');
  } catch (err) {
    console.error(err);
    showToast('Помилка компіляції.');
  }
}

function applyAutoFixCommand(command) {
  const input = document.getElementById('compiler-input-config');
  input.value = input.value.trim() + "\n\n# Auto-applied fix:\n" + command;
  runCompilerPipeline();
  showToast('Застосовано виправлення!');
}

async function runExpertDesign() {
  try {
    const clients_count = parseInt(document.getElementById('expert-clients').value) || 50;
    const wan_count = parseInt(document.getElementById('expert-wans').value) || 1;
    const wifi_needed = document.getElementById('expert-wifi').checked;
    const capsman_needed = document.getElementById('expert-capsman').checked;
    const vpn_needed = document.getElementById('expert-vpn').checked;
    const container_needed = document.getElementById('expert-container').checked;
    
    const r = await fetch(`${API}/design/expert`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ clients_count, wan_count, wifi_needed, capsman_needed, vpn_needed, container_needed })
    });
    const data = await r.json();
    
    document.getElementById('expert-design-result').style.display = 'block';
    document.getElementById('expert-res-core').textContent = data.core_device;
    document.getElementById('expert-res-core-desc').textContent = data.core_desc;
    
    document.getElementById('expert-res-ap').textContent = data.access_ap + (data.ap_count > 0 ? ` (к-ть: ${data.ap_count} шт.)` : '');
    document.getElementById('expert-res-ap-desc').textContent = data.ap_desc;
    
    const tbody = document.getElementById('expert-res-vlans-body');
    tbody.innerHTML = '';
    data.vlans.forEach(vl => {
      const tr = document.createElement('tr');
      tr.style.borderBottom = '1px solid var(--border)';
      tr.innerHTML = `
        <td style="padding:6px; font-weight:700; color:var(--yellow);">${vl.id}</td>
        <td style="padding:6px;"><code>${vl.name}</code></td>
        <td style="padding:6px;"><code>${vl.subnet}</code></td>
        <td style="padding:6px; color:var(--text2);">${vl.desc}</td>
      `;
      tbody.appendChild(tr);
    });
    
    showToast('Дизайн успішно згенеровано!');
  } catch(err) {
    console.error(err);
    showToast('Помилка генерації дизайну');
  }
}

let cachedWikiModels = null;
async function loadWikiModels() {
  try {
    const select = document.getElementById('wiki-model-select');
    select.innerHTML = '<option value="">Оберіть модель...</option>';
    const r = await fetch(`${API}/wiki/models`);
    const data = await r.json();
    cachedWikiModels = data;
    
    for (const key in data) {
      const option = document.createElement('option');
      option.value = key;
      option.textContent = data[key].name || key;
      select.appendChild(option);
    }
  } catch(err) {
    console.error(err);
    showToast('Помилка завантаження бази знань моделей');
  }
}

function onWikiModelChange() {
  const key = document.getElementById('wiki-model-select').value;
  if (!key || !cachedWikiModels || !cachedWikiModels[key]) {
    document.getElementById('wiki-model-cards').style.display = 'none';
    return;
  }
  const model = cachedWikiModels[key];
  document.getElementById('wiki-model-cards').style.display = 'flex';
  document.getElementById('wiki-device-name').textContent = model.name || key;
  
  let briefHtml = `
    <p style="margin-bottom:8px; line-height:1.5;">${model.wiki.brief}</p>
    <div style="background:rgba(239,68,68,0.1); border:1px solid var(--danger); color:var(--danger); padding:8px; border-radius:var(--radius); font-size:12px; margin-bottom:8px;">
      <strong>✗ Не рекомендується:</strong> ${model.wiki.not_recommended}
    </div>
    <p style="color:var(--text2); font-size:12px; font-style:italic;">${model.wiki.details}</p>
  `;
  document.getElementById('wiki-device-brief-body').innerHTML = briefHtml;
  
  let specsHtml = `
    <div><b>Процесор CPU:</b> ${model.cpu.model} (${model.cpu.cores} x ${model.cpu.frequency} MHz)</div>
    <div><b>RAM пам'ять:</b> ${model.ram.size_mb} MB</div>
    <div><b>Ethernet порти:</b> ${model.ports.ethernet}</div>
    <div><b>2.5G порти:</b> ${model.ports.two_5g}</div>
    <div><b>SFP/SFP+ порти:</b> ${model.ports.sfp_plus}</div>
    <div><b>Wi-Fi адаптер:</b> ${model.wifi.supported ? 'Присутній' : 'Відсутній'}</div>
    <div><b>Рекомендовано клієнтів (Office):</b> ${model.recommended_clients.office}</div>
    <div><b>Рекомендовано клієнтів (Hotspot):</b> ${model.recommended_clients.hotspot}</div>
  `;
  document.getElementById('wiki-device-specs').innerHTML = specsHtml;
  
  const caps = model.capabilities;
  let capsHtml = `
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">PCC Load Balancing</div>
      <div style="font-weight:700; color:var(--yellow); font-size:14px;">${caps.pcc.toUpperCase()}</div>
    </div>
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">BGP Routing</div>
      <div style="font-weight:700; color:var(--yellow); font-size:14px;">${caps.bgp.toUpperCase()}</div>
    </div>
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">OSPF Routing</div>
      <div style="font-weight:700; color:var(--purple); font-size:14px;">${caps.ospf.toUpperCase()}</div>
    </div>
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">CAPsMAN Controller</div>
      <div style="font-weight:700; color:var(--green); font-size:14px;">${caps.capsman.toUpperCase()}</div>
    </div>
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">Docker / Containers</div>
      <div style="font-weight:700; color:${caps.container ? 'var(--green)' : 'var(--red)'}; font-size:14px;">${caps.container ? 'SUPPORTED' : 'NO'}</div>
    </div>
    <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
      <div style="font-size:11px; color:var(--text3);">WireGuard Throughput</div>
      <div style="font-weight:700; color:var(--teal); font-size:14px;">${caps.wireguard_throughput} Mbps</div>
    </div>
  `;
  document.getElementById('wiki-device-capabilities').innerHTML = capsHtml;
}

function showCompilerResultTab(tabName) {
  document.querySelectorAll('.compiler-tab-content').forEach(c => c.style.display = 'none');
  document.querySelectorAll('#compiler-results .result-tab').forEach(t => t.classList.remove('active'));
  
  document.getElementById('comp-tab-' + tabName).style.display = 'block';
  document.getElementById('btn-comp-tab-' + tabName).classList.add('active');
}

function copyCompilerOutput(type) {
  let content = "";
  if (type === 'new-config') {
    content = document.getElementById('compiler-out-rsc').textContent;
  } else if (type === 'rollback') {
    content = document.getElementById('compiler-out-rollback').textContent;
  } else if (type === 'secrets') {
    content = document.getElementById('compiler-out-secrets').textContent;
  } else if (type === 'topology') {
    content = document.getElementById('compiler-out-topology').textContent;
  } else if (type === 'diff') {
    content = document.getElementById('compiler-out-diff').textContent;
  }
  
  if (!content) {
    showToast('Немає контенту для копіювання');
    return;
  }
  
  navigator.clipboard.writeText(content).then(() => {
    showToast('Скопійовано в буфер обміну!');
  });
}

async function runCompare() {
  const config_old = document.getElementById('compare-old').value.trim();
  const config_new = document.getElementById('compare-new').value.trim();
  if (!config_old || !config_new) { showToast('Заповніть обидва поля!'); return; }
  try {
    const r = await fetch(`${API}/compare`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({config_old, config_new})
    });
    const data = await r.json();
    
    let html = "";
    
    // Added sections
    if (Object.keys(data.added).length > 0) {
      html += `<div style="color: var(--green); font-weight:700; margin-bottom:10px;">➕ ДОДАНІ СЕКЦІЇ:</div>`;
      for (const [section, lines] of Object.entries(data.added)) {
        html += `<div style="margin-left:12px; font-weight:600; color:var(--accent);">${section}</div>`;
        html += `<div style="margin-left:24px; color:var(--green); margin-bottom:12px;">${lines.map(l => '+ ' + l).join('\n')}</div>`;
      }
    }
    
    // Removed sections
    if (Object.keys(data.removed).length > 0) {
      html += `<div style="color: var(--red); font-weight:700; margin-bottom:10px;">➖ ВИДАЛЕНІ СЕКЦІЇ:</div>`;
      for (const [section, lines] of Object.entries(data.removed)) {
        html += `<div style="margin-left:12px; font-weight:600; color:var(--accent);">${section}</div>`;
        html += `<div style="margin-left:24px; color:var(--red); margin-bottom:12px;">${lines.map(l => '- ' + l).join('\n')}</div>`;
      }
    }
    
    // Changed sections
    if (Object.keys(data.changed).length > 0) {
      html += `<div style="color: var(--yellow); font-weight:700; margin-bottom:10px;">🔄 ЗМІНЕНІ СЕКЦІЇ:</div>`;
      for (const [section, diff] of Object.entries(data.changed)) {
        html += `<div style="margin-left:12px; font-weight:600; color:var(--accent);">${section}</div>`;
        if (diff.removed.length > 0) {
          html += `<div style="margin-left:24px; color:var(--red);">${diff.removed.map(l => '- ' + l).join('\n')}</div>`;
        }
        if (diff.added.length > 0) {
          html += `<div style="margin-left:24px; color:var(--green);">${diff.added.map(l => '+ ' + l).join('\n')}</div>`;
        }
        html += `<div style="margin-bottom:12px;"></div>`;
      }
    }
    
    if (html === "") {
      html = `<div style="color: var(--text2); text-align:center;">Конфігурації ідентичні!</div>`;
    }
    
    document.getElementById('compare-diff-output').innerHTML = html;
    document.getElementById('compare-results').style.display = 'block';
    showToast('Порівняння завершено!');
  } catch(e) {
    showToast('Помилка порівняння');
  }
}

async function runGenerate() {
  const vlanRows = document.querySelectorAll('#gen-vlans .vlan-row');
  const ssidRows = document.querySelectorAll('#gen-ssids .vlan-row');
  const vlans = [...vlanRows].map(r => {
    const inputs = r.querySelectorAll('input');
    return { id: parseInt(inputs[0].value)||10, name: inputs[1].value||'vlan', gateway: inputs[2].value||'10.10.0.1' };
  });
  const ssids = [...ssidRows].map(r => {
    const inputs = r.querySelectorAll('input');
    return { name: inputs[0].value||'Network', vlan: parseInt(inputs[1].value)||10 };
  });
  const capsman = document.getElementById('gen-capsman-toggle').classList.contains('on');
  try {
    const r = await fetch(`${API}/generate`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({
        device_type: document.getElementById('gen-device').value,
        ros_version: document.getElementById('gen-ros-version').value,
        country: document.getElementById('gen-country').value,
        vlans, ssids, capsman,
        wifi_password: document.getElementById('gen-wifi-password').value,
        dns_mode: document.getElementById('gen-dns').value,
        dns_custom: document.getElementById('gen-dns-custom').value,
        ntp_mode: document.getElementById('gen-ntp').value,
        ntp_custom: document.getElementById('gen-ntp-custom').value,
        firewall_profile: document.getElementById('gen-firewall').value
      })
    });
    const data = await r.json();
    
    // Highlight the CLI output with our HSL highlighting
    document.getElementById('gen-output').innerHTML = highlightROS(data.config);
    document.getElementById('gen-output-card').style.display = 'block';
  } catch(e) { showToast('Помилка генерації'); }
}

function copyConfig() {
  copyText(document.getElementById('gen-output').textContent);
}

function downloadConfig() {
  const text = document.getElementById('gen-output').textContent;
  const blob = new Blob([text], {type:'text/plain'});
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'mikrotik-config.rsc';
  a.click();
}

// ── Knowledge Base ──
async function addKnowledge() {
  const problem = document.getElementById('kb-problem').value.trim();
  const solution = document.getElementById('kb-solution').value.trim();
  const tags = document.getElementById('kb-tags').value.trim();
  if (!problem || !solution) { showToast('Заповніть проблему та рішення'); return; }
  try {
    await fetch(`${API}/knowledge`, {
      method: 'POST', headers: {'Content-Type':'application/json'},
      body: JSON.stringify({problem, solution, tags})
    });
    document.getElementById('kb-problem').value = '';
    document.getElementById('kb-solution').value = '';
    document.getElementById('kb-tags').value = '';
    showToast('Збережено в базу знань!');
    loadKnowledge();
  } catch(e) { showToast('Помилка'); }
}

async function loadKnowledge() {
  try {
    const r = await fetch(`${API}/knowledge`);
    allKb = await r.json();
    renderKb(allKb);
  } catch(e) {}
}

function renderKb(items) {
  const el = document.getElementById('kb-list');
  if (!items.length) {
    el.innerHTML = '<div class="empty-state"><div class="icon">📚</div><p>База знань порожня. Додайте перше рішення.</p></div>';
    return;
  }
  el.innerHTML = items.map(k => `
    <div class="kb-item">
      <div class="kb-item-content">
        <div class="kb-problem">${escHtml(k.problem)}</div>
        <div class="kb-solution">${escHtml(k.solution)}</div>
        ${k.tags ? `<div class="kb-tags">${k.tags.split(',').map(t=>`<span class="kb-tag">${escHtml(t.trim())}</span>`).join('')}</div>` : ''}
        <div class="kb-meta">Використань: ${k.used_count} · ${k.created_at.split('T')[0]||k.created_at.split(' ')[0]}</div>
      </div>
      <div style="display:flex;flex-direction:column;gap:6px">
        <button class="btn btn-secondary btn-sm" onclick="copyText('${escHtml(k.solution)}')">📋</button>
        <button class="btn btn-danger btn-sm" onclick="deleteKnowledge(${k.id})">🗑</button>
      </div>
    </div>
  `).join('');
}

function filterKb() {
  const q = document.getElementById('kb-filter').value.toLowerCase();
  const filtered = allKb.filter(k =>
    k.problem.toLowerCase().includes(q) ||
    k.solution.toLowerCase().includes(q) ||
    (k.tags||'').toLowerCase().includes(q)
  );
  renderKb(filtered);
}

async function deleteKnowledge(id) {
  if (!confirm('Видалити запис?')) return;
  await fetch(`${API}/knowledge/${id}`, {method:'DELETE'});
  showToast('Видалено');
  loadKnowledge();
}

// ── History ──
async function loadHistory() {
  try {
    const r = await fetch(`${API}/history`);
    const items = await r.json();
    const el = document.getElementById('history-list');
    if (!items.length) {
      el.innerHTML = '<div class="empty-state"><div class="icon">🕐</div><p>Історія порожня. Запустіть перший аудит.</p></div>';
      return;
    }
    el.innerHTML = items.map(h => {
      const sc = h.summary.score;
      const col = scoreColor(sc);
      const date = (h.created_at||'').replace('T',' ').split('.')[0];
      return `
        <div class="hist-item">
          <div class="hist-score ${col}">${sc}</div>
          <div class="hist-info">
            <div class="hist-name">📄 ${escHtml(h.filename||'config')}</div>
            <div class="hist-date">${date} · ${h.issues_count} помилок · ${h.summary.total_warnings||0} попереджень</div>
          </div>
          <div style="display:flex;gap:8px">
            <span class="pill ${col}">${sc >= 80 ? 'Добре' : sc >= 50 ? 'Середньо' : 'Критично'}</span>
          </div>
        </div>
      `;
    }).join('');
  } catch(e) {}
}

// ── Loading ──
let loadingEl = null;
function showLoading(afterId) {
  loadingEl = document.createElement('div');
  loadingEl.className = 'loading';
  loadingEl.innerHTML = '<div class="spinner"></div><span>Аналізую конфіг...</span>';
  const after = document.getElementById(afterId);
  after.parentNode.insertBefore(loadingEl, after);
}
function hideLoading() { if(loadingEl) { loadingEl.remove(); loadingEl = null; } }

// ── Drag & Drop ──
document.addEventListener('dragover', e => e.preventDefault());
document.addEventListener('drop', e => {
  e.preventDefault();
  const file = e.dataTransfer.files[0];
  if (file) {
    const fd = new FormData();
    fd.append('file', file);
    showLoading('audit-results');
    fetch(`${API}/analyze/upload`, {method:'POST', body:fd})
      .then(r => r.json()).then(data => {
        hideLoading();
        file.text().then(t => { document.getElementById('audit-config').value = t; });
        renderAudit(data);
        goto('audit');
      }).catch(() => { hideLoading(); showToast('Помилка'); });
  }
});

// ── Policy ──────────────────────────────────────────────────────────────────

function tog(id) {
  return document.getElementById(id) && document.getElementById(id).classList.contains('on');
}
function setTog(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  if (val) el.classList.add('on'); else el.classList.remove('on');
}

async function loadPolicy() {
  try {
    const r = await fetch(`${API}/policy`);
    const p = await r.json();
    if (!p || Object.keys(p).length === 0) {
      setTog('pol-ssh-crypto-toggle', true);
      return;
    }
    const dis = (p.disabled_services || []).join(',');
    document.getElementById('pol-disabled-services').value = dis;
    if (p.winbox_port) document.getElementById('pol-winbox-port').value = p.winbox_port;
    if (p.ssh_port) document.getElementById('pol-ssh-port').value = p.ssh_port;
    if (p.winbox_allowed_addresses) document.getElementById('pol-winbox-addr').value = p.winbox_allowed_addresses;
    if (p.ssh_allowed_addresses) document.getElementById('pol-ssh-addr').value = p.ssh_allowed_addresses;
    setTog('pol-ssh-crypto-toggle', p.ssh_strong_crypto !== false);
    setTog('pol-ipv6-toggle', p.disable_ipv6 === true);
    if (p.identity_prefix) document.getElementById('pol-identity-prefix').value = p.identity_prefix;
    if (p.identity_regex) document.getElementById('pol-identity-regex').value = p.identity_regex;
    if (p.identity_example) document.getElementById('pol-identity-example').value = p.identity_example;
    setTog('pol-syslog-toggle', p.syslog_enabled === true);
    if (p.syslog_host) document.getElementById('pol-syslog-host').value = p.syslog_host;
    if (p.syslog_port) document.getElementById('pol-syslog-port').value = p.syslog_port;
    if (p.syslog_topics) document.getElementById('pol-syslog-topics').value = p.syslog_topics;
    if (p.ntp_primary) document.getElementById('pol-ntp-primary').value = p.ntp_primary;
    if (p.ntp_secondary) document.getElementById('pol-ntp-secondary').value = p.ntp_secondary;
    if (p.dns_servers) document.getElementById('pol-dns-servers').value = p.dns_servers;
    
    document.getElementById('pol-custom-rules').innerHTML = '';
    (p.custom_rules || []).forEach(r => addCustomRule(r));
  } catch(e) {
    console.error('loadPolicy error', e);
    setTog('pol-ssh-crypto-toggle', true);
  }
}

function addCustomRule(data) {
  const container = document.getElementById('pol-custom-rules');
  const idx = container.children.length;
  const div = document.createElement('div');
  div.className = 'card';
  div.style.cssText = 'padding:12px;margin-bottom:8px;background:var(--bg3);border:1px solid var(--border)';
  div.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px">
      <span style="font-size:12px;font-weight:600;color:var(--text2)">Правило #${idx+1}</span>
      <button class="btn btn-danger btn-sm" onclick="this.closest('.card').remove()">✕</button>
    </div>
    <label>Опис порушення (що показувати)</label>
    <input type="text" class="cr-desc" value="${data && data.description ? data.description : ''}" placeholder="Напр: має бути вимкнений LLDP на всіх інтерфейсах" style="margin-bottom:8px">
    <label>Розділ конфігу (ключ секції)</label>
    <input type="text" class="cr-section" value="${data && data.section ? data.section : ''}" placeholder="/ip neighbor discovery-settings" style="margin-bottom:8px">
    <label>Обов'язковий рядок (має бути присутній)</label>
    <input type="text" class="cr-must" value="${data && data.must_contain ? data.must_contain : ''}" placeholder="discover-interface-list=none" style="margin-bottom:8px">
    <label>Команда виправлення</label>
    <input type="text" class="cr-fix" value="${data && data.fix ? data.fix : ''}" placeholder="/ip neighbor discovery-settings set discover-interface-list=none">
  `;
  container.appendChild(div);
}

function collectCustomRules() {
  return Array.from(document.querySelectorAll('#pol-custom-rules .card')).map(card => ({
    description: card.querySelector('.cr-desc').value.trim(),
    section: card.querySelector('.cr-section').value.trim(),
    must_contain: card.querySelector('.cr-must').value.trim(),
    fix: card.querySelector('.cr-fix').value.trim(),
  })).filter(r => r.must_contain);
}

async function savePolicy() {
  const policy = {
    disabled_services: document.getElementById('pol-disabled-services').value.split(',').map(s => s.trim()).filter(Boolean),
    enabled_services: ['winbox','ssh'],
    winbox_port: parseInt(document.getElementById('pol-winbox-port').value) || 8291,
    ssh_port: parseInt(document.getElementById('pol-ssh-port').value) || 22,
    winbox_allowed_addresses: document.getElementById('pol-winbox-addr').value.trim(),
    ssh_allowed_addresses: document.getElementById('pol-ssh-addr').value.trim(),
    ssh_strong_crypto: tog('pol-ssh-crypto-toggle'),
    disable_ipv6: tog('pol-ipv6-toggle'),
    identity_prefix: document.getElementById('pol-identity-prefix').value.trim(),
    identity_regex: document.getElementById('pol-identity-regex').value.trim(),
    identity_example: document.getElementById('pol-identity-example').value.trim(),
    syslog_enabled: tog('pol-syslog-toggle'),
    syslog_host: document.getElementById('pol-syslog-host').value.trim(),
    syslog_port: parseInt(document.getElementById('pol-syslog-port').value) || 514,
    syslog_topics: document.getElementById('pol-syslog-topics').value.trim(),
    ntp_primary: document.getElementById('pol-ntp-primary').value.trim(),
    ntp_secondary: document.getElementById('pol-ntp-secondary').value.trim(),
    dns_servers: document.getElementById('pol-dns-servers').value.trim(),
    custom_rules: collectCustomRules(),
  };
  try {
    const r = await fetch(`${API}/policy`, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(policy)
    });
    if (r.ok) {
      const el = document.getElementById('pol-save-status');
      el.textContent = '✅ Регламент збережено!';
      setTimeout(() => el.textContent = '', 3000);
    }
  } catch(e) {
    document.getElementById('pol-save-status').textContent = '❌ Помилка збереження';
  }
}

// ── Design Suite ──
let designTemplates = {};
let designProfiles = {};
let currentDesignTemplateId = '';

async function loadDesignTemplates() {
  if (Object.keys(designTemplates).length > 0) return;
  try {
    const r = await fetch(`${API}/design/templates`);
    const data = await r.json();
    designTemplates = data.templates;
    designProfiles = data.profiles;
    
    // Populate templates dropdown
    const tplSelect = document.getElementById('design-template-select');
    tplSelect.innerHTML = Object.keys(designTemplates).map(id => `
      <option value="${id}">${designTemplates[id].title}</option>
    `).join('');
    
    // Populate profiles dropdown
    const profSelect = document.getElementById('design-profile-select');
    profSelect.innerHTML = '<option value="">-- Виберіть профіль (за замовчуванням) --</option>' + 
      Object.keys(designProfiles).map(id => `
        <option value="${id}">${designProfiles[id].title}</option>
      `).join('');
      
    // Set first template as active
    onDesignTemplateChange();
  } catch(e) {
    showToast('Помилка завантаження шаблонів дизайну');
  }
}

function onDesignTemplateChange() {
  const tplId = document.getElementById('design-template-select').value;
  if (!tplId || !designTemplates[tplId]) return;
  
  const template = designTemplates[tplId];
  currentDesignTemplateId = tplId;
  document.getElementById('design-template-desc').textContent = template.description;
  
  // Prefill variables
  const vars = template.variables || {};
  
  // Standard site variables
  const standardVars = ['SITE_NAME', 'WAN_INTERFACE', 'LAN_BRIDGE', 'COUNTRY', 'TIMEZONE', 'WIREGUARD_PORT'];
  standardVars.forEach(v => {
    const input = document.getElementById('var-' + v);
    if (input) {
      input.value = vars[v] || '';
    }
  });
  
  // VLAN/IP Designer variables
  const vlanVars = [
    'MGMT_VLAN', 'MGMT_SUBNET', 'MGMT_GATEWAY',
    'STAFF_VLAN', 'STAFF_SUBNET', 'STAFF_GATEWAY',
    'GUEST_VLAN', 'GUEST_SUBNET', 'GUEST_GATEWAY',
    'IOT_VLAN', 'IOT_SUBNET', 'IOT_GATEWAY',
    'CCTV_VLAN', 'CCTV_SUBNET', 'CCTV_GATEWAY'
  ];
  vlanVars.forEach(v => {
    const input = document.getElementById('var-' + v);
    if (input) {
      input.value = vars[v] || '';
    }
  });
  
  // Clear outputs
  clearDesignOutputs();
}

function applyDesignProfile() {
  const profId = document.getElementById('design-profile-select').value;
  if (!profId) return;
  if (!designProfiles[profId]) return;
  
  const profile = designProfiles[profId];
  
  // Reset fields to avoid mixing Profiles
  const vlanVars = [
    'MGMT_VLAN', 'MGMT_SUBNET', 'MGMT_GATEWAY',
    'STAFF_VLAN', 'STAFF_SUBNET', 'STAFF_GATEWAY',
    'GUEST_VLAN', 'GUEST_SUBNET', 'GUEST_GATEWAY',
    'IOT_VLAN', 'IOT_SUBNET', 'IOT_GATEWAY',
    'CCTV_VLAN', 'CCTV_SUBNET', 'CCTV_GATEWAY'
  ];
  vlanVars.forEach(v => {
    const el = document.getElementById('var-' + v);
    if (el) el.value = '';
  });
  
  profile.vlans.forEach(vlan => {
    const name = vlan.name.toLowerCase();
    let prefix = '';
    if (name.includes('mgmt') || name.includes('management')) prefix = 'MGMT';
    else if (name.includes('staff') || name.includes('lan_bridge')) prefix = 'STAFF';
    else if (name.includes('guest')) prefix = 'GUEST';
    else if (name.includes('iot')) prefix = 'IOT';
    else if (name.includes('cctv')) prefix = 'CCTV';
    
    if (prefix) {
      const vlanIdInput = document.getElementById(`var-${prefix}_VLAN`);
      const subnetInput = document.getElementById(`var-${prefix}_SUBNET`);
      const gatewayInput = document.getElementById(`var-${prefix}_GATEWAY`);
      
      if (vlanIdInput) vlanIdInput.value = vlan.id;
      if (subnetInput) subnetInput.value = vlan.subnet;
      if (gatewayInput) gatewayInput.value = vlan.gateway;
    }
  });
  
  showToast(`Застосовано профіль: ${profile.title}`);
}

function showDesignSubtab(subtab) {
  document.querySelectorAll('.design-subtab-content').forEach(el => el.style.display = 'none');
  document.getElementById('subtab-' + subtab).style.display = 'block';
  
  document.querySelectorAll('#page-design .result-tabs:first-child .result-tab').forEach(el => el.classList.remove('active'));
  document.getElementById('btn-' + subtab).classList.add('active');
}

function showDesignOutputTab(tabId) {
  document.querySelectorAll('.design-output-content').forEach(el => el.style.display = 'none');
  document.getElementById(tabId).style.display = 'block';
  
  document.querySelectorAll('#design-output-tabs-container .result-tab').forEach(el => el.classList.remove('active'));
  event.target.classList.add('active');
}

async function generateDesignedConfig() {
  const tplId = currentDesignTemplateId;
  if (!tplId) {
    showToast('Оберіть шаблон');
    return;
  }
  
  // Collect all variables
  const variables = {};
  const allVarInputs = document.querySelectorAll('[id^="var-"]');
  allVarInputs.forEach(input => {
    const key = input.id.replace('var-', '');
    if (input.value.trim()) {
      variables[key] = input.value.trim();
    }
  });
  
  try {
    showToast('Генерація конфігурації...');
    const r = await fetch(`${API}/design/generate`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        template_id: tplId,
        variables: variables
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка генерації');
      return;
    }
    
    const data = await r.json();
    
    // 1. Update CLI Output (.rsc)
    document.getElementById('design-rsc-code').innerHTML = highlightROS(data.config);
    
    // 2. Update Documentation Output
    document.getElementById('design-doc-md').textContent = data.documentation;
    
    // 3. Update VLAN Table
    const tbody = document.getElementById('design-vlan-table-body');
    if (data.vlan_table && data.vlan_table.length > 0) {
      tbody.innerHTML = data.vlan_table.map(v => `
        <tr>
          <td><strong>${v.vlan_id}</strong></td>
          <td>vlan_${v.name}</td>
          <td><code>${v.subnet}</code></td>
          <td><code>${v.gateway}</code></td>
          <td>${v.description}</td>
        </tr>
      `).join('');
    } else {
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text3);">Немає VLAN для відображення</td></tr>`;
    }
    
    // 4. Update Connectivity Scheme
    document.getElementById('design-scheme-ascii').textContent = data.connectivity_scheme;
    
    // 5. Update IP Plan Validation Status
    const valStatus = document.getElementById('ip-plan-validation-status');
    if (data.ip_plan_errors && data.ip_plan_errors.length > 0) {
      valStatus.innerHTML = data.ip_plan_errors.map(err => `
        <div class="issue-item warning" style="margin-bottom:6px; padding: 6px 12px; font-size: 11.5px;">⚠️ ${escHtml(err)}</div>
      `).join('');
      // Open IP plan tab to show issues
      showDesignSubtab('design-ip');
    } else {
      valStatus.innerHTML = `<div class="issue-item info" style="margin-bottom:6px; padding: 6px 12px; font-size: 11.5px;">✅ Конфліктів підмереж не виявлено.</div>`;
    }
    
    // 6. Update Pre-generation Audit Report
    const auditEl = document.getElementById('design-audit-issues-list');
    const audit = data.audit;
    let issuesHtml = '';
    
    if (audit && audit.production_readiness) {
      const pr = audit.production_readiness;
      
      // Update Premium Gauge
      document.getElementById('design-results-premium-card').style.display = 'flex';
      const circle = document.getElementById('design-readiness-circle');
      const num = document.getElementById('design-readiness-num');
      const verdict = document.getElementById('design-readiness-verdict');
      const summary = document.getElementById('design-readiness-summary');
      
      const score = pr.score;
      num.textContent = score + '%';
      
      // Animation of circular gauge
      const offset = 251.2 - (251.2 * score) / 100;
      circle.style.strokeDashoffset = offset;
      
      if (score >= 80) {
        circle.style.stroke = 'var(--green)';
        verdict.innerHTML = `<span style="color:var(--green)">${pr.verdict}</span>`;
      } else if (score >= 50) {
        circle.style.stroke = 'var(--yellow)';
        verdict.innerHTML = `<span style="color:var(--yellow)">${pr.verdict}</span>`;
      } else {
        circle.style.stroke = 'var(--red)';
        verdict.innerHTML = `<span style="color:var(--red)">${pr.verdict}</span>`;
      }
      
      summary.textContent = `Аудит згенерованої конфігурації: ${audit.summary.total_issues} помилок та ${audit.summary.total_warnings} попереджень.`;
      
      // Render issues
      let listItems = [];
      
      if (pr.critical_failures && pr.critical_failures.length > 0) {
        pr.critical_failures.forEach(cf => {
          listItems.push(`<div class="issue-item error">❌ [КРИТИЧНО] ${escHtml(cf)}</div>`);
        });
      }
      
      // Pull and sort high issues/warnings from categories
      const categories = ["l2", "vlan_ext", "dhcp_ext", "wifi_ext", "firewall", "security_ext", "services", "monitoring", "performance_ext"];
      categories.forEach(cat => {
        const catData = audit[cat];
        if (catData) {
          if (catData.issues) {
            catData.issues.forEach(iss => {
              listItems.push(`<div class="issue-item error">🔴 [${cat.toUpperCase()}] ${escHtml(iss)}</div>`);
            });
          }
          if (catData.warnings) {
            catData.warnings.forEach(warn => {
              listItems.push(`<div class="issue-item warning">🟡 [${cat.toUpperCase()}] ${escHtml(warn)}</div>`);
            });
          }
        }
      });
      
      if (listItems.length > 0) {
        issuesHtml = listItems.join('');
      } else {
        issuesHtml = '<div class="issue-item info">✅ Жодних зауважень до згенерованого конфігу немає! Пристрій готовий до продакшну.</div>';
      }
    } else {
      issuesHtml = '<div class="issue-item info">ℹ️ Звіт про аудит порожній.</div>';
    }
    
    auditEl.innerHTML = issuesHtml;
    
    showToast('Згенеровано та перевірено успішно!');
  } catch(e) {
    showToast('Помилка при генерації: ' + e);
  }
}

function clearDesignOutputs() {
  document.getElementById('design-rsc-code').innerHTML = '# Оберіть шаблон та натисніть згенерувати';
  document.getElementById('design-doc-md').textContent = '';
  document.getElementById('design-vlan-table-body').innerHTML = `<tr><td colspan="5" style="text-align:center; color:var(--text3);">Дані відсутні. Згенеруйте конфіг.</td></tr>`;
  document.getElementById('design-scheme-ascii').textContent = '';
  document.getElementById('design-results-premium-card').style.display = 'none';
  document.getElementById('design-audit-issues-list').innerHTML = '<div class="issue-item info">ℹ️ Звіт про аудит буде згенеровано разом із конфігурацією.</div>';
  document.getElementById('ip-plan-validation-status').innerHTML = '';
}

function checkSubnetOverlaps() {
  const vlan_list = [];
  const vlans_to_add = [
    ["MGMT_VLAN", "MGMT_SUBNET", "MGMT_GATEWAY"],
    ["STAFF_VLAN", "STAFF_SUBNET", "STAFF_GATEWAY"],
    ["GUEST_VLAN", "GUEST_SUBNET", "GUEST_GATEWAY"],
    ["IOT_VLAN", "IOT_SUBNET", "IOT_GATEWAY"],
    ["CCTV_VLAN", "CCTV_SUBNET", "CCTV_GATEWAY"]
  ];
  
  vlans_to_add.forEach(item => {
    const v_id = document.getElementById('var-' + item[0]).value.trim();
    const subnet = document.getElementById('var-' + item[1]).value.trim();
    const gateway = document.getElementById('var-' + item[2]).value.trim();
    
    if (v_id || subnet || gateway) {
      vlan_list.push({
        id: v_id,
        name: item[0].replace('_VLAN', '').toLowerCase(),
        subnet: subnet,
        gateway: gateway
      });
    }
  });
  
  if (vlan_list.length === 0) {
    showToast('Заповніть хоча б одну підмережу');
    return;
  }
  
  showToast('Перевірка IP плану...');
  generateDesignedConfig();
}

async function runSiteCloner() {
  const config = document.getElementById('clone-config-text').value.trim();
  const src = document.getElementById('clone-src-base').value.trim();
  const dst = document.getElementById('clone-dst-base').value.trim();
  
  if (!config) {
    showToast('Будь ласка, вставте вихідну конфігурацію');
    return;
  }
  if (!src || !dst) {
    showToast('Введіть вихідну та цільову підмережі');
    return;
  }
  
  try {
    showToast('Клонування конфігурації...');
    const r = await fetch(`${API}/design/clone`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        config: config,
        src_base: src,
        dst_base: dst
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка клонування');
      return;
    }
    
    const data = await r.json();
    document.getElementById('cloner-output-pre').innerHTML = highlightROS(data.cloned_config);
    document.getElementById('cloner-output-card').style.display = 'block';
    showToast('Клонування виконано успішно!');
  } catch(e) {
    showToast('Помилка при клонуванні: ' + e);
  }
}

// ── Design Suite Template Extractor, Bulk Cloner, Compare & Blueprints JS ──
let extractedOriginalConfig = '';

async function runTemplateExtractor() {
  const config = document.getElementById('extractor-config-text').value.trim();
  if (!config) {
    showToast('Будь ласка, вставте конфігурацію для аналізу');
    return;
  }
  
  try {
    showToast('Аналіз конфігурації...');
    const r = await fetch(`${API}/design/extract`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ config })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка аналізу конфігурації');
      return;
    }
    
    const data = await r.json();
    extractedOriginalConfig = config;
    
    document.getElementById('extractor-template-pre').innerHTML = highlightROS(data.template_rsc);
    document.getElementById('extractor-json-pre').textContent = data.variables_json;
    document.getElementById('extractor-yaml-pre').textContent = data.variables_yaml;
    
    // Build interactive overrides form
    const form = document.getElementById('extractor-overrides-form');
    form.innerHTML = '';
    
    let html = '<div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">';
    for (const [k, v] of Object.entries(data.variables)) {
      html += `<div>
        <label style="font-size: 11px; margin-bottom: 2px; display:block; color:var(--text2);">${k}</label>
        <input type="text" class="extractor-override-input" data-var="${k}" value="${v}" style="width:100%; padding: 4px 8px; font-size: 12px; background:var(--bg3); border:1px solid var(--border); color:var(--text); border-radius:4px;">
      </div>`;
    }
    html += '</div>';
    form.innerHTML = html;
    
    document.getElementById('extractor-output-card').style.display = 'block';
    showToast('Створено універсальний шаблон та змінні!');
  } catch (e) {
    showToast('Помилка екстрактора: ' + e);
  }
}

async function runCloneFromExtractorBlueprint() {
  if (!extractedOriginalConfig) {
    showToast('Спочатку виконайте екстракцію шаблону');
    return;
  }
  
  const overrides = {};
  document.querySelectorAll('.extractor-override-input').forEach(input => {
    overrides[input.getAttribute('data-var')] = input.value.trim();
  });
  
  try {
    showToast('Генерація конфігурації...');
    const r = await fetch(`${API}/design/clone-blueprint`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        config: extractedOriginalConfig,
        overrides: overrides
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка генерації конфігу');
      return;
    }
    
    const data = await r.json();
    document.getElementById('extractor-clone-pre').innerHTML = highlightROS(data.cloned_config);
    document.getElementById('extractor-clone-output-card').style.display = 'block';
    showToast('Конфігурацію успішно згенеровано!');
  } catch (e) {
    showToast('Помилка генерації: ' + e);
  }
}

function showExtVarTab(format) {
  document.querySelectorAll('.ext-var-content').forEach(el => el.style.display = 'none');
  document.getElementById('ext-var-' + format).style.display = 'block';
  
  document.getElementById('btn-ext-json').classList.remove('active');
  document.getElementById('btn-ext-yaml').classList.remove('active');
  document.getElementById('btn-ext-' + format).classList.add('active');
}

async function autoDetectBulkSourceVars() {
  const config = document.getElementById('bulk-config-text').value.trim();
  if (!config) return;
  try {
    const r = await fetch(`${API}/design/extract`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({config})
    });
    if (r.ok) {
      const data = await r.json();
      let subnet = '';
      for (const [k, v] of Object.entries(data.variables)) {
        if (k.endsWith('_SUBNET')) { subnet = v; break; }
      }
      if (!subnet) {
        for (const [k, v] of Object.entries(data.variables)) {
          if (k.endsWith('_NETWORK') && v.includes('/')) { subnet = v; break; }
        }
      }
      let ssid = data.variables.WORK_SSID || data.variables.GUEST_SSID || '';
      if (!ssid) {
        for (const [k, v] of Object.entries(data.variables)) {
          if (k.includes('SSID')) { ssid = v; break; }
        }
      }
      let pwd = data.variables.WORK_WIFI_PASSWORD || data.variables.GUEST_WIFI_PASSWORD || '';
      if (!pwd) {
        for (const [k, v] of Object.entries(data.variables)) {
          if (k.includes('PASSWORD') || k.includes('PASSPHRASE')) { pwd = v; break; }
        }
      }
      
      if (subnet) document.getElementById('bulk-src-subnet').value = subnet;
      if (ssid) document.getElementById('bulk-src-ssid').value = ssid;
      if (pwd) document.getElementById('bulk-src-pwd').value = pwd;
      
      const list = document.getElementById('bulk-sites-list');
      if (list.children.length === 0) {
        addBulkSiteRow();
      }
    }
  } catch(e) {
    console.error("Auto detect failed", e);
  }
}

function addBulkSiteRow() {
  const list = document.getElementById('bulk-sites-list');
  const index = list.children.length + 1;
  const div = document.createElement('div');
  div.className = 'bulk-site-row card';
  div.style.padding = '12px';
  div.style.background = 'rgba(255,255,255,0.01)';
  div.style.border = '1px solid var(--border)';
  div.style.marginBottom = '8px';
  
  div.innerHTML = `
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:8px;">
      <span style="font-weight:600; font-size:12px; color:var(--text);">🏢 Площадка #${index}</span>
      <button class="btn btn-danger btn-sm" onclick="this.closest('.bulk-site-row').remove()" style="padding: 2px 6px; font-size:11px;">✕ Видалити</button>
    </div>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px; margin-bottom:6px;">
      <div>
        <label style="font-size:11px; margin-bottom: 2px; display:block;">Назва роутера (Identity)</label>
        <input type="text" class="bulk-site-name" placeholder="Site-${index}" value="Site-${index}" style="width:100%; padding: 4px 8px; font-size: 12px; background:var(--bg3); border:1px solid var(--border); color:var(--text); border-radius:4px;">
      </div>
      <div>
        <label style="font-size:11px; margin-bottom: 2px; display:block;">Нова підмережа</label>
        <input type="text" class="bulk-site-subnet" placeholder="10.50.${index}.0/24" value="10.50.${index}.0/24" style="width:100%; padding: 4px 8px; font-size: 12px; background:var(--bg3); border:1px solid var(--border); color:var(--text); border-radius:4px;">
      </div>
    </div>
    <div style="display:grid; grid-template-columns: 1fr 1fr; gap:10px;">
      <div>
        <label style="font-size:11px; margin-bottom: 2px; display:block;">Новий SSID WiFi</label>
        <input type="text" class="bulk-site-ssid" placeholder="WiFi-Site-${index}" value="WiFi-Site-${index}" style="width:100%; padding: 4px 8px; font-size: 12px; background:var(--bg3); border:1px solid var(--border); color:var(--text); border-radius:4px;">
      </div>
      <div>
        <label style="font-size:11px; margin-bottom: 2px; display:block;">Новий пароль WiFi</label>
        <input type="text" class="bulk-site-pwd" placeholder="PassSite${index}!" value="PassSite${index}!" style="width:100%; padding: 4px 8px; font-size: 12px; background:var(--bg3); border:1px solid var(--border); color:var(--text); border-radius:4px;">
      </div>
    </div>
  `;
  list.appendChild(div);
}

async function runBulkCloning() {
  const config = document.getElementById('bulk-config-text').value.trim();
  if (!config) {
    showToast('Будь ласка, вставте вихідну конфігурацію');
    return;
  }
  
  const srcSubnet = document.getElementById('bulk-src-subnet').value.trim();
  const srcSsid = document.getElementById('bulk-src-ssid').value.trim();
  const srcPwd = document.getElementById('bulk-src-pwd').value.trim();
  
  const rows = document.querySelectorAll('.bulk-site-row');
  if (rows.length === 0) {
    showToast('Додайте хоча б одну цільову площадку');
    return;
  }
  
  const sites = [];
  rows.forEach(row => {
    const siteName = row.querySelector('.bulk-site-name').value.trim();
    const dstSubnet = row.querySelector('.bulk-site-subnet').value.trim();
    const dstSsid = row.querySelector('.bulk-site-ssid').value.trim();
    const dstPwd = row.querySelector('.bulk-site-pwd').value.trim();
    
    const ssids = {};
    if (srcSsid && dstSsid) ssids[srcSsid] = dstSsid;
    
    const passwords = {};
    if (srcPwd && dstPwd) passwords[srcPwd] = dstPwd;
    
    sites.push({
      site_name: siteName,
      src_base: srcSubnet,
      dst_base: dstSubnet,
      ssids: ssids,
      passwords: passwords
    });
  });
  
  try {
    showToast('Запуск масового клонування...');
    const r = await fetch(`${API}/design/bulk-clone`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        config: config,
        sites: sites
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка масового клонування');
      return;
    }
    
    const data = await r.json();
    const container = document.getElementById('bulk-results-container');
    container.innerHTML = '';
    
    data.results.forEach((res, i) => {
      const div = document.createElement('div');
      div.className = 'card';
      div.style.border = '1px solid var(--border)';
      div.style.marginBottom = '10px';
      div.innerHTML = `
        <div class="card-title" style="justify-content:space-between; margin-bottom:8px;">
          <span>🏢 ${res.site_name} (${sites[i].dst_base})</span>
          <div style="display:flex; gap:8px;">
            <button class="btn btn-secondary btn-sm" onclick="copyText(document.getElementById('bulk-config-pre-${i}').textContent)">📋 Копіювати</button>
            <button class="btn btn-success btn-sm" onclick="downloadText('bulk-config-pre-${i}', '${res.site_name}_config.rsc')">💾 Скачати</button>
          </div>
        </div>
        <div class="config-output ros-highlight" id="bulk-config-pre-${i}" style="max-height: 200px; font-family: monospace; font-size:12px; overflow-y:auto; padding:10px;">${highlightROS(res.config)}</div>
      `;
      container.appendChild(div);
    });
    
    document.getElementById('bulk-results-card').style.display = 'block';
    showToast('Масове клонування завершено!');
  } catch (e) {
    showToast('Помилка масового клонування: ' + e);
  }
}

async function runCompareSites() {
  const configA = document.getElementById('comp-config-a').value.trim();
  const configB = document.getElementById('comp-config-b').value.trim();
  
  if (!configA || !configB) {
    showToast('Будь ласка, вставте обидві конфігурації');
    return;
  }
  
  try {
    showToast('Порівняння конфігурацій...');
    const r = await fetch(`${API}/design/compare-sites`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        config_a: configA,
        config_b: configB
      })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка порівняння конфігурацій');
      return;
    }
    
    const data = await r.json();
    document.getElementById('compare-sync-pre').textContent = data.sync_rsc;
    
    const addList = document.getElementById('compare-added-list');
    addList.innerHTML = '';
    let addCount = 0;
    for (const [sec, lines] of Object.entries(data.added)) {
      lines.forEach(line => {
        addCount++;
        const li = document.createElement('li');
        li.style.marginBottom = '4px';
        li.innerHTML = `<span style="color:var(--green); font-weight:600;">[+]</span> <b style="color:var(--text);">${sec}:</b> <code style="background:var(--bg3); padding:1px 4px; border-radius:3px;">${line}</code>`;
        addList.appendChild(li);
      });
    }
    if (addCount === 0) addList.innerHTML = '<li style="color:var(--text3);">Немає доданих правил</li>';
    
    const remList = document.getElementById('compare-removed-list');
    remList.innerHTML = '';
    let remCount = 0;
    for (const [sec, lines] of Object.entries(data.removed)) {
      lines.forEach(line => {
        remCount++;
        const li = document.createElement('li');
        li.style.marginBottom = '4px';
        li.innerHTML = `<span style="color:var(--red); font-weight:600;">[-]</span> <b style="color:var(--text);">${sec}:</b> <code style="background:var(--bg3); padding:1px 4px; border-radius:3px;">${line}</code>`;
        remList.appendChild(li);
      });
    }
    if (remCount === 0) remList.innerHTML = '<li style="color:var(--text3);">Немає видалених правил</li>';
    
    document.getElementById('compare-sites-output-card').style.display = 'block';
    showToast('Порівняння виконано успішно!');
  } catch (e) {
    showToast('Помилка при порівнянні: ' + e);
  }
}

async function runGenerateBlueprint() {
  const config = document.getElementById('blueprint-config-text').value.trim();
  if (!config) {
    showToast('Вставте конфігурацію для побудови креслення');
    return;
  }
  
  try {
    showToast('Аналіз та побудова креслення...');
    const r = await fetch(`${API}/design/extract`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ config })
    });
    
    if (!r.ok) {
      const errData = await r.json();
      showToast(errData.error || 'Помилка генерації креслення');
      return;
    }
    
    const data = await r.json();
    const pretty = document.getElementById('blueprint-pretty-view');
    const bp = data.blueprint;
    
    let html = '';
    
    html += `
      <div style="display:flex; justify-content:space-between; align-items:center; background: rgba(59,130,246,0.1); padding: 10px 14px; border-radius: 6px; border-left: 4px solid var(--accent);">
        <div><b>Пристрій:</b> <span class="badge" style="background:var(--accent); color:white; padding: 2px 6px; border-radius:4px; font-size:12px;">${bp.identity || 'Unknown'}</span></div>
        <div><b>RouterOS:</b> ${bp.version || 'v7'} (${bp.hardware || 'Unknown'})</div>
      </div>
    `;
    
    if (bp.bridges && bp.bridges.length > 0) {
      html += `<div><div style="font-weight:600; color:var(--accent); margin-bottom:8px; border-bottom:1px solid var(--border); padding-bottom:4px;">🌉 Комутація & Bridges</div>`;
      bp.bridges.forEach(br => {
        html += `
          <div style="background:var(--bg2); padding:10px; border-radius:6px; border:1px solid var(--border); margin-bottom:8px;">
            <div style="display:flex; justify-content:space-between; margin-bottom:6px;">
              <span><b>Міст:</b> <code style="color:var(--yellow);">${br.name}</code></span>
              <span><b>VLAN Filtering:</b> <span class="badge" style="padding: 2px 6px; font-size:11px; border-radius:4px; background:${br.vlan_filtering ? 'var(--green)' : 'gray'}; color:white;">${br.vlan_filtering ? 'ON' : 'OFF'}</span></span>
            </div>
            <div style="font-size:12px; color:var(--text2);">
              <b>Порти моста:</b> ${br.ports.length === 0 ? 'відсутні' : br.ports.map(p => `<span style="display:inline-block; background:var(--bg3); padding:1px 6px; margin:2px; border-radius:4px; border:1px solid var(--border);">${p.interface} (PVID: ${p.pvid || 1})</span>`).join(' ')}
            </div>
          </div>
        `;
      });
      html += `</div>`;
    }
    
    if (bp.vlans && bp.vlans.length > 0) {
      html += `<div><div style="font-weight:600; color:var(--accent); margin-bottom:8px; border-bottom:1px solid var(--border); padding-bottom:4px;">🏷️ VLAN Сегменти</div>`;
      html += `<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(180px, 1fr)); gap:8px;">`;
      bp.vlans.forEach(vl => {
        html += `
          <div style="background:var(--bg2); padding:8px; border-radius:6px; border:1px solid var(--border); text-align:center;">
            <div style="font-size:14px; font-weight:700; color:var(--yellow);">VLAN ${vl.id}</div>
            <div style="font-weight:600; font-size:12px; margin:2px 0;">${vl.name}</div>
            <div style="font-size:11px; color:var(--text3);">інт: ${vl.interface}</div>
          </div>
        `;
      });
      html += `</div></div>`;
    }
    
    if (bp.ips && bp.ips.length > 0) {
      html += `<div><div style="font-weight:600; color:var(--accent); margin-bottom:8px; border-bottom:1px solid var(--border); padding-bottom:4px;">🌐 IP Адреси Інтерфейсів</div>`;
      html += `<div style="display:flex; flex-direction:column; gap:4px;">`;
      bp.ips.forEach(ip => {
        html += `
          <div style="display:flex; justify-content:space-between; background:var(--bg2); padding:6px 10px; border-radius:6px; border:1px solid var(--border);">
            <span><b>${ip.interface}</b></span>
            <span><code style="color:var(--yellow); font-weight:600;">${ip.address}</code></span>
          </div>
        `;
      });
      html += `</div></div>`;
    }
    
    const dhcpSrv = bp.dhcp ? bp.dhcp.servers || [] : [];
    if (dhcpSrv.length > 0) {
      html += `<div><div style="font-weight:600; color:var(--accent); margin-bottom:8px; border-bottom:1px solid var(--border); padding-bottom:4px;">🔋 DHCP Сервери та Пули</div>`;
      dhcpSrv.forEach(srv => {
        const pool = (bp.dhcp.pools || []).find(p => p.name === srv.pool);
        html += `
          <div style="background:var(--bg2); padding:10px; border-radius:6px; border:1px solid var(--border); margin-bottom:6px; font-size:12.5px;">
            <div><b>Служба:</b> <code style="color:var(--yellow);">${srv.name}</code> на інтерфейсі <b>${srv.interface}</b></div>
            <div style="margin-top:4px; display:flex; gap:12px; color:var(--text2); font-size:12px;">
              <div>🎨 <b>Пул:</b> ${srv.pool} (${pool ? pool.ranges : 'невідомий діапазон'})</div>
            </div>
          </div>
        `;
      });
      html += `</div>`;
    }
    
    if (bp.services && bp.services.length > 0) {
      html += `<div><div style="font-weight:600; color:var(--accent); margin-bottom:8px; border-bottom:1px solid var(--border); padding-bottom:4px;">🛡️ Статус Мережевих Сервісів</div>`;
      html += `<div style="display:grid; grid-template-columns:repeat(auto-fill, minmax(130px, 1fr)); gap:6px;">`;
      bp.services.forEach(srv => {
        const isDisabled = srv.disabled === true || srv.disabled === 'yes';
        html += `
          <div style="display:flex; justify-content:space-between; align-items:center; background:var(--bg2); padding:6px 10px; border-radius:6px; border:1px solid var(--border); font-size:12px;">
            <span><b>${srv.name}</b></span>
            <span class="badge" style="padding:1px 5px; font-size:10px; border-radius:3px; background:${isDisabled ? 'rgba(239,68,68,0.15)' : 'rgba(16,185,129,0.15)'}; color:${isDisabled ? 'var(--red)' : 'var(--green)'}; border:1px solid ${isDisabled ? 'var(--red)' : 'var(--green)'};">${isDisabled ? 'OFF' : 'ON'}</span>
          </div>
        `;
      });
      html += `</div></div>`;
    }
    
    pretty.innerHTML = html;
    document.getElementById('blueprint-json-pre').textContent = JSON.stringify(bp, null, 2);
    document.getElementById('blueprint-output-container').style.display = 'block';
    showToast('Креслення побудовано успішно!');
  } catch (e) {
    showToast('Помилка побудови креслення: ' + e);
  }
}

let blueprintFormat = 'pretty';
function toggleBlueprintFormat() {
  const pretty = document.getElementById('blueprint-pretty-view');
  const json = document.getElementById('blueprint-json-view');
  if (blueprintFormat === 'pretty') {
    pretty.style.display = 'none';
    json.style.display = 'block';
    blueprintFormat = 'json';
  } else {
    pretty.style.display = 'flex';
    json.style.display = 'none';
    blueprintFormat = 'pretty';
  }
}

// ─── Q&A Wiki search ───
async function searchWikiConcept() {
  const query = document.getElementById('wiki-search-input').value.trim();
  if (!query) {
    showToast('Введіть ключове слово для пошуку');
    return;
  }
  showToast('Пошук у базі знань...');
  try {
    const r = await fetch(`${API}/wiki/learn?q=${encodeURIComponent(query)}`);
    if (!r.ok) {
      showToast('Помилка пошуку');
      return;
    }
    const data = await r.json();
    document.getElementById('wiki-search-result-card').style.display = 'block';
    document.getElementById('wiki-res-name').textContent = data.name || query;
    document.getElementById('wiki-res-explanation').innerHTML = data.explanation ? data.explanation.replace(/\n/g, '<br>') : '';
    
    document.getElementById('wiki-res-caveats').innerHTML = data.caveats ? data.caveats.replace(/\n/g, '<br>') : 'Немає застережень.';
    document.getElementById('wiki-res-best-practice').innerHTML = data.best_practice ? data.best_practice.replace(/\n/g, '<br>') : 'Немає рекомендацій.';
    document.getElementById('wiki-res-examples').textContent = data.examples || '# Немає прикладу';
  } catch (err) {
    showToast('Помилка мережі при пошуку');
    console.error(err);
  }
}

// ─── Presale Hardware Advisor & Simulator ───
async function runHardwareAdvisor() {
  const clients = document.getElementById('advisor-clients').value;
  const wans = document.getElementById('advisor-wans').value;
  const speed = document.getElementById('advisor-speed').value;
  const wifi = document.getElementById('advisor-wifi').checked;
  const vpn = document.getElementById('advisor-vpn').checked;
  const vlan = document.getElementById('advisor-vlan').checked;

  showToast('Отримання рекомендації обладнання...');
  try {
    const r = await fetch(`${API}/design/advisor`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        clients_count: Number(clients),
        wan_count: Number(wans),
        wifi_needed: wifi,
        vpn_needed: vpn,
        vlan_needed: vlan,
        internet_speed: Number(speed)
      })
    });

    if (!r.ok) {
      const err = await r.json();
      showToast('Помилка радника: ' + (err.error || r.statusText));
      return;
    }

    const data = await r.json();
    document.getElementById('advisor-results').style.display = 'block';
    
    document.getElementById('advisor-res-core').textContent = data.core_device;
    document.getElementById('advisor-res-core-desc').textContent = data.core_desc;
    
    document.getElementById('advisor-res-ap').textContent = data.access_ap + (data.ap_count > 0 ? ` (${data.ap_count} шт.)` : '');
    document.getElementById('advisor-res-ap-desc').textContent = data.ap_desc;
    
    document.getElementById('advisor-res-sw').textContent = data.switch_device + (data.switch_count > 0 ? ` (${data.switch_count} шт.)` : '');
    document.getElementById('advisor-res-sw-desc').textContent = data.switch_desc;
    
    const loadPercent = data.estimated_load_percent || 0;
    document.getElementById('advisor-res-load-bar').style.width = loadPercent + '%';
    document.getElementById('advisor-res-load-val').textContent = loadPercent + '%';
    
    const bar = document.getElementById('advisor-res-load-bar');
    if (loadPercent >= 80) {
      bar.style.backgroundColor = 'var(--danger)';
    } else if (loadPercent >= 50) {
      bar.style.backgroundColor = 'var(--warning)';
    } else {
      bar.style.backgroundColor = 'var(--accent)';
    }

    const vlansBody = document.getElementById('advisor-res-vlans-body');
    vlansBody.innerHTML = '';
    if (data.vlans && data.vlans.length > 0) {
      data.vlans.forEach(v => {
        const tr = document.createElement('tr');
        tr.style.borderBottom = '1px solid var(--border)';
        tr.innerHTML = `
          <td style="padding:6px; font-weight:bold; color:var(--accent);">${v.id}</td>
          <td style="padding:6px;">${v.name}</td>
          <td style="padding:6px; font-family:var(--font-mono);">${v.subnet}</td>
          <td style="padding:6px; color:var(--text2);">${v.desc || ''}</td>
        `;
        vlansBody.appendChild(tr);
      });
    } else {
      vlansBody.innerHTML = '<tr><td colspan="4" style="text-align:center; color:var(--text3); padding:10px;">VLAN не рекомендовано</td></tr>';
    }
    showToast('Рекомендацію оновлено успішно!');
  } catch (err) {
    showToast('Помилка підключення до сервера');
    console.error(err);
  }
}

async function runCapacitySimulation() {
  const device = document.getElementById('sim-device-select').value;
  const clients = document.getElementById('sim-clients-count').value;
  const speed = document.getElementById('sim-wan-speed').value;
  
  let configText = "";
  const compilerInput = document.getElementById('compiler-input-config');
  if (compilerInput && compilerInput.value.trim()) {
    configText = compilerInput.value.trim();
  }
  
  showToast('Симуляція навантаження пристрою...');
  try {
    const r = await fetch(`${API}/design/simulate`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        model_key: device,
        clients_count: Number(clients),
        wan_speed_mbps: Number(speed),
        config: configText
      })
    });
    
    if (!r.ok) {
      const err = await r.json();
      showToast('Помилка симуляції: ' + (err.error || r.statusText));
      return;
    }
    
    const data = await r.json();
    document.getElementById('sim-results').style.display = 'block';
    
    const cpu = data.cpu_percent || 0;
    const ram = data.ram_percent || 0;
    
    document.getElementById('sim-cpu-bar').style.width = cpu + '%';
    document.getElementById('sim-cpu-val').textContent = cpu + '%';
    document.getElementById('sim-cpu-bar').style.backgroundColor = cpu >= 80 ? 'var(--danger)' : cpu >= 50 ? 'var(--warning)' : 'var(--green)';
    
    document.getElementById('sim-ram-bar').style.width = ram + '%';
    document.getElementById('sim-ram-val').textContent = ram + '%';
    document.getElementById('sim-ram-bar').style.backgroundColor = ram >= 80 ? 'var(--danger)' : ram >= 50 ? 'var(--warning)' : 'var(--green)';
    
    document.getElementById('sim-limit-nat').textContent = (data.throughput_mbps || 0) + ' Mbps';
    let fwLimit = Math.round((data.throughput_mbps || 0) * 0.6);
    let vpnLimit = data.wireguard_throughput || 200;
    
    document.getElementById('sim-limit-fw').textContent = fwLimit + ' Mbps';
    document.getElementById('sim-limit-vpn').textContent = vpnLimit + ' Mbps';
    
    const warnContainer = document.getElementById('sim-warnings-container');
    const warnList = document.getElementById('sim-warnings-list');
    warnList.innerHTML = '';
    
    let simWarnings = data.warnings || [];
    if (cpu >= 90) {
      simWarnings.push('Критичне навантаження процесора (>90%). Можлива втрата пакетів та зависання пристрою.');
    }
    if (Number(speed) > (data.throughput_mbps || 0)) {
      simWarnings.push(`Трафік (${speed} Mbps) перевищує максимальну пропускну здатність пристрою (${data.throughput_mbps} Mbps).`);
    }
    
    if (simWarnings.length > 0) {
      simWarnings.forEach(w => {
        const li = document.createElement('li');
        li.textContent = w;
        warnList.appendChild(li);
      });
      warnContainer.style.display = 'block';
    } else {
      warnContainer.style.display = 'none';
    }
    showToast('Симуляцію закінчено!');
  } catch (err) {
    showToast('Помилка підключення до сервера');
    console.error(err);
  }
}

// ─── Enterprise Design Generator ───
let currentGeneratorData = null;
async function runEnterpriseGenerator() {
  const name = document.getElementById('generator-office-name').value.trim() || 'Enterprise';
  const clients = document.getElementById('generator-clients-count').value;
  const wans = document.getElementById('generator-wan-count').value;
  const ap = document.getElementById('generator-ap-count').value;
  
  const guest = document.getElementById('generator-guest-wifi').checked;
  const voip = document.getElementById('generator-voip').checked;
  const cctv = document.getElementById('generator-cctv').checked;
  const mgmt = document.getElementById('generator-mgmt').checked;
  const workstations = document.getElementById('generator-workstations').checked;

  showToast('Генерація Enterprise проекту...');
  try {
    const r = await fetch(`${API}/design/generator`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        office_name: name,
        clients_count: Number(clients),
        wan_count: Number(wans),
        ap_count: Number(ap),
        guest_wifi: guest,
        voip_needed: voip,
        cctv_needed: cctv,
        management_needed: mgmt,
        workstations_needed: workstations
      })
    });

    if (!r.ok) {
      const err = await r.json();
      showToast('Помилка генерації: ' + (err.error || r.statusText));
      return;
    }

    const data = await r.json();
    currentGeneratorData = data;
    
    document.getElementById('generator-results-card').style.display = 'block';
    document.getElementById('generator-out-router').textContent = data.router_rsc;
    document.getElementById('generator-out-rollback').textContent = data.rollback_rsc;
    document.getElementById('generator-out-topology').textContent = data.topology_mmd;
    document.getElementById('generator-out-inventory').textContent = JSON.stringify(data.inventory_json, null, 2);
    document.getElementById('generator-out-documentation').textContent = data.documentation_md;
    document.getElementById('generator-out-checklist').textContent = data.acceptance_checklist_md;
    
    showGeneratorTab('router');
    showToast('Пакет проекту згенеровано успішно!');
  } catch (err) {
    showToast('Помилка підключення до сервера');
    console.error(err);
  }
}

function showGeneratorTab(tabName) {
  document.querySelectorAll('.gen-tab-content').forEach(c => c.style.display = 'none');
  document.querySelectorAll('#generator-result-tabs .result-tab').forEach(t => t.classList.remove('active'));

  document.getElementById('gen-tab-' + tabName).style.display = 'block';
  const tabs = document.querySelectorAll('#generator-result-tabs .result-tab');
  tabs.forEach(t => {
    if (t.getAttribute('onclick').includes(tabName)) {
      t.classList.add('active');
    }
  });
}

function copyGeneratorText(type) {
  let content = "";
  if (type === 'router') content = document.getElementById('generator-out-router').textContent;
  else if (type === 'rollback') content = document.getElementById('generator-out-rollback').textContent;
  else if (type === 'topology') content = document.getElementById('generator-out-topology').textContent;
  else if (type === 'inventory') content = document.getElementById('generator-out-inventory').textContent;
  else if (type === 'documentation') content = document.getElementById('generator-out-documentation').textContent;
  else if (type === 'checklist') content = document.getElementById('generator-out-checklist').textContent;
  
  if (!content) {
    showToast('Контент порожній');
    return;
  }
  copyText(content);
}

function downloadGeneratorFile(type, filename) {
  let content = "";
  if (type === 'router') content = document.getElementById('generator-out-router').textContent;
  else if (type === 'rollback') content = document.getElementById('generator-out-rollback').textContent;
  else if (type === 'topology') content = document.getElementById('generator-out-topology').textContent;
  else if (type === 'inventory') content = document.getElementById('generator-out-inventory').textContent;
  else if (type === 'documentation') content = document.getElementById('generator-out-documentation').textContent;
  else if (type === 'checklist') content = document.getElementById('generator-out-checklist').textContent;

  if (!content) {
    showToast('Контент порожній');
    return;
  }
  const blob = new Blob([content], {type: 'text/plain;charset=utf-8'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

// ─── Digital Twin Packet Tracer ───
function toggleTraceConfigTextarea() {
  const src = document.getElementById('trace-config-source').value;
  const container = document.getElementById('trace-custom-config-container');
  if (src === 'custom') {
    container.style.display = 'block';
  } else {
    container.style.display = 'none';
  }
}

async function runPacketTrace() {
  const source = document.getElementById('trace-config-source').value;
  let rscText = "";
  if (source === 'current') {
    const compilerOut = document.getElementById('compiler-out-rsc');
    const designOut = document.getElementById('design-rsc-code');
    if (compilerOut && compilerOut.textContent.trim()) {
      rscText = compilerOut.textContent.trim();
    } else if (designOut && designOut.textContent.trim() && !designOut.textContent.includes('Оберіть шаблон')) {
      rscText = designOut.textContent.trim();
    } else {
      rscText = "/interface bridge add name=bridge vlan-filtering=yes";
    }
  } else {
    rscText = document.getElementById('trace-custom-config').value.trim();
  }
  
  if (!rscText) {
    showToast('Текст конфігурації для трасування порожній!');
    return;
  }
  
  const srcIp = document.getElementById('trace-src-ip').value.trim();
  const dstIp = document.getElementById('trace-dst-ip').value.trim();
  const dstPort = document.getElementById('trace-dst-port').value.trim();
  const protocol = document.getElementById('trace-protocol').value;
  const connState = document.getElementById('trace-connection-state').value;
  
  showToast('Симуляція трасування пакету...');
  try {
    const r = await fetch(`${API}/design/packet-trace`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({
        config: rscText,
        src_ip: srcIp,
        dst_ip: dstIp,
        protocol: protocol,
        dst_port: dstPort,
        connection_state: connState
      })
    });
    
    if (!r.ok) {
      const err = await r.json();
      showToast('Помилка трасування: ' + (err.error || r.statusText));
      return;
    }
    
    const data = await r.json();
    document.getElementById('trace-results-card').style.display = 'block';
    
    const allowed = data.allowed;
    const verdict = data.verdict || (allowed ? 'ALLOWED' : 'DROPPED');
    
    const banner = document.getElementById('trace-verdict-banner');
    const icon = document.getElementById('trace-verdict-icon');
    const txt = document.getElementById('trace-verdict-text');
    
    txt.textContent = verdict;
    if (allowed) {
      banner.style.background = 'rgba(16, 185, 129, 0.15)';
      banner.style.border = '1px solid var(--success)';
      banner.style.color = 'var(--green)';
      icon.textContent = '✅';
    } else {
      banner.style.background = 'rgba(239, 68, 68, 0.15)';
      banner.style.border = '1px solid var(--danger)';
      banner.style.color = 'var(--red)';
      icon.textContent = '❌';
    }
    
    const stepsContainer = document.getElementById('trace-steps-container');
    stepsContainer.innerHTML = '';
    if (data.trace && data.trace.length > 0) {
      data.trace.forEach(step => {
        const div = document.createElement('div');
        div.style.background = 'rgba(255,255,255,0.02)';
        div.style.padding = '8px 12px';
        div.style.borderRadius = 'var(--radius)';
        div.style.border = '1px solid var(--border)';
        div.style.fontSize = '12.5px';
        
        div.innerHTML = `
          <div style="font-weight:600; color:var(--text);">${step}</div>
        `;
        stepsContainer.appendChild(div);
      });
    } else {
      stepsContainer.innerHTML = '<div style="color:var(--text3); font-style:italic;">Кроки трасування відсутні.</div>';
    }
    showToast('Трасування завершено!');
  } catch (err) {
    showToast('Помилка підключення до сервера');
    console.error(err);
  }
}

// ── Keyboard Shortcuts ──
document.addEventListener('DOMContentLoaded', () => {
  const auditTextarea = document.getElementById('audit-config');
  if (auditTextarea) {
    auditTextarea.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        runAudit();
      }
    });
  }
});
