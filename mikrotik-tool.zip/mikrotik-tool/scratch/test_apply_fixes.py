import re
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Original lines count:", len(lines))
print("Line 2313 original:", repr(lines[2312]))
print("Line 3609 original:", repr(lines[3608]))

# Apply HTML fix: replace line 2313 (empty line) with </div>
lines[2312] = "    </div>\n"

# Apply JS fix: remove line 3609
del lines[3608]

modified_html = "".join(lines)

# 1. Verify HTML divs balance
div_opens = len(re.findall(r'<div\b', modified_html))
div_closes = len(re.findall(r'</div>', modified_html))
print(f"\nModified HTML Div Balance:")
print(f"Opening <div> tags: {div_opens}")
print(f"Closing </div> tags: {div_closes}")
print(f"Difference: {div_opens - div_closes}")

# 2. Verify Page balances
page_matches = list(re.finditer(r'<div[^>]*class="page[^"]*"[^>]*id="([^"]*)"[^>]*>', modified_html))
print(f"\nModified Page Section Balances:")
for idx, match in enumerate(page_matches):
    start_pos = match.start()
    page_id = match.group(1)
    if idx + 1 < len(page_matches):
        end_pos = page_matches[idx+1].start()
    else:
        script_match = re.search(r'<script>', modified_html[start_pos:])
        end_pos = start_pos + script_match.start() if script_match else len(modified_html)
        
    page_html = modified_html[start_pos:end_pos]
    opens = len(re.findall(r'<div\b', page_html))
    closes = len(re.findall(r'</div>', page_html))
    diff = opens - closes
    print(f"Page: {page_id:15s} | Opens: {opens:3d} | Closes: {closes:3d} | Diff: {diff:3d}")

# 3. Verify JS syntax
script_matches = list(re.finditer(r'<script>(.*?)</script>', modified_html, re.DOTALL))
script_content = script_matches[1].group(1)

temp_file = 'scratch/temp_js_check_final.js'
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(script_content)

print("\nRunning node syntax check on final JavaScript...")
res = subprocess.run(['node', '--check', temp_file], capture_output=True, text=True)

if res.returncode == 0:
    print("SUCCESS: Javascript syntax is 100% VALID!")
else:
    print("FAIL: Javascript syntax error:")
    print(res.stderr)
    sys.exit(1)
