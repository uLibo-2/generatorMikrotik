import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Original lines count:", len(lines))
# Line 1469 (0-indexed 1468)
print("Line 1469 original:", repr(lines[1468]))
# Line 1842-1847 (0-indexed 1841-1846)
print("Lines 1842-1847 original:")
for idx in range(1841, 1847):
    print(f"  {idx+1}: {repr(lines[idx])}")

# 1. Create a copy of lines to modify
modified = list(lines)

# Replace line 1469 (index 1468) with the correct closing tags for the expert-design table and card columns
modified[1468] = """                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
"""

# Replace lines 1842-1847 (indices 1841-1846) with the correct closing tags for row, subtab, and Left Column
modified[1841] = "            </div>\n"
modified[1842] = "          </div>\n"
modified[1843] = "        </div>\n"
# delete the remaining 3 lines (indices 1844, 1845, 1846) since they are no longer needed
del modified[1844:1847]

modified_html = "".join(modified)

# 2. Check parent stack of page-compiler
print("\n--- NEW PARENT STACK OF page-compiler ---")
compiler_pos = modified_html.find('id="page-compiler"')
if compiler_pos == -1:
    print("page-compiler not found!")
    sys.exit(1)

stack = []
tag_regex = re.compile(r'<(/?[a-zA-Z0-9:-]+)(?:\s+[^>]*)?>')

for match in tag_regex.finditer(modified_html[:compiler_pos]):
    tag_name = match.group(1)
    if tag_name.startswith('/'):
        tag_name = tag_name[1:]
        if stack and stack[-1][0] == tag_name:
            stack.pop()
    else:
        if not match.group(0).endswith('/>') and tag_name not in ['img', 'br', 'hr', 'input', 'link', 'meta']:
            stack.append((tag_name, match.start(), match.group(0)))

for idx, (tag, start, raw) in enumerate(stack):
    line_no = modified_html.count('\n', 0, start) + 1
    print(f"Level {idx+1}: <{tag}> at line {line_no} | Raw: {raw.strip()}")

# 3. Check all page balances
print("\n--- NEW PAGE SECTION BALANCES ---")
page_matches = list(re.finditer(r'<div[^>]*class="page[^"]*"[^>]*id="([^"]*)"[^>]*>', modified_html))
for idx, match in enumerate(page_matches):
    start_pos = match.start()
    page_id = match.group(1)
    if idx + 1 < len(page_matches):
        end_pos = page_matches[idx+1].start()
    else:
        script_match = re.search(r'<script>', modified_html[start_pos:])
        end_pos = start_pos + script_match.start() if script_match else len(modified_html)
        
    page_html = modified_html[start_pos:end_pos]
    opens = len(re.findall(r'<div\b', page_html))
    closes = len(re.findall(r'</div>', page_html))
    diff = opens - closes
    print(f"Page: {page_id:15s} | Opens: {opens:3d} | Closes: {closes:3d} | Diff: {diff:3d}")

# 4. Check global div tags balance
div_opens = len(re.findall(r'<div\b', modified_html))
div_closes = len(re.findall(r'</div>', modified_html))
print(f"\nGlobal Div Balance: Opens={div_opens}, Closes={div_closes}, Diff={div_opens - div_closes}")
