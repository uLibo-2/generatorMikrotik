import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

print("Original lines count:", len(lines))

# Create a copy of lines to modify
modified = list(lines)

# Replace line 1469 (0-indexed 1468) with 1 table + 4 divs
modified[1468] = """                  </table>
                </div>
              </div>
            </div>
          </div>
"""

# Replace lines 1842-1847 (0-indexed 1841 to 1846) with exactly two closing </div> tags
modified[1841] = "        </div>\n      </div>\n"
del modified[1842:1847]

modified_html = "".join(modified)

# Check all page balances
print("\n--- NEW PAGE SECTION BALANCES ---")
page_matches = list(re.finditer(r'<div[^>]*class="page[^"]*"[^>]*id="([^"]*)"[^>]*>', modified_html))
for idx, match in enumerate(page_matches):
    start_pos = match.start()
    page_id = match.group(1)
    if idx + 1 < len(page_matches):
        end_pos = page_matches[idx+1].start()
    else:
        script_match = re.search(r'<script>', modified_html[start_pos:])
        end_pos = start_pos + script_match.start() if script_match else len(modified_html)
        
    page_html = modified_html[start_pos:end_pos]
    opens = len(re.findall(r'<div\b', page_html))
    closes = len(re.findall(r'</div>', page_html))
    diff = opens - closes
    print(f"Page: {page_id:15s} | Opens: {opens:3d} | Closes: {closes:3d} | Diff: {diff:3d}")

# Check global div tags balance
div_opens = len(re.findall(r'<div\b', modified_html))
div_closes = len(re.findall(r'</div>', modified_html))
print(f"\nGlobal Div Balance: Opens={div_opens}, Closes={div_closes}, Diff={div_opens - div_closes}")
