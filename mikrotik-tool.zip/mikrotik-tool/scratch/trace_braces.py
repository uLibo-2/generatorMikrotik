import sys
import re

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    html = f.read()

script_matches = list(re.finditer(r'<script>(.*?)</script>', html, re.DOTALL))
script_content = script_matches[1].group(1)

def preserve_newlines(m):
    return re.sub(r'[^\n]', ' ', m.group(0))

clean = script_content
clean = re.sub(r'`(?:[^`\\]|\\.)*`', preserve_newlines, clean, flags=re.DOTALL)
clean = re.sub(r'"(?:[^"\\]|\\.)*"', preserve_newlines, clean)
clean = re.sub(r"'(?:[^'\\]|\\.)*'", preserve_newlines, clean)
clean = re.sub(r'/\*.*?\*/', preserve_newlines, clean, flags=re.DOTALL)
clean = re.sub(r'//.*', preserve_newlines, clean)

lines = clean.split('\n')
orig_lines = script_content.split('\n')

start_pos = script_matches[1].start(1)
start_line = html.count('\n', 0, start_pos) + 1

nesting = 0
for idx, (line, orig_line) in enumerate(zip(lines, orig_lines)):
    html_line = start_line + idx
    opens = line.count('{')
    closes = line.count('}')
    prev_nesting = nesting
    nesting += opens - closes
    if 3510 <= html_line <= 3530:
        print(f"HTML {html_line} | Prev: {prev_nesting} -> Nesting: {nesting} (Opens: {opens}, Closes: {closes}) | Content: {orig_line.strip()}")
