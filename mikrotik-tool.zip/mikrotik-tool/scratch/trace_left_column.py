import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

start_line = 1036
end_line = 1841

stack = []
tag_regex = re.compile(r'<(/?[a-zA-Z0-9:-]+)(?:\s+[^>]*)?>')

print(f"Tracing Left Column from line {start_line} to {end_line}:")
for line_idx in range(start_line - 1, end_line):
    line = lines[line_idx]
    line_no = line_idx + 1
    
    # We will replace the mismatched expert design section with our proposed fix to see what is open
    if line_no == 1469:
        line = """                  </table>
                </div>
              </div>
            </div>
          </div>
"""
    
    for match in tag_regex.finditer(line):
        tag_name = match.group(1)
        if tag_name.startswith('/'):
            tag_name = tag_name[1:]
            if stack:
                if stack[-1][0] == tag_name:
                    stack.pop()
                else:
                    print(f"Mismatch at line {line_no}: closing </{tag_name}>, but expected </{stack[-1][0]}> (opened at line {stack[-1][1]})")
                    popped = False
                    for i in range(len(stack)-1, -1, -1):
                        if stack[i][0] == tag_name:
                            stack = stack[:i]
                            popped = True
                            break
                    if not popped:
                        print(f"  (Ignored </{tag_name}>)")
            else:
                print(f"Warning at line {line_no}: closing </{tag_name}> when stack is empty!")
        else:
            if not match.group(0).endswith('/>') and tag_name not in ['img', 'br', 'hr', 'input', 'link', 'meta']:
                stack.append((tag_name, line_no, match.group(0).strip()))

print("\n--- FINAL STACK FOR LEFT COLUMN ---")
for idx, (tag, line_no, raw) in enumerate(stack):
    print(f"Level {idx+1}: <{tag}> opened at line {line_no} | Raw: {raw}")
