import re
import sys

sys.stdout.reconfigure(encoding='utf-8')

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

modified = list(lines)
modified[1468] = """                  </table>
                </div>
              </div>
            </div>
          </div>
"""
modified[1841] = "        </div>\n"
del modified[1842:1847]

modified_html = "".join(modified)

# Find start and end line of page-design in modified_html
start_pos = modified_html.find('id="page-design"')
end_pos = modified_html.find('id="page-compiler"')

start_line = modified_html.count('\n', 0, start_pos) + 1
end_line = modified_html.count('\n', 0, end_pos) + 1

print(f"Tracing page-design from line {start_line} to {end_line}:")

stack = []
tag_regex = re.compile(r'<(/?[a-zA-Z0-9:-]+)(?:\s+[^>]*)?>')

design_lines = modified_html.splitlines()[start_line - 1:end_line]
for idx, line in enumerate(design_lines):
    line_no = start_line + idx
    for match in tag_regex.finditer(line):
        tag_name = match.group(1)
        if tag_name.startswith('/'):
            tag_name = tag_name[1:]
            if stack:
                if stack[-1][0] == tag_name:
                    stack.pop()
                else:
                    print(f"Mismatch at line {line_no}: closing </{tag_name}>, but expected </{stack[-1][0]}> (opened at line {stack[-1][1]})")
                    popped = False
                    for i in range(len(stack)-1, -1, -1):
                        if stack[i][0] == tag_name:
                            stack = stack[:i]
                            popped = True
                            break
                    if not popped:
                        print(f"  (Ignored </{tag_name}>)")
            else:
                print(f"Warning at line {line_no}: closing </{tag_name}> when stack is empty!")
        else:
            if not match.group(0).endswith('/>') and tag_name not in ['img', 'br', 'hr', 'input', 'link', 'meta']:
                stack.append((tag_name, line_no, match.group(0).strip()))

print("\n--- FINAL STACK AT END OF page-design ---")
for idx, (tag, line_no, raw) in enumerate(stack):
    print(f"Level {idx+1}: <{tag}> opened at line {line_no} | Raw: {raw}")
