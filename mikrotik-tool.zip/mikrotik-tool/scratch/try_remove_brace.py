import re
import subprocess
import sys

with open('static/index.html', 'r', encoding='utf-8') as f:
    lines = f.readlines()

# Remove line 3609 (0-indexed 3608)
# Let's verify line content first
print("Line 3609 content:", repr(lines[3608]))

modified_lines = list(lines)
# Delete line 3609
del modified_lines[3608]

modified_html = "".join(modified_lines)

# Extract scripts
script_matches = list(re.finditer(r'<script>(.*?)</script>', modified_html, re.DOTALL))
script_content = script_matches[1].group(1)

# Save to temporary file
temp_file = 'scratch/temp_js_check_mod.js'
with open(temp_file, 'w', encoding='utf-8') as f:
    f.write(script_content)

print("Running node syntax check on modified JavaScript...")
res = subprocess.run(['node', '--check', temp_file], capture_output=True, text=True)

if res.returncode == 0:
    print("SUCCESS! JavaScript syntax is VALID after removing the brace!")
else:
    print("JavaScript syntax is still INVALID:")
    print(res.stderr)
