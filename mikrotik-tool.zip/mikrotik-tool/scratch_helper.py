# -*- coding: utf-8 -*-
import os

path1 = "_archive_v3/mikrotik-tool-v3/backend/dependency/graph.py"
path2 = "_archive_upgraded/mikrotik-tool-upgraded/backend/dependency/graph.py"
path = path1 if os.path.exists(path1) else path2

with open(path, "r", encoding="utf-8") as f:
    lines = f.readlines()

for idx, line in enumerate(lines, 1):
    if "class ConfigDependencyGraph" in line:
        print(f"Found ConfigDependencyGraph starting at line {idx}")
        for offset in range(120, 175):
            if idx + offset < len(lines):
                output = f"  {idx+offset+1}: {lines[idx+offset].rstrip()}"
                print(output.encode('ascii', 'backslashreplace').decode('ascii'))
        break
