# Mikrotik Script Generator

Простой генератор конфигураций MikroTik на основе шаблонов Jinja2.

## Установка

```bash
pip install -r requirements.txt
```

## Запуск

```bash
python script_generator.py
```

## Шаблоны

Пока реализован базовый шаблон (1) - базовая настройка MikroTik.
